spool F:\Base\Clases\ch11_5a.txt

-- ch11_5a.sql
REM 
REM INCLUYE CURSOR EXPLICITO, OPEN & CLOSE FETCH & UN LOOP  
REM  Modify the example to make use of the cursor attributes %FOUND and %ROWCOUNT.
REM
SET SERVEROUTPUT ON
DECLARE
	v_sid student.student_id%TYPE;
	CURSOR c_student IS
		SELECT student_id
			FROM student
			WHERE student_id < 110;
BEGIN
	OPEN c_student;
	LOOP
		FETCH c_student INTO v_sid;
		IF c_student%FOUND THEN
			DBMS_OUTPUT.PUT_LINE
			('Just FETCHED row '||CHR(9)||'LECTURA DESDE EL CURSOR ( FETCH)'||CHR(9)
			||TO_CHAR(c_student%ROWCOUNT)||
			'    Student ID: '||v_sid);
		ELSE
			EXIT;
		END IF;
	END LOOP;
	CLOSE c_student;
EXCEPTION
	WHEN OTHERS
	THEN
		IF c_student%ISOPEN
		THEN
			CLOSE c_student;
		END IF;
END;
/
spool off;