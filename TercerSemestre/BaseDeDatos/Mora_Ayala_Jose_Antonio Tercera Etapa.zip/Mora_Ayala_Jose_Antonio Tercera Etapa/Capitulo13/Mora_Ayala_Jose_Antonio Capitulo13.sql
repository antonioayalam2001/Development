spool F:\Documents\BasedeDatos\Capitulo13MO\Capitulo13MO.txt

--  =======================================================================================
--  ||Capitulo 13 Ejercicios Mastering Oracle SQL                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Mastering Oracle SQL                             ||
--* ||by Sanjay Mishra and Alan Beaulieu                                                ||
--* ||Copyright © 2002 O’Reilly & Associates, Inc. All rights reserved.                 ||
--* ||Printed in the United States of America.                                          ||
--* ||Published by O’Reilly & Associates, Inc., 1005 Gravenstein Highway North,         ||
--* ||Sebastopol, CA 95472.                                                             ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 13 Mastering Oracle SQL'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 210
Connect MasterOracle/MasterOracle;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos MasterOracle
show user;
--  Conociendo nuestras tablas 
desc Customer;

--Advanced Analytic SQL
--Agregado de ventas por region
SELECT o.region_id region_id, SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.region_id;

--Suma de ventas por cliente
SELECT o.cust_nbr cust_nbr, o.region_id region_id,
SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.cust_nbr, o.region_id;

--Localizando aquellos clientes cuyas ventas totales exceden el 20% de su region con:
SELECT cust_sales.cust_nbr cust_nbr, cust_sales.region_id region_id,
cust_sales.tot_sales cust_sales, region_sales.tot_sales region_sales
FROM
(SELECT o.region_id region_id, SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.region_id) region_sales,
(SELECT o.cust_nbr cust_nbr, o.region_id region_id,
SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.cust_nbr, o.region_id) cust_sales
WHERE cust_sales.region_id = region_sales.region_id
AND cust_sales.tot_sales > (region_sales.tot_sales * .2);

--Por ultimo procedemos a realizar un JOIN con la region y el cliente con el proposito de poder
--incluir el nombre del cliente y la region dentro del resultado
SELECT c.name cust_name,
big_custs.cust_sales cust_sales, r.name region_name,
100 * ROUND(big_custs.cust_sales /
big_custs.region_sales, 2) percent_of_region
FROM region r, customer c,
(SELECT cust_sales.cust_nbr cust_nbr, cust_sales.region_id region_id,
cust_sales.tot_sales cust_sales,
region_sales.tot_sales region_sales
FROM
(SELECT o.region_id region_id, SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.region_id) region_sales,
(SELECT o.cust_nbr cust_nbr, o.region_id region_id,
SUM(o.tot_sales) tot_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.cust_nbr, o.region_id) cust_sales
WHERE cust_sales.region_id = region_sales.region_id
AND cust_sales.tot_sales > (region_sales.tot_sales * .2)) big_custs
WHERE big_custs.cust_nbr = c.cust_nbr
AND big_custs.region_id = r.region_id;

--En las consultas anteriores hemos recurrido al ultimo tema que vimos, siendo este las llamadas 
--inline views aunque la solcuion para lo solicitado es algo compleja.

--Procedemos a proponer otra forma de llegar al mismo resulatdo mediante la aplicacion de otras
--operaciones
SELECT o.region_id region_id, o.cust_nbr cust_nbr,
SUM(o.tot_sales) tot_sales,
SUM(SUM(o.tot_sales)) OVER (PARTITION BY o.region_id) region_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.region_id, o.cust_nbr;

--La linea 2 genera la suma de ventas por cliente y region
--En la tercera linea obtenemos el resultado que denominamos region_sales

SELECT c.name cust_name,
cust_sales.tot_sales cust_sales, r.name region_name,
100 * ROUND(cust_sales.tot_sales /
cust_sales.region_sales, 2) percent_of_region
FROM region r, customer c,
(SELECT o.region_id region_id, o.cust_nbr cust_nbr,
SUM(o.tot_sales) tot_sales,
SUM(SUM(o.tot_sales)) OVER (PARTITION BY o.region_id) region_sales
FROM orders o
WHERE o.year = 2001
GROUP BY o.region_id, o.cust_nbr) cust_sales
WHERE cust_sales.tot_sales > (cust_sales.region_sales * .2)
AND cust_sales.region_id = r.region_id
AND cust_sales.cust_nbr = c.cust_nbr;

--Ranking Functions
--RANK, DENSE_RANK, and ROW_NUMBER
--RANK
--Asigna un numero unico a cada fila comenzando con 1, omite aquellos con valores duplicados
--en ese caso se asigna el mismo valor y aparece un salto en la secuencia por cada valor duplicado
--DENSE_RANK
--Asigna un numero unico a cada fila comenzando con 1, omite aquellos que tienen un valor duplicado
--en esa caso el mismo valor es asignado
--ROW_NUMBER
--Devuelve un valor unico para cada fila comenzando con 1. Para aquellas que tengan valores duplicados se 
--asigna un valor arbitrario

SELECT region_id, cust_nbr, SUM(tot_sales) cust_sales
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY region_id, cust_nbr;

--Clientes 2,23,24 poseen el mismo valor de ventas totales

SELECT region_id, cust_nbr,
SUM(tot_sales) cust_sales,
RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_rank,
DENSE_RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_dense_rank,
ROW_NUMBER( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_number
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 6;

--RANK y DENSE_RANK asignan el mismo numero 12 a las 3 filas con el mismo valor mientras que
--ROW_NUMBER asigna 12,13,14

SELECT region_id, cust_nbr, SUM(tot_sales) cust_sales,
RANK( ) OVER (PARTITION BY region_id
ORDER BY SUM(tot_sales) DESC) sales_rank,
DENSE_RANK( ) OVER (PARTITION BY region_id
ORDER BY SUM(tot_sales) DESC) sales_dense_rank,
ROW_NUMBER( ) OVER (PARTITION BY region_id
ORDER BY SUM(tot_sales) DESC) sales_number
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 1,6;

--El uso de la clausula de PARTITION_BY es usado en el ranqueo de funciones para dividir el resultado en un conjunto
-- de piezas para que el ranqueo pueda ser aplicado con cada subconjunto

--Handling NULLs
SELECT region_id, cust_nbr, SUM(tot_sales) cust_sales,
RANK( ) OVER (ORDER BY SUM(tot_sales) DESC NULLS LAST) sales_rank
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr;

--Top/Bottom-N queries
--Uso de un inline view para obtener el tpop 5 de vendedores en el año 2001
SELECT s.name, sp.sp_sales total_sales
FROM salesperson s,
(SELECT salesperson_id, SUM(tot_sales) sp_sales,
RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_rank
FROM orders
WHERE year = 2001
GROUP BY salesperson_id) sp
WHERE sp.sales_rank <= 5
AND sp.salesperson_id = s.salesperson_id
ORDER BY sp.sales_rank;

--FIRST/LAST
SELECT
MIN(region_id)
KEEP (DENSE_RANK FIRST ORDER BY SUM(tot_sales) DESC) best_region,
MIN(region_id)
KEEP (DENSE_RANK LAST ORDER BY SUM(tot_sales) DESC) worst_region
FROM orders
WHERE year = 2001
GROUP BY region_id;


SELECT
MIN(region_id)
KEEP (DENSE_RANK FIRST ORDER BY SUM(tot_sales) DESC) min_best_region,
MAX(region_id)
KEEP (DENSE_RANK FIRST ORDER BY SUM(tot_sales) DESC) max_best_region,
MIN(region_id)
KEEP (DENSE_RANK LAST ORDER BY SUM(tot_sales) DESC) min_worst_region,
MAX(region_id)
KEEP (DENSE_RANK LAST ORDER BY SUM(tot_sales) DESC) max_worst_region
FROM orders
WHERE year = 2001
GROUP BY region_id;

--NTILE
--Usamos para agrupar a los clientes en 4 "baldes"
SELECT region_id, cust_nbr, SUM(tot_sales) cust_sales,
NTILE(4) OVER (ORDER BY SUM(tot_sales) DESC) sales_quartile
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 4,3 DESC;
--NTILE encuentra cada posicion de la fila en el ranking y luego lo agrega a aquella "cubeta/balde"
--que posee la misma cantidad de filas

--WIDTH_BUCKET
--Agrupa filas del resultado en "baldes", tratando de crear baldes del mismo tamaño
--el rango de valores es distribuido a lo largo de los "baldes"
--WIDTH_BUCKET(Valor usado para el comienzo del rango del primer balde, valor usado para el balde final, numero de baldes a crear)
SELECT region_id, cust_nbr,
SUM(tot_sales) cust_sales,
WIDTH_BUCKET(SUM(tot_sales), 1, 3000000, 3) sales_buckets
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 3;

--CUME_DIST and PERCENT_RANK
SELECT region_id, cust_nbr,
SUM(tot_sales) cust_sales,
CUME_DIST( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_cume_dist,
PERCENT_RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) sales_percent_rank
FROM orders
WHERE year = 2001
GROUP BY region_id, cust_nbr
ORDER BY 3 DESC;

--Hypothetical Functions
SELECT cust_nbr, SUM(tot_sales) cust_sales,
RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) rank,
DENSE_RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) dense_rank,
CUME_DIST( ) OVER (ORDER BY SUM(tot_sales) DESC) cume_dist,
PERCENT_RANK( ) OVER (ORDER BY SUM(tot_sales) DESC) percent_rank
FROM orders
WHERE year = 2001
GROUP BY cust_nbr
ORDER BY 3;

SELECT
RANK(1000000) WITHIN GROUP
(ORDER BY SUM(tot_sales) DESC) hyp_rank,
DENSE_RANK(1000000) WITHIN GROUP
(ORDER BY SUM(tot_sales) DESC) hyp_dense_rank,
CUME_DIST(1000000) WITHIN GROUP
(ORDER BY SUM(tot_sales) DESC) hyp_cume_dist,
PERCENT_RANK(1000000) WITHIN GROUP
(ORDER BY SUM(tot_sales) DESC) hyp_percent_rank
FROM orders
WHERE year = 2001
GROUP BY cust_nbr;

--FIRST_VALUE and LAST_VALUE
--Pueden ser empleadas con las llamadas ventanas para entonces identificar el primer y ultimo valor
--de la ventana

SELECT month,
FIRST_VALUE(SUM(tot_sales)) OVER (ORDER BY month
ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING) prev_month,
SUM(tot_sales) monthly_sales,
LAST_VALUE(SUM(tot_sales)) OVER (ORDER BY month
ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING) next_month,
AVG(SUM(tot_sales)) OVER (ORDER BY month
ROWS BETWEEN 1 PRECEDING AND 1 FOLLOWING) rolling_avg
FROM orders
WHERE year = 2001
AND region_id = 6
GROUP BY month
ORDER BY month;

--LAG/LEAD Functions
--Permiten a las filas ser referenciadas por su posicion relativa a la fila actual
--Son utiles para comparar el resultado de una fila con otro que tenga el mismo resultado
SELECT month, SUM(tot_sales) monthly_sales,
LAG(SUM(tot_sales), 1) OVER (ORDER BY month) prev_month_sales
FROM orders
WHERE year = 2001
AND region_id = 6
GROUP BY month
ORDER BY month;

--El siguiente query utiliza la salida del anterior para generar la diferencia de porcentaje
-- de cada mes
--La columna prev_month_sales esta envuelta en una funcion NVL para que el primer mes no
--genere un valor nulo
SELECT months.month month, months.monthly_sales monthly_sales,
ROUND((months.monthly_sales — NVL(months.prev_month_sales,
months.monthly_sales)) /
NVL(months.prev_month_sales, months.monthly_sales),
3) * 100 percent_change
FROM
(SELECT month, SUM(tot_sales) monthly_sales,
LAG(SUM(tot_sales), 1) OVER (ORDER BY month) prev_month_sales
FROM orders
WHERE year = 2001
AND region_id = 6
GROUP BY month) months
ORDER BY month;

SELECT month,
SUM(tot_sales) monthly_sales,
SUM(SUM(tot_sales)) OVER (ORDER BY month
ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) total_sales
FROM orders
WHERE year = 2001
AND region_id = 6
GROUP BY month
ORDER BY month;

--USING REPORTING FUNCTIONS
SELECT month,
SUM(tot_sales) monthly_sales,
SUM(SUM(tot_sales)) OVER (ORDER BY month
ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) window_sales,
SUM(SUM(tot_sales)) OVER ( ) reporting_sales
FROM orders
WHERE year = 2001
AND region_id = 6
GROUP BY month
ORDER BY month;

--Report Partitions
--Permite dividir el resultado en diferentes "piezas"
SELECT region_id, salesperson_id,
SUM(tot_sales) sp_sales,
SUM(SUM(tot_sales)) OVER (PARTITION BY region_id) region_sales
FROM orders
WHERE year = 2001
GROUP BY region_id, salesperson_id
ORDER BY region_id, salesperson_id;

--RATIO_TO_REPORT

SELECT region_id, salesperson_id,
SUM(tot_sales) sp_sales,
ROUND(SUM(tot_sales) /
SUM(SUM(tot_sales)) OVER (PARTITION BY region_id),
2) percent_of_region
FROM orders
WHERE year = 2001
GROUP BY region_id, salesperson_id
ORDER BY region_id, salesperson_id1,2;

spool off;
