spool F:\Base\Clases\Mora_Ayala_Jose_Antonio_ch12_3a.txt

-- ch20_01c.sql, version 1.0
CREATE OR REPLACE FUNCTION new_instructor_id
	RETURN instructor.instructor_id%TYPE
AS
	v_new_instid instructor.instructor_id%TYPE;
BEGIN
	SELECT INSTRUCTOR_ID_SEQ.NEXTVAL
		INTO v_new_instid
		FROM dual;
	RETURN v_new_instid;
EXCEPTION
WHEN OTHERS
THEN
	DECLARE
		v_sqlerrm VARCHAR2(250) := SUBSTR(SQLERRM,1,250);
	BEGIN
		RAISE_APPLICATION_ERROR(-20003,
		'Error in instructor_id: '||v_sqlerrm);
	END;
END new_instructor_id;
/
spool off;