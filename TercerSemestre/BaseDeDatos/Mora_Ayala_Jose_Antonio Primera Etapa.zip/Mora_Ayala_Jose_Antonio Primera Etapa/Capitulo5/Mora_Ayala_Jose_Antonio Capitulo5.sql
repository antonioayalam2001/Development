spool F:\Documents\BasedeDatos\Capitulo5\Capitulo5.txt

--  =======================================================================================
--  ||Capitulo 5 Ejercicios SQLOracle By Example                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Oracle SQL by Example Third Edition              ||
--* ||Rischert, Alice.                                                                  ||
--* ||Oracle SQL by example / Alice Rischert.-- 3rd ed.                                 ||
--* ||p. cm. -- (Prentice Hall PTR Oracle series)                                       ||
--* ||Rev. ed. of: Oracle SQL interactive workbook, 2003.                               ||
--* ||Includes indexes.                                                                 ||
--* ||ISBN 0-13-145131-6                                                                ||
--* ||1. SQL (Computer program language) 2. Oracle (Computer file)                      ||
--* ||I. Rischert, Alice. Oracle SQL interactive workbook. II. Title. III. Series.      ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 5'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2


SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 110
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;

--    Aggregate Functions, GROUP BY, and Having
--    AGGREGATE FUNCTIONS
--    The COUNT Function

SELECT COUNT(*)
   FROM enrollment;

--    The COUNT Function
--    COUNT and NULLS
--  Nos devuelve la cantidad de elementos que hay de acuerdo a la tabla 
--  No considera los valores nulos
SELECT COUNT(final_grade), COUNT(section_id), COUNT(*)
   FROM enrollment;


--    COUNT and DISTINCT
--  Nos devolvera la cantidad donde sean distintos, como hay varios que se repiten 
--  No entran en la cuenta final, mientras que COUN generaliza

SELECT COUNT(DISTINCT section_id), COUNT(section_id)
   FROM enrollment;

--    The SUM Function
--  Agrega valores juntos por un grupo de filas
--  Realiza una suma de los valores numericos de la fila, si hay valores nulos son ignorados
SELECT SUM(capacity)
   FROM section;

--    The AVG Function
--  Funcion PROMEDIO, la cual nos proprociona el promedio de los valores numericos 

SELECT AVG(capacity), AVG(NVL(capacity,0))
   FROM section;

--    The MIN and MAX Functions
--  Proporiona el valor minimo y valor maximo que se encuentra dentro de estos datos

SELECT MIN(capacity), MAX(capacity)
   FROM section;

--    The MIN and MAX Functions
--    MIN and MAX With Other Datatypes
--  Tambien puede ser usado con las CHAR, pues se basa en el codigo ASCII y de aqui es como 
--  realiza la prioridad, como A es el numero 65 y luego B 66 así va hasta ver cual debería ir primero
SELECT MIN(registration_date) "First", MAX(registration_date) "Last"
   FROM student;
SELECT MIN (description) AS MIN, MAX (description) AS MAX
   FROM course;

--    AGGREGATE Function and CASE


 SELECT AVG(CASE WHEN prerequisite IS NOT NULL THEN cost*1.1
                 WHEN prerequisite = 20 THEN cost*1.2
                 ELSE cost
            END) AS avg
   FROM course;

--    The GROUP BY and HAVING Clauses
--    The GROUP BY Clause

--  Nos realiza la agrupación, devuelve 12 filas debido a que solo 12 son unicos
--  de ahi estos 12 datos proporcionados se van repitiendo para diferentes estudiantes etc.

SELECT location
   FROM section
  GROUP BY location;

--    The GROUP BY Clause
--  Contara las veces que se repite esa locación
--  Devuelve 12 filas y la cuenta de cuantas veces se repite dicho dato
SELECT location, COUNT(*)
   FROM section
  GROUP BY location;

SELECT location, COUNT(*), SUM(capacity) AS sum,
        MIN(capacity) AS min, MAX(capacity) AS max
   FROM section
  GROUP BY location;

SELECT location, capacity, section_id
   FROM section
  WHERE location = 'L211';

--    Grouping By Multiple Columns

SELECT location, instructor_id,
        COUNT(*), SUM(capacity) AS sum,
        MIN(capacity) AS min, MAX(capacity) AS max
   FROM section
  GROUP BY location, instructor_id;

SELECT location, instructor_id, capacity, section_id
   FROM section
  WHERE location = 'L210'
  ORDER BY 1, 2;

--    The HAVING Clause
--  Se usa para eliminar grupos 
--  Aqui el having nos restringe el resultado a aquellas locaciones con una 
--  capacidad total de mas de 50 estudiantes
 SELECT location "Location", instructor_id,
        COUNT(location) "Total Locations",
        SUM(capacity) "Total Capacity"
   FROM section
  GROUP BY location, instructor_id
 HAVING SUM(capacity) > 50
ORDER BY "Total Capacity" DESC;

--    The WHERE and HAVING Clauses
--  Asi como having elimina grupos, where se encarga de eliminar filas que no cumplan con la condicion,
--  el manejador aplica primero where

SELECT location "Location", instructor_id,
        COUNT(location) "Total Locations",
        SUM(capacity) "Total Capacity"
   FROM section
  WHERE section_no IN (2, 3)
  GROUP BY location, instructor_id
 HAVING SUM(capacity) > 50;

--    Multiple Conditions In The HAVING Clause

SELECT location "Location",
        SUM(capacity) "Total Capacity"
   FROM section  WHERE section_no = 3
  GROUP BY location
HAVING (COUNT(location) > 3
         AND location LIKE 'L5%');

--    Constants and Functions Without Paramenters

SELECT 'Hello', 1, SYSDATE, course_no "Course #",
        COUNT(*)
   FROM section
  GROUP BY course_no HAVING COUNT(*) = 5;

--    Order Of The Clauses

SELECT course_no "Course #",
        AVG(capacity) "Avg. Capacity",
        ROUND(AVG(capacity)) "Rounded Avg. Capacity"
   FROM section
 HAVING COUNT(*) = 2
  GROUP BY course_no;

--    Nesting Aggregate Functions

SELECT MAX(COUNT(*))
   FROM enrollment
  GROUP BY section_id;

  --  	5.1.1. Usar funciones agregadas en una declaración SQL

--  	a) Escriba una declaración SELECT para determinar cuántos cursos 
--  		no tienen un requisito previo.

SELECT COUNT(*)
    FROM course
   WHERE prerequisite IS NULL;

--  	b) Escriba una declaración SELECT para determinar el número total de estudiantes inscritos.
--  		Cuente los estudiantes solo una vez, sin importar en cuántos cursos estén inscritos.

SELECT COUNT(DISTINCT student_id)
   FROM enrollment;

--  	c) Determine el costo promedio de todos los cursos. Si el costo del curso contiene un valor 
--  		nulo, sustituya el valor por 0.

SELECT AVG(NVL(cost, 0))
FROM course;

--  	d) Escriba una declaración SELECT para determinar la fecha de la inscripción más reciente.

SELECT MAX(enroll_date)
   FROM enrollment;

--  	5.2.1. Utilice las cláusulas GROUP BY y HAVING

--  	a) Muestre una lista de requisitos previos y cuente cuántas veces aparece 
--  		cada uno en la tabla CURSO. Ordene el resultado por la columna PRERREQUISITO.

SELECT prerequisite, COUNT(*)
   FROM course
    GROUP BY prerequisite
   ORDER BY prerequisite;

--  	b) Escriba una declaración SELECT que muestre las identificaciones de los estudiantes y 
--  		la cantidad de cursos en los que están inscritos. Muestre solo los inscritos en más 
--  		de dos clases.

SELECT student_id, COUNT(*)
   FROM enrollment
    GROUP BY student_id
   HAVING COUNT(*) > 2;

--  	c) Escriba una declaración SELECT que muestre la capacidad promedio de la sala para cada 
--  		curso. Muestre el promedio expresado al número entero más cercano en otra columna.
--  		Utilice alias de columna para cada columna seleccionada.

SELECT course_no "Course #", AVG(capacity) "Avg. Capacity",
		ROUND(AVG(capacity)) "Rounded Avg. Capacity"
FROM section
GROUP BY course_no;

--  	d) Escriba la misma declaración SELECT que en la pregunta anterior, excepto para los 
--  		cursos con exactamente dos secciones. Sugerencia: Piense en la relación entre las 
--  		tablas COURSE y SECTION, específicamente cuántas veces se puede representar un curso 
--  		en la tabla SECTION.

SELECT course_no "Course #", AVG(capacity) "Avg. Capacity",
		ROUND(AVG(capacity)) "Rounded Avg. Capacity"
FROM section
GROUP BY course_no
HAVING COUNT(*) = 2;

  spool off