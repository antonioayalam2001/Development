spool C:\Users\Admin\Documents\2021_bases\salidas\clase_tres.txt
rem revisar el manual SQL*Plus® de Oracle 
rem User’s Guide and Reference
rem Release 10.2
rem B14357-01
CLEAR SCREEN
SET PAGESIZE 90;
SET LINESIZE 90;
SET COLSEP ' ||';
set describe linenum on;
SET FEEDBACK on;


COL PARAMETER FORMAT A29;
COL VALUE     FORMAT A29;

SELECT PARAMETER, VALUE FROM NLS_SESSION_PARAMETERS
     ORDER BY 1;


Rem desplegar la estructura de cada entidad del esquema STUDENT

describe instructor
describe student
describe course
describe enrollment
describe grade_type
describe grade_conversion
describe grade_type
describe grade
describe grade_type_weight
describe section
describe course
describe zipcode

rem deplegar tres atributos de la entidad instructor

select instructor_id, first_name, last_name
	from instructor;
rem desplegar tres atributos odernarlos por alguno de ellos en este caso el tercero.
select instructor_id, first_name, last_name
	from instructor
	order by 3;
rem desplegarlos ahora odernarlos por el tercero en forma descendente.
select instructor_id, first_name, last_name
	from instructor
	order by 3 desc;

rem desplegar tres atributos de la entidad student solamente los diez primeros
	
select student_id, first_name, last_name 
	from student
	where rownum <= 10 ;
	
rem despleguemos ahora un dato fecha 
rem la fecha se desplegara con el formato que esta configurada la session
rem el nls_date_format
select student_id, first_name, last_name, registration_date 
	from student
	where rownum <= 10 ;
rem cambiemos el formato de fecha en la session  NLS_DATE_FORMAT = "DAY DD-MONTH-YYYY";
alter session set NLS_DATE_FORMAT = "DAY DD-MONTH-YYYY";
rem ajustemos el tamaño de las columnas al desplegar 
column first_name format a10;
column last_name format a10;
COLUMN student_id FORMAT 9,999;
select student_id, first_name, last_name, registration_date 
	from student
	where rownum <= 10 ;
	
rem tambien podemos sobremodificar el formato dentro de la sentencia SELECT
column fecha format a33
select student_id, first_name, last_name, to_char(registration_date,'DAY DD-Month-YYYY') fecha 
	from student
	where rownum <= 10;	
rem despleguemos en el formato de TO_CHAR el dia del año
select student_id, first_name, last_name,
		to_char(registration_date,'DDD DD-Month-YYYY') fecha 
	from student
	where rownum <= 10;
rem despleguemos en el formato de TO_CHAR el dia del año  HH:MM
select student_id, first_name, last_name, 
		to_char(registration_date,'DDD DD-Month-YYYY HH:MM:SS') fecha 
	from student
	where rownum <= 10;
Rem quitarle los espacios en blanco entre el mes y el año	
select student_id, first_name, last_name, 
		to_char(registration_date,'DDD DD-fmMonth-YYYY HH:MM:SS') fecha 
	from student
	where rownum <= 10; 
	
alter session set nls_date_language = 'ENGLISH';
SELECT TO_CHAR(SYSDATE, 'fmDDTH') || ' of ' ||
TO_CHAR(SYSDATE, 'fmMonth') || ', ' ||
TO_CHAR(SYSDATE, 'YYYY') "fecha en English"
FROM DUAL;

alter session set nls_date_language = 'SPANISH';



REM conocer la estructura de algunas de las tablas del diccionario de datos
desc nls_session_parameters
desc all_objects
desc user_tables
desc user_objects
column table_name format a28
column tablespace_name format a8
column owner format a8
rem despleagar tres atributos de user_tables
select table_name, tablespace_name, status, pct_free, pct_used
   from user_tables;
   
rem despleagar tres atributos de all_tables 
select owner,table_name, tablespace_name, status, pct_free, pct_used
   from all_tables;
   
rem despleagar tres atributos de all_tables filtrando los renglones 
rem del tablespace USERS 
select owner,table_name, tablespace_name, status, pct_free, pct_used
   from all_tables
   where tablespace_NAME= 'USERS';
   
SELECT OWNER, OBJECT_NAME, OBJECT_ID, OBJECT_TYPE,STATUS
	FROM ALL_OBJECTS
	WHERE OBJECT_TYPE LIKE '%TABLE';
REM AHORA SOLO LOS DE UN USUARIO
SELECT OWNER, OBJECT_NAME, OBJECT_ID, OBJECT_TYPE,STATUS
	FROM ALL_OBJECTS
	WHERE OBJECT_TYPE LIKE '%TABLE'AND 
		 OWNER = 'SERGIO20';
 REM DESPLEGAR LOS DISTINTOS TIPOS DE OBJETOS QUE EXISTEN
 SELECT DISTINCT OBJECT_TYPE FROM ALL_OBJECTS;
 REM DESPLEGAR LOS INDICES ASOCIADO A ESTE ESQUEMA
SELECT OWNER, OBJECT_NAME, OBJECT_ID, OBJECT_TYPE,STATUS
	FROM ALL_OBJECTS
	WHERE OBJECT_TYPE LIKE '%INDEX'AND 
		 OWNER = 'SERGIO20';
  REM DESPLEGAR SEQUENCES ASOCIADOS A ESTE ESQUEMA
SELECT OWNER, OBJECT_NAME, OBJECT_ID, OBJECT_TYPE,STATUS
	FROM ALL_OBJECTS
	WHERE OBJECT_TYPE LIKE '%SEQUENCE'AND 
		 OWNER = 'SERGIO20';
 spool off
 






