
spool F:\Base\Clases\Mora_Ayala_Jose_Antonio_ch12_4a.txt
-- ch12_4a.sql
REM  ACTUALIZAR LA CLAVE DE INICIO DEL TELEFONO DE LOS HABITANTES DE 
REM LS ESTUDIANTES QUE VIVEN EL BROOKLIN

DECLARE
	CURSOR c_stud_zip IS
		SELECT s.student_id, z.city
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
				AND s.zip = z.zip
			FOR UPDATE OF phone;
BEGIN
	FOR r_stud_zip IN c_stud_zip
	LOOP
		UPDATE student
			SET phone = '799'||SUBSTR(phone,4)
		WHERE student_id = r_stud_zip.student_id;
	END LOOP;
END;
/
rem consultas previas 
rem sin el filtro adecuados 

		SELECT s.student_id, z.city,phone,s.zip 
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
			and SUBSTR(phone,1,3) like '718';
			
		SELECT s.student_id, z.city,phone,s.zip 
			FROM student s, zipcode z
			WHERE  SUBSTR(phone,1,3) like '718';

rem 
/*			
		SELECT s.student_id, z.city,s.zip,count(*)
			FROM student s, zipcode z
			WHERE  z.city = 'Brooklyn' and phone like '%718%'
			group by z.city,s.zip,s.student_id;
*/			
	
		SELECT s.student_id,s.zip
			FROM student s
			WHERE   phone like '%718%'
			group by s.student_id,s.zip
			order by 1;	
rem    desplegar los codigos postales de Brooklin 
		
		SELECT  z.city,z.zip 
			FROM zipcode z
			WHERE z.city = 'Brooklyn';
			
			11029, 11201-11238
/*			
		SELECT s.student_id,s.phone,count(*)
			FROM student s
			WHERE   phone like '%718%'
			group by s.student_id,s.zip
			order by 1;	
*/
rem encontrar los alumnos cuyos telefonos emíecen con   718
rem con conector OR 
SELECT s.student_id,s.phone
			FROM student s
			WHERE   phone like '%718%'
				or rownum <= 15;
rem con conector AND     				
SELECT s.student_id,s.phone
			FROM student s
			WHERE   phone like '%718%'
				and rownum <= 15;
REM CON   LA FUNCIÓN       SUBSTR 				
SELECT s.student_id,s.phone
			FROM student s				
			where SUBSTR(phone,1,3) like '718'
			and rownum <= 15;
			
rem
rem DESPLEGAR LOS ALUMNOS QUE VIVEN EN BROOKLIN
		SELECT s.student_id, z.city,phone
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
				AND s.zip = z.zip
				and rownum <= 20;
				
rem 		depleguemos el todas las tuplas de los 
rem      estudiantes que son de Brooklin
rem      incluyendo el telefono
REM  QUERY PARA VERIFICAR 		
		SELECT s.student_id, z.city,phone
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
				AND s.zip = z.zip;
				
rem inclyendo el codigo postal
		SELECT s.student_id, z.city,phone,z.zip 
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
				AND s.zip = z.zip;	
				
rem ahora contemos 	solo hasta 20 			
		SELECT  z.city,phone,count (*)
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
				AND s.zip = z.zip
				and rownum <= 20
				group by  z.city,phone;
				
rem contemos el total 				
		SELECT  z.city,phone,count (*)
			FROM student s, zipcode z
			WHERE z.city = 'Brooklyn'
				AND s.zip = z.zip
				group by  z.city,phone;
spool off;