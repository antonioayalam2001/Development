
spool C:\Users\ORA_bases\dbbook\salida\dbbook.txt
@@C:\Users\ORA_bases\dbbook\script\dbbook.sql
@@C:\Users\ORA_bases\dbbook\script\cifras
spool off