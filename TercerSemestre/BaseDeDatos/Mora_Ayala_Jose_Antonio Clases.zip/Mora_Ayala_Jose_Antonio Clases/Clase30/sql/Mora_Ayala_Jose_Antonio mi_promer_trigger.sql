spool F:\Base\Clases\mi_promer_trigger.txt
set feedback off
set pagesize 99
set linesize 130
set colsep '|=|'


set serveroutput on 

drop table temp;
CREATE TABLE temp (N NUMBER);

CREATE OR REPLACE TRIGGER temp_air
   AFTER INSERT ON TEMP
   FOR EACH ROW
   BEGIN
   dbms_output.put_line('         H O L A   ESCOM');
   dbms_output.put_line('executing temp_air');
   dbms_output.put_line
		('Estoy en clase Remota de ESCOM------------');
  END;
  
  REM compilando el trigger con un punto
  .


INSERT INTO temp VALUES (10); 
INSERT INTO temp VALUES (20); 
INSERT INTO temp VALUES (30); 
INSERT INTO temp VALUES (40); 
INSERT INTO temp VALUES (50); 
INSERT INTO temp VALUES (60); 
INSERT INTO temp VALUES (70); 




col trigger_name format a13
col trigger_type format a20
col triggering_event format A10
col table_owner format A10
col status format A10

select trigger_name,trigger_type,triggering_event,
	table_owner,status
	from user_triggers;
	
alter trigger 	temp_air DISABLE; 

alter trigger 	temp_air ENABLE; 
  
spool off;