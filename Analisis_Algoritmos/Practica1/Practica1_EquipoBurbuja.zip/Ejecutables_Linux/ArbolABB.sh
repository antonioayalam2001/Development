#!/bin/bash
echo Estas apunto de ejecutar el programa: ArbolABB
cd ..
gcc mainLin.c -lm -o mainLin

./mainLin 7 100 >ArbolT.txt
./mainLin 7 1000 >>ArbolT.txt
./mainLin 7 5000 >>ArbolT.txt
./mainLin 7 10000 >>ArbolT.txt
./mainLin 7 50000 >>ArbolT.txt
./mainLin 7 100000 >>ArbolT.txt 
./mainLin 7 125000 >>ArbolT.txt 
./mainLin 7 175000 >>ArbolT.txt 
./mainLin 7 200000 >>ArbolT.txt
./mainLin 7 225000 >>ArbolT.txt
./mainLin 7 275000 >>ArbolT.txt
./mainLin 7 300000 >>ArbolT.txt
./mainLin 7 325000 >>ArbolT.txt
./mainLin 7 375000 >>ArbolT.txt
./mainLin 7 400000 >>ArbolT.txt
./mainLin 7 425000 >>ArbolT.txt
./mainLin 7 500000 >>ArbolT.txt
# ./mainLin 7 600000 >>ArbolT.txt
# ./mainLin 7 800000 >>ArbolT.txt
# ./mainLin 7 1000000 >>ArbolT.txt
# ./mainLin 7 2000000 >>ArbolT.txt
# ./mainLin 7 3000000 >>ArbolT.txt
# ./mainLin 7 4000000 >>ArbolT.txt
# ./mainLin 7 5000000 >>ArbolT.txt
# ./mainLin 7 6000000 >>ArbolT.txt
# ./mainLin 7 7000000 >>ArbolT.txt
# ./mainLin 7 8000000 >>ArbolT.txt
# ./mainLin 7 9000000 >>ArbolT.txt
# ./mainLin 7 10000000 >>ArbolT.txt



