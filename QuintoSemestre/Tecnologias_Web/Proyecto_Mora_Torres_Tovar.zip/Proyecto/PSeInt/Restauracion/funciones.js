  var canvas = document.getElementById('canvas');
  var ctx = canvas.getContext('2d');
  var ctx2= canvas.getContext('2d');
  var ch = canvas.width;
  var coordenadax=400;
  var coordenaday=75;
  var coordenadayt=90;
  var coordenadaxt=470;

function dibujarinicio(){
  var centrox=ch/2, radioX = 50, radioY = 20, rotacion=0, ap = 0, af = 2*Math.PI, cR = true;
  ctx.beginPath();
  ctx.fillStyle = "blue";
  ctx.ellipse(centrox, 35, radioX, radioY, rotacion, ap, af, cR);
  ctx.fill();
  ctx.font = "bold 15px sans-serif";
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('INICIO',480,40);

}

function dibujarfin(){
  var canvas1 = document.getElementById('canvas');
  var ctx3 = canvas1.getContext('2d');
  var centrox=ch/2, radioX = 50, radioY = 20, rotacion=0, ap = 0, af = 2*Math.PI, cR = true;
  ctx.beginPath();
  ctx3.fillStyle = "red";
  ctx3.ellipse(centrox, 415, radioX, radioY, rotacion, ap, af, cR);
  ctx3.fill();
  ctx3.font = "bold 15px sans-serif";
  ctx3.fillStyle = '#FFFFFF';
  ctx3.fillText('FIN',490,420);

}


function compilar(){
var palabra=document.getElementById("norm").value;
var palabra1=document.getElementById("indi").value;
var palabra2=document.getElementById("indi1").value;
var palabra3=document.getElementById("indif").value;

var palabraz=document.getElementById("p1").value;
var palabrax=document.getElementById("p2").value;
var palabray=document.getElementById("p3").value;
var estructura=document.getElementById("menu").value

if(estructura=='1'){
  document.formu.texto.value += 'void(main){\n'+'int '+palabra+';\n'+'printf("'+palabra1+'");\n'+'scanf("'+palabra2+'");\n\n'+'if('+palabraz+'){\n'+'printf("'+palabrax+'");\n'+'}\n'+'else{\n'+'printf("'+palabray+'");\n}\n'+'printf("'+palabra3+'");\n}';
}

if(estructura=='2'){
  document.formu.texto.value += 'void(main){\n'+'int '+palabra+';\n'+'printf("'+palabra1+'");\n'+'scanf("'+palabra2+'");\n\n'+'while('+palabraz+'){\n'+'printf("'+palabrax+'");\n'+'}\n'+'printf("'+palabra3+'");\n}';
}

if(estructura=='3'){
  document.formu.texto.value += 'void(main){\n'+'int '+palabra+';\n'+'printf("'+palabra1+'");\n'+'scanf("'+palabra2+'")\n\n'+'for(int i='+palabraz+';i<='+palabrax+';i++){\n'+'printf("'+palabray+'");\n}'+'printf("'+palabra3+'");\n}';
}

}

  function dibujar(){
    var color=document.getElementById("color").value
    var palabra=document.getElementById("norm").value;
    ctx.fillStyle =color;
    ctx.fillRect(coordenadax,coordenaday,200,35);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabra+'',coordenadaxt,coordenadayt);
    alert(palabra);
  }
  function dibujarindicacion(){
    var color1=document.getElementById("color1").value
    var palabra1=document.getElementById("indi").value;  
    ctx.fillStyle =color1;
    ctx.fillRect(coordenadax-30,coordenaday+50,260,35);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabra1+'',coordenadaxt,coordenadayt+60);
    alert(palabra1);
  }
  
  function dibujarescan(){
    var color2=document.getElementById("color2").value
    var palabra2=document.getElementById("indi1").value;
    ctx.fillStyle =color2;
    ctx.fillRect(coordenadax+10,coordenaday+100,180,35);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabra2+'',coordenadaxt,coordenadayt+110);
    alert(palabra2); 
  }



  function dibujarindif(){
    var color3=document.getElementById("color4").value
    var palabra3=document.getElementById("indif").value;
    ctx.fillStyle = color3;
    ctx.beginPath();
    ctx.moveTo(435, 325);
    ctx.lineTo(600, 325);
    ctx.lineTo(580, 375); 
    ctx.lineTo(415, 375);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabra3+'',coordenadaxt,350);
    alert(palabra3); 
  }


  function dibujarest(){
    var colorz=document.getElementById("color3").value
    var palabraz=document.getElementById("p1").value;
    var palabrax=document.getElementById("p2").value;
    var palabray=document.getElementById("p3").value;
    var estructura=document.getElementById("menu").value
    
if(estructura=='1'){
   ctx2.fillStyle = colorz;
   ctx2.beginPath();
   ctx2.moveTo(500, 225);
   ctx2.lineTo(610,265);
   ctx2.lineTo(500, 305);
   ctx2.lineTo(390, 265);
   ctx2.closePath();
   ctx2.fill();

   ctx.fillStyle =color2;
   ctx.fillRect(210,247,180,35);
   ctx.fillStyle =color2;
   ctx.fillRect(610,247,180,35);
   
   
   
   ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabraz+'',470,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabrax+'',225,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "10px Verdana";
    ctx.fillText(''+palabray+'',625,265);
    alert(palabraz); 
}

if(estructura=='2'){

  ctx.fillStyle = "#D4E157";
  ctx.beginPath();
  ctx.moveTo(420,225);
  ctx.lineTo(575, 225);
  ctx.lineTo(600,265);
  ctx.lineTo(575, 305);
  ctx.lineTo(420, 305);
  ctx.lineTo(395, 265);
  ctx.closePath();
  ctx.fill();
   
   ctx.fillStyle =colorz;
   ctx.fillRect(210,247,180,45);
   ctx.fillStyle =colorz;
   ctx.fillRect(610,247,180,45);
  
   ctx.fillStyle = '#FFFFFF';
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabraz+'',470,275);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabrax+'',225,275);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabray+'',625,275);
  alert(palabraz); 
}


if(estructura=='3'){
ctx.fillStyle = "#1565C0";
ctx.beginPath();
ctx.moveTo(400,240);
ctx.lineTo(595,240);
ctx.lineTo(620,300); 
ctx.lineTo(380,300);
ctx.closePath();
ctx.fill();
ctx.fillStyle =colorz;
   ctx.fillRect(210,247,180,45);
   ctx.fillStyle =colorz;
   ctx.fillRect(610,247,180,45);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabraz+'',470,275);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabrax+'',225,275);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabray+'',625,275);
  alert(palabraz); 
}
 
  }

  function cargardiagrama(tex){
  ctx.clearRect(0, 0, 1000, 3000);
  var tex1=tex;
  ctx2.fillText('Carlos y es es'+tex1+' ',coordenadaxt,coordenadayt);
  ctx2.fillStyle = "#C2185B";
  ctx2.beginPath();
  ctx2.moveTo(500, 175);
  ctx2.lineTo(550,230);
  ctx2.lineTo(500, 280);
  ctx2.lineTo(450, 230);
  ctx2.closePath();
  ctx2.fill();
  ctx2.fillStyle = "#C2185B";
  }

  function borrar(){
  ctx.clearRect(0, 0, 1000, 3000);
  document.getElementById("ide").value="";
  coordenadax=400;
  coordenaday=75;
  coordenadayt=90;
  coordenadaxt=470;
  }

  function guardado(){
    alert("TU DIAGRAMA SE HA GUARDADO XD");
  }
  