CLEAR SCREEN
SET PAGESIZE 99;
SET LINESIZE 150;

/* DANDO FORMATO A COMO QUEREMOS QUE NOS DE EL FORMATO DE LA TABLA */
COL PARAMETER FORMAT A29;
COL VALUE     FORMAT A29;
SET COLSEP ' * ';
SELECT PARAMETER, VALUE FROM NLS_SESSION_PARAMETERS
     ORDER BY 1;
REM CAMBIA EL IDIOMA DE LA FECHA
alter session set nls_date_language = 'ENGLISH';
REM Despliega nuevamente los parametros de la session 
clear screen
SELECT PARAMETER, VALUE FROM NLS_SESSION_PARAMETERS
rem despliega solamente el parametro  nls_date_language
select parameter, value from nls_session_parameters
  where parameter = 'NLS_DATE_LANGUAGE' ;

  /* DUMP(SYSDATE) DUMP = VACYADO DE MEMORIA (VACIA EL CONTENIDO DE SYSDATE)
--------------------------------------------------------------------------------
Typ=13 Len=8: 228,7,9,29,9,3,50,0 */

/* select dump(systimestamp) from dual;

DUMP(SYSTIMESTAMP)
--------------------------------------------------------------------------------
Typ=188 Len=20: 228,7,9,29,14,15,24,0,64,9,229,18,251,0,5,0,0,0,0,0

SI DAMOS FORMATO DUMP NOS REGRESA QYE TIENE 20 CARACTERES DE LONGITUD DE 20
 */

 /*  COLUMN FECHA1 FORMAT A20;
SQL> COLUMN FECHA2 FORMAT A32;
SQL>


a30 = dando caracteres 


select sysdate FECHA1, systimestamp FECHA2 from dual;
cada coma es un atributo de la etiqueta de la tabla 
 */

 /* select
  2  TO_CHAR(TO_DATE('1-Ene--4712 12:00 pm' , 'dd-Mon-syyyy hh:mi am'),'J')
  3  from dual;
  
  2- Estamos dando una fecha y estamos proporcionando el formato en que lo estamos dando,
  usamos formato J para que lo de en formato numerico 
  
   */

   /* REM 
   Realiza comentarios */

/* 

SQL> COLUMN FECHA1 FORMAT A20;  CREANDO COLUMNA
SQL> COLUMN FECHA2 FORMAT A32;     CREANDO COLUMNA 2
SQL> select
  2  TO_CHAR(TO_DATE('29-Sep-2020 7:00 am' , 'dd-Mon-syyyy hh:mi am'),'J') FECHA1,  ALMACENANDO CONTENIDO EN COLUMNA 1 
  3  TO_CHAR(TO_DATE('10-Feb-2020 7:00 am' , 'dd-Mon-syyyy hh:mi am'),'J') FECHA2,   ALMACENANDO CONTENIDO EN COLUMNA 2
  4  (TO_DATE('29-Sep-2020 7:00 Am','dd-Mon-yyyy hh:mi am') - TO_DATE('10-Feb-2020 7:00 Am','dd-Mon-yyyy hh:mi am')) "Dias |Transcurridos"
  5  from dual;

FECHA1               FECHA2                           Dias |Transcurridos
-------------------- -------------------------------- -------------------
2459122              2458890                                          232





 */











