spool F:\Documents\BasedeDatos\Capitulo6\Capitulo6.txt

--  =======================================================================================
--  ||Capitulo 6 Ejercicios SQLOracle By Example                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Oracle SQL by Example Third Edition              ||
--* ||Rischert, Alice.                                                                  ||
--* ||Oracle SQL by example / Alice Rischert.-- 3rd ed.                                 ||
--* ||p. cm. -- (Prentice Hall PTR Oracle series)                                       ||
--* ||Rev. ed. of: Oracle SQL interactive workbook, 2003.                               ||
--* ||Includes indexes.                                                                 ||
--* ||ISBN 0-13-145131-6                                                                ||
--* ||1. SQL (Computer program language) 2. Oracle (Computer file)                      ||
--* ||I. Rischert, Alice. Oracle SQL interactive workbook. II. Title. III. Series.      ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 6'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2


SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 110
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;

--       Equijoins
--       The Two-Table Join
--       Narrowing Down Your Result Set

--  Aqui podemos ver como estamos porporcionando un alias a las columnas
--  para que sea mas facil diferenciar de donde estamos tomando la informacion
SELECT c.course_no, s.section_no, c.description,
        s.location, s.instructor_id
   FROM course c, section s
  WHERE c.course_no = s.course_no;


--       NULLS and JOINS
--      En un equijoin un valor nulo en la columna en comun posee el efecto de que 
--      esa fila no es incluida en el resultado
--      Un valor nulo NO ES IGUAL a ningun otro valor, incluso si este otro valor
--      tambien es uno nulo

SELECT instructor_id, zip, last_name, first_name
   FROM instructor
  WHERE zip IS NULL;

--        NULLS and JOINS

SELECT i.instructor_id, i.zip, i.last_name, i.first_name
   FROM instructor i, zipcode z
  WHERE i.zip = z.zip;

--        ANSI JOIN Syntax

--        The USING Condition
--  Identifica la columna en comun entre tablas

SELECT course_no, s.section_no, c.description,
        s.location, s.instructor_id
   FROM course c INNER JOIN section s
  USING (course_no);

--        The ON Condition
--  En caso de que los nombres de las tablas fueran diferentes, se puede usar ON
--  y poder el identificador con el aliars correspondiente asi como el nombre 
--  de las columans 

SELECT c.course_no, s.section_no, c.description,
        s.location, s.instructor_id
   FROM course c JOIN section s;

--       Additional WHERE Clause Conditions

SELECT c.course_no, s.section_no, c.description,
s.location, s.instructor_id
FROM course c JOIN section s
ON (c.course_no = s.course_no)
WHERE description LIKE 'B%';

--       The NATURAL JOIN
--  Une tablas basadas en las columnas con el mismo nombre y tipo de dato.
--  No hay ninguna necesidad de realizar una especificacion 
SELECT course_no, s.section_no, c.description,
        s.location, s.instructor_id
   FROM course c NATURAL JOIN section s;
--  No devuelve ningun dato debido a que estas dos tablas tienen mas columnas con el mismo nombre
--  al no encontrar algun dato con los mismo valores en las 5 columnas no hay dato que devolver

--       Cartesian Product

SELECT COUNT(*)
   FROM section, instructor;

--       Cartesian Product
--  El producto cartesiano realemnte es de poco uso en el mundo real y sobre todo en las bases de datos, pues
--  indica inconsistencias y genera tuplas espuria, lo cual en el modelo EER se trata de evitar

SELECT s.instructor_id s_instructor_id,
        i.instructor_id i_instructor_id
   FROM section s, instructor i;
SET PAGESIZE 99
SET LINESIZE 230
--       Three Or More Table Joins

SELECT c.course_no, s.section_no, c.description,
        s.location, s.instructor_id
   FROM course c, section s
  WHERE c.course_no = s.course_no;

--       Three Or More Table Joins

SELECT c.course_no, s.section_no, c.description, s.location,
        s.instructor_id, i.last_name, i.first_name
   FROM course c, section s, instructor i
  WHERE c.course_no = s.course_no;

--       ANSI JOIN For Three And More Table Joins

SELECT c.course_no, s.section_no, c.description, s.location,
        s.instructor_id, i.last_name, i.first_name
   FROM course c JOIN section s
     ON (c.course_no = s.course_no);

SELECT course_no, s.section_no, c.description, s.location,
        instructor_id, i.last_name, i.first_name
   FROM course c JOIN section s
  USING (course_no);

--       Multicolumn Joins


SELECT student_id, section_id, grade_type_code type,
        grade_code_occurrence no,
        numeric_grade indiv_gr
   FROM grade
  WHERE student_id = 220
    AND section_id = 119;

--       Multicolumn Joins

SELECT g.student_id, g.section_id,
        g.grade_type_code type,
        g.grade_code_occurrence no,
        g.numeric_grade indiv_gr,
        TO_CHAR(e.enroll_date, 'MM/DD/YY') enrolldt
   FROM grade g, enrollment e
  WHERE g.student_id = 220
    AND g.section_id = 119
    AND g.student_id = e.student_id
    AND g.section_id = e.section_id;

--       Expressing Multicolumn Joins Using The ANSI JOIN Syntax

SELECT g.student_id, g.section_id,
        g.grade_type_code type,
        g.grade_code_occurrence no,
        g.numeric_grade indiv_gr,
        TO_CHAR(e.enroll_date, 'MM/DD/YY') enrolldt
   FROM grade g JOIN enrollment e
     ON (g.student_id = e.student_id
    AND g.section_id = e.section_id)
  WHERE g.student_id = 220
    AND g.section_id = 119;

--       Expressing Multicolumn Joins Using The ANSI JOIN Syntax

SELECT student_id, section_id,
        grade_type_code type,
        grade_code_occurrence no,
        numeric_grade indiv_gr,
        TO_CHAR(enroll_date, 'MM/DD/YY') enrolldt
   FROM grade JOIN enrollment
  USING (student_id, section_id)
  WHERE student_id = 220
    AND section_id = 119;

--      Ejercicios
--  	6.1.1. Escribir construcciones de unión simples

--  	a) Para todos los estudiantes, muestre el apellido, la ciudad, el estado y el código
--  		postal. Muestra el resultado ordenado por código postal.

SELECT s.last_name, s.zip, z.state, z.city
FROM student s, zipcode z
WHERE s.zip = z.zip
ORDER BY s.zip;

--  	b) Seleccione el nombre y apellido de todos los estudiantes inscritos y ordene por 
--  		apellido en orden ascendente.

SELECT s.first_name, s.last_name, s.student_id
FROM student s, enrollment e
WHERE s.student_id = e.student_id
ORDER BY s.last_name;

--  	6.1.2. Reduzca su conjunto de resultados

--  	a) Ejecute la siguiente instrucción SQL. Explique sus observaciones sobre la cláusula 
--  		WHERE y el resultado resultante.

--  	SELECT c.course_no, c.description, s.section_no
--  	FROM course c, section s
--  	WHERE c.course_no = s.course_no
--  	AND c.prerequisite IS NULL
--  	ORDER BY c.course_no, s.section_no

--  	Esta consulta incluye una condición de combinación y una condición que restringe las filas 
--  		a cursos que no tienen requisitos previos. El resultado está ordenado por el número de 
--  		curso y el número de sección.

--  	Las tablas COURSE y SECTION se unen para obtener la columna SECTION_NO. La combinación 
--  		requiere la igualdad de valores para las columnas COURSE_NO en ambas tablas. 
--  		Los cursos sin prerrequisito se determinan con el operador IS NULL. Si la consulta 
--  		se escribe con la sintaxis de combinación ANSI y la cláusula ON, verá una ventaja de 
--  		la sintaxis de combinación ANSI sobre la sintaxis de combinación tradicional. 
--  		La combinación ANSI distingue la condición de combinación de los criterios de filtrado.

--  	b) Seleccione la identificación del estudiante, el número de curso, la fecha de inscripción
--  		y la identificación de la sección para los estudiantes que se inscribieron en el 
--  		curso número 20 el 30 de enero de 2003.

SELECT s.student_id, c.course_no, TO_CHAR(s.enroll_date,'MM/DD/YYYY HH:MI PM'), s.section_id
FROM enrollment s JOIN section c
ON (s.section_id = c.section_id)
WHERE c.course_no = 20
AND s.enroll_date >= TO_DATE('01/30/2003','MM/DD/YYYY')
AND s.enroll_date < TO_DATE('01/31/2003','MM/DD/YYYY');

--  	Lab 6.1.3. Entender el producto cartesiano

--  	a) Seleccione los estudiantes e instructores que viven en el mismo código postal 
--  		uniéndose alcolumna ZIP común. Ordene el resultado por STUDENT_ID e INSTRUCTOR_ID 
--  		columnas. ¿Qué observas?

SELECT s.student_id, i.instructor_id, s.zip, i.zip
FROM student s, instructor i
WHERE s.zip = i.zip
ORDER BY s.student_id, i.instructor_id;

--  	Inicialmente, es posible que esta consulta y su resultado correspondiente no le parezca un 
--  		producto cartesiano porque la cláusula WHERE contiene un criterio de combinación. 
--  		Sin embargo, la relación entre la tabla ESTUDIANTE y INSTRUCTOR no sigue la ruta de 
--  		clave primaria / clave externa y, por lo tanto, es posible un producto cartesiano. 
--  		Una mirada al diagrama de esquema revela que no existe una relación de clave 
--  		primaria / clave externa entre las dos tablas. Para ilustrar mejor la relación de 
--  		varios a varios entre las columnas ZIP, seleccione los estudiantes e instructores 
--  		que viven en el código postal 10025 en diferentes sentencias SQL.

--  	6.2.1. Join Three or More Tables

--  	a) Muestre la identificación del estudiante, el número de curso y el número de sección de
--  		los estudiantes inscritos donde vive el instructor de la sección en el código postal 
--  		10025. Además, el curso no debe tener ningún requisito previo.

SELECT c.course_no, s.section_no, e.student_id
FROM course c, section s, instructor i, enrollment e
WHERE c.prerequisite IS NULL
AND c.course_no = s.course_no
AND s.instructor_id = i.instructor_id
AND i.zip = '10025'
AND s.section_id = e.section_id;

--  	b) Produzca las direcciones de correo de los instructores que impartieron las secciones 
--  		a partir de junio de 2003.

SELECT i.first_name || ' ' ||i.last_name name, i.street_address, 
		z.city || ', ' || z.state || ' ' || i.zip "City State Zip",
		TO_CHAR(s.start_date_time, 'MM/DD/YY') start_dt, section_id sect
FROM instructor i, section s, zipcode z
WHERE i.instructor_id = s.instructor_id
AND i.zip = z.zip
AND s.start_date_time >= TO_DATE('01-JUN-2003','DD-MON-YYYY')
AND s.start_date_time < TO_DATE('01-JUL-2003','DD-MON-YYYY');

--  	c) Enumere las identificaciones de los estudiantes matriculados que viven en Connecticut.

SELECT student_id
FROM student JOIN enrollment
USING (student_id)
JOIN zipcode
USING (zip)
WHERE state = 'CT';

--  	c) Muestra LAST_NAME, STUDENT_ID, PERCENT_OF_FINAL_GRADE, GRADE_TYPE_CODE y NUMERIC_GRADE
--  		columnas para los alumnos que recibieron 80 o menor para su proyecto de clase 
--  		(GRADE_TYPE_CODE = 'PJ'). Ordene el resultado por apellido del estudiante.

SELECT g.student_id, g.section_id, gw.percent_of_final_grade pct, g.grade_type_code,
		g.numeric_grade grade, s.last_name
FROM grade_type_weight gw, grade g, enrollment e, student s
WHERE g.grade_type_code = 'PJ'
AND gw.grade_type_code = g.grade_type_code
AND gw.section_id = g.section_id
AND g.numeric_grade <= 80
AND g.section_id = e.section_id
AND g.student_id = e.student_id
AND e.student_id = s.student_id
ORDER BY s.last_name;

spool off