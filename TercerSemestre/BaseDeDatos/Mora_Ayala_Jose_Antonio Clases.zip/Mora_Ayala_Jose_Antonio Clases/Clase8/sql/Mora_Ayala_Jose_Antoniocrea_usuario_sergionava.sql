spool F:\Base\Clases\crea_usuario_sergionava.txt
drop user sergionava cascade;
create user sergionava identified by sergionava
default tablespace users
temporary tablespace temp;


GRANT CONNECT, RESOURCE TO sergionava;

drop user sergionava on cascade;

GRANT CREATE ANY VIEW TO SERGIONAVA;