SPOOL C:\Users\ORA_bases\2020_09_02_clase_a\salida\ejer_completo.txt
rem crea la base student 
rem pausa
set flush off
set termout off
rem @@C:\Users\ORA_bases\2020_09_02_clase_a\crea_usuario.sql
@@C:\Users\ORA_bases\2020_09_02_clase_a\desp_par_session.sql
@@C:\Users\ORA_bases\2020_09_02_clase_a\cambia_idioma_fecha.sql
@@C:\Users\ORA_bases\2020_09_02_clase_a\instala_base_student.sql
rem @@C:\Users\ORA_bases\2020_09_02_clase_a\desinstala_base_student.sql
spool off

