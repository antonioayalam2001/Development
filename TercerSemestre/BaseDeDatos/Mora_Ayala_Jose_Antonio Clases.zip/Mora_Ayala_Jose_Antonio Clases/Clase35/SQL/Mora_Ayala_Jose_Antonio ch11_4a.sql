spool F:\Base\Clases\ch11_4a.txt

-- ch11_4a.sql
DECLARE
	v_sid student.student_id%TYPE;
	CURSOR c_student IS
	SELECT student_id
		FROM student
		WHERE student_id < 110;
BEGIN
	OPEN c_student;
	LOOP
		FETCH c_student INTO v_sid;
		EXIT WHEN c_student%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(' ID ESTUDIANTE: '||v_sid);
	END LOOP;
		CLOSE c_student;
	EXCEPTION
	WHEN OTHERS
	THEN
	IF c_student%ISOPEN
		THEN
			CLOSE c_student;
	END IF;
END;
/

REM ESCENARIO DOS 
DECLARE
	v_sid student.student_id%TYPE;
	CURSOR c_student IS
	SELECT student_id
		FROM student
		WHERE student_id < 110;
BEGIN
	OPEN c_student;
	LOOP
		FETCH c_student INTO v_sid;
		EXIT WHEN c_student%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(' ID ESTUDIANTE: '||v_sid);
	END LOOP;
		CLOSE c_student;
	DBMS_OUTPUT.PUT_LINE ('Final YA'||chr(13)||chr(10)||chr(10)||
	' Termine'||chr(07)||chr(07)||chr(07));
	EXCEPTION
	WHEN OTHERS
	THEN
	IF c_student%ISOPEN
		THEN
			CLOSE c_student;
	END IF;
END;
/
spool off;	