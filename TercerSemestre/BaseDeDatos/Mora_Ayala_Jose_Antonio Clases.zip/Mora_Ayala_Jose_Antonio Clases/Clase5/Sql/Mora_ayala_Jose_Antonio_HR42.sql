spool  %ORA_OUT%\s42.txt
rem script HR42.sql
rem despliega atributos de la tabla employees del esquema HR
select employee_id, first_name, salary, salary*12
    from employees
    where salary*12 > 2400 and
    	   employee_id between 185 and 200;  
spool off