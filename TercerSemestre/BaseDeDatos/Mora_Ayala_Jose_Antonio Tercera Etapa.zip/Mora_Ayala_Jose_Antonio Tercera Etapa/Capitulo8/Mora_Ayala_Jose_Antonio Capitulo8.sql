spool F:\Documents\BasedeDatos\Capitulo8MO\Capitulo8MO.txt

--  =======================================================================================
--  ||Capitulo 8 Ejercicios Mastering Oracle SQL                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Mastering Oracle SQL                             ||
--* ||by Sanjay Mishra and Alan Beaulieu                                                ||
--* ||Copyright © 2002 O’Reilly & Associates, Inc. All rights reserved.                 ||
--* ||Printed in the United States of America.                                          ||
--* ||Published by O’Reilly & Associates, Inc., 1005 Gravenstein Highway North,         ||
--* ||Sebastopol, CA 95472.                                                             ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 8 Mastering Oracle SQL'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 210
Connect MasterOracle/MasterOracle;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos MasterOracle
show user;
--  Conociendo nuestras tablas 
desc Customer;

--Hierarchical Queries

--Considerando la creacion de la siguiente tabla
--CREATE TABLE EMPLOYEE (
--EMP_ID NUMBER (4) CONSTRAINT EMP_PK PRIMARY KEY,
--FNAME VARCHAR2 (15)NOT NULL,
--LNAME VARCHAR2 (15)NOT NULL,
--DEPT_ID NUMBER (2)NOT NULL,
--MANAGER_EMP_ID NUMBER (4) CONSTRAINT EMP_FK REFERENCES EMPLOYEE(EMP_ID),
--SALARY NUMBER (7,2)NOT NULL,
--HIRE_DATE DATENOT NULL,
--JOB_ID NUMBER (3));

--Es de duma importancia considerar que hay dos aspectos importantes a considerar
--La columna MANAGER_EMP_ID hace referencia a otra columna en la tabla
--EMP_ID es una llave foranea
SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE;

--Finding the Root Node
--Aquella que no tiene un padre
SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE
WHERE MANAGER_EMP_ID IS NULL;

--Finding a Node’s Immediate Parent
SELECT E.LNAME "Employee", M.LNAME "Manager"
FROM EMPLOYEE E, EMPLOYEE M
WHERE E.MANAGER_EMP_ID = M.EMP_ID;

--Pero notamos que empleado tiene 14 filas
SELECT COUNT(*) FROM EMPLOYEE;

--La razon es que como ese query lista los empleados con su manager correpsondiente y uno
--no posee (hay un valor nulo) solo devuelve 13 filas

--Finding Leaf Nodes
--Aquellos que no tienen hijos. Empleados que no se encargan de nadie 
SELECT * FROM EMPLOYEE
WHERE EMP_ID NOT IN (SELECT MANAGER_EMP_ID FROM EMPLOYEE);

--Devuelve una seleccion nula de filas debido a que MANAGER_EMP_ID contiene un valor nulo en una fila 
--y como ya sabemos los valores nulos no son candidatos a ser comparados

SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE E
WHERE EMP_ID NOT IN
(SELECT MANAGER_EMP_ID FROM EMPLOYEE
WHERE MANAGER_EMP_ID IS NOT NULL);

--Otra forma de escribir el query anterior seria 
SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE E
WHERE NOT EXISTS
(SELECT EMP_ID FROM EMPLOYEE E1 WHERE E.EMP_ID = E1.MANAGER_EMP_ID);

--Oracle SQL Extensions
SELECT E_TOP.LNAME, E_2.LNAME, E_3.LNAME, E_4.LNAME
FROM EMPLOYEE E_TOP, EMPLOYEE E_2, EMPLOYEE E_3, EMPLOYEE E_4
WHERE E_TOP.MANAGER_EMP_ID IS NULL
AND E_TOP.EMP_ID = E_2.MANAGER_EMP_ID (+)
AND E_2.EMP_ID = E_3.MANAGER_EMP_ID (+)
AND E_3.EMP_ID = E_4.MANAGER_EMP_ID (+);

--START WITH...CONNECT BY and PRIOR
--[[START WITH condition1] CONNECT BY condition2]

SELECT LNAME, EMP_ID, MANAGER_EMP_ID
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY PRIOR EMP_ID = MANAGER_EMP_ID;

--The LEVEL Pseudocolumn
SELECT LEVEL, LNAME, EMP_ID, MANAGER_EMP_ID
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID;

--Finding the Number of Levels
SELECT COUNT(DISTINCT LEVEL)
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY PRIOR EMP_ID = MANAGER_EMP_ID;

--Determinando el numero de empleados en cada nivel. agrupando los resultados por nivel
--y contar los empleados en cada grupo distinto

SELECT LEVEL, COUNT(EMP_ID)
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY PRIOR EMP_ID = MANAGER_EMP_ID
GROUP BY LEVEL;

SET PAGESIZE 200
SET LINESIZE 100

--Listing Records in Hierarchical Order
--Con LPAD somos capaces de alinear la columna de nombres de acerdo al nivel que poseen
SELECT LEVEL, LPAD(' ',2*(LEVEL - 1)) || LNAME "EMPLOYEE",
EMP_ID, MANAGER_EMP_ID
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY PRIOR EMP_ID = MANAGER_EMP_ID;

--Si ahora queremos obtener solo la información con respecto a JONES podemos hacer lo siguiente
SELECT LEVEL, LPAD(' ',2*(LEVEL - 1)) || LNAME "EMPLOYEE",
EMP_ID, MANAGER_EMP_ID, SALARY
FROM EMPLOYEE
START WITH LNAME = 'JONES'
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID;

--Checking for Ascendancy
--Estamos comprobando el orden que poseen por ejemplo, Blake esta por encima de Jones, obtendremos
--una seleccion nula de filas por lo que podemos realizar otra consulta
--El subarbol creado para Jones donde mediante la clausula where filtramos para encontrar a Blake 
--no genera resultados
SELECT *
FROM EMPLOYEE
WHERE LNAME = 'BLAKE'
START WITH LNAME = 'JONES'
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID;
--Ahora vemos si JONES tiene alguna autoridad sobre SMITH
SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE
WHERE LNAME = 'SMITH'
START WITH LNAME = 'JONES'
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID;

--Deleting a Subtree
DELETE FROM EMPLOYEE
WHERE EMP_ID IN
(SELECT EMP_ID FROM EMPLOYEE
START WITH LNAME = 'JONES'
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID);

--Listing Multiple Root Nodes
SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID
AND DEPT_ID != PRIOR DEPT_ID;

--Listing the Top Few Levels of a Hierarchy
SELECT EMP_ID, LNAME, DEPT_ID, MANAGER_EMP_ID, SALARY, HIRE_DATE
FROM EMPLOYEE
WHERE LEVEL <= 2
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID;

--Aggregating a Hierarchy
SELECT SUM(SALARY)
FROM EMPLOYEE
START WITH LNAME = 'JONES'
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID;

--

SELECT LNAME, SALARY,
(SELECT SUM(SALARY) FROM EMPLOYEE T1
START WITH LNAME = T2.LNAME
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID) SUM_SALARY
FROM EMPLOYEE T2;

--Restrictions on Hierarchical Queries
--No puede usar un JOIN
--No puede seleccionar datos que involucren un JOIN

SELECT LEVEL, LPAD(' ',2*(LEVEL - 1)) || LNAME "EMPLOYEE",
EMP_ID, MANAGER_EMP_ID, SALARY
FROM EMPLOYEE
START WITH MANAGER_EMP_ID IS NULL
CONNECT BY MANAGER_EMP_ID = PRIOR EMP_ID
ORDER BY SALARY;

spool off;