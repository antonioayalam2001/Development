spool %ORA_ARG_SAL%\sal_creaBook.txt
@@%ORA_ARG%\dbbook.sql
spool off
SET 
SET ORA_ARG_SCRIPTS=C:\Users\Admin\Documents\BASES_ARGENTINA\dbbook
set ORA_ARG_SAL=C:\Users\Admin\Documents\BASES_ARGENTINA\dbbook\salida
%ORA_HOME%\	bin\
sqlldr SERGIO10/SERGIO10
		control='%ORA_ARG_SCRIPTS%\faculty.ctl  log='%ORA_ARG_SAL%\faculty.log'