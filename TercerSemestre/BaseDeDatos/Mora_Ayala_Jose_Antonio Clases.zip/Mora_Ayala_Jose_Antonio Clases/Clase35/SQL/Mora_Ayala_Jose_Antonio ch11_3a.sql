spool F:\Base\Clases\ch11_3a.txt

-- ch11_3a.sql
SET SERVEROUTPUT ON
DECLARE
	v_city zipcode.city%type;
BEGIN
	SELECT city
	INTO v_city
	FROM zipcode
	WHERE zip = 07002;
		IF SQL%ROWCOUNT = 1
		THEN
			DBMS_OUTPUT.PUT_LINE(v_city ||' has a '||
				'zipcode of 07002');
		ELSIF SQL%ROWCOUNT = 0
		THEN
			DBMS_OUTPUT.PUT_LINE('The zipcode 07002 is '||
			' not in the database');
		ELSE
			DBMS_OUTPUT.PUT_LINE('Stop harassing me');
		END IF;
END;
/

REM CONSULTAS PREVIAS 
REM SOLO HAY UN CODIGO POSTAL 07002 
SELECT ZIP,city,STATE
	FROM zipcode
	WHERE zip = 07002;

spool off;