spool F:\Base\Clases\ch11_2a.txt

-- ch11_2a.sql
SET SERVEROUTPUT ON
DECLARE
	CURSOR c_zip IS
	SELECT *
	FROM zipcode;
	vr_zip c_zip%ROWTYPE;
BEGIN
	OPEN c_zip;
	LOOP
		FETCH c_zip INTO vr_zip;
		EXIT WHEN c_zip%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(vr_zip.zip||
			' '||vr_zip.city||' '||vr_zip.state);
	END LOOP;
END;
/

REM CONSULTA PREVIA 
SELECT ROWNUM,ZIP,CITY,STATE
	FROM zipcode;

SELECT COUNT(*) FROM ZIPCODE;

SELECT ZIP FROM ZIPCODE
WHERE ROWNUM <= 20;

REM ESCENARIO DOS
--* CURSOR EXPLICITO

DECLARE
	CURSOR c_zip_2 IS
	SELECT *
	FROM zipcode
	WHERE ROWNUM <= 20;
	vr_zip c_zip_2%ROWTYPE;	
BEGIN
	OPEN c_zip_2;
	LOOP
		FETCH c_ziP_2 INTO vr_zip;
		EXIT WHEN c_zip_2%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(CHR(9)||vr_zip.zip||
			'  =>'||CHR(9)||vr_zip.city||' '||vr_zip.state);
	END LOOP;
END;
/

rem escenario 3
rem odernar las columnas antes de llevarlas al cursor 
rem agregarle al final un sonido de bell chr(7)
rem agregar un tablulador vertical chr(9) 
rem agregar el carrige return chr(13)
rem agregar el salto de linea chr (10)
DECLARE
	CURSOR c_zip_2 IS
	SELECT *
	FROM zipcode
	WHERE ROWNUM <= 20 order by 2;
	vr_zip c_zip_2%ROWTYPE;	
BEGIN
	OPEN c_zip_2;
	LOOP
		FETCH c_ziP_2 INTO vr_zip;
		EXIT WHEN c_zip_2%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE(CHR(9)||vr_zip.zip||
			'  =>'||CHR(9)||vr_zip.city||' '||CHR(9)||vr_zip.state);
	END LOOP;
	 DBMS_OUTPUT.PUT_LINE ('Final'||chr(13)||chr(10)||chr(10)||
	 ' Termine'||chr(07)||chr(07)||chr(07));
END;
/

spool off;