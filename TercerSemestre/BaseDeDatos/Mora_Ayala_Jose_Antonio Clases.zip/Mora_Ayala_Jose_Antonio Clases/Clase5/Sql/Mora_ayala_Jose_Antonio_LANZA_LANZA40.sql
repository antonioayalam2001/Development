spool  %ORA_OUT%\lanzalanza.txt
@%ORA_IN%\lanzador40.sql
spool off