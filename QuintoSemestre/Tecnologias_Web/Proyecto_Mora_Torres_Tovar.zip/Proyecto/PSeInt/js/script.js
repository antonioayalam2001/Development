//Aqui Ponemos el codigo general de la pagina
//Si necesitamos crear mas .js los creamos

/////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/**
* vkBeautify - javascript plugin to pretty-print or minify text in XML, JSON, CSS and SQL formats.
*  
* Version - 0.99.00.beta 
* Copyright (c) 2012 Vadim Kiryukhin
* vkiryukhin @ gmail.com
* http://www.eslinstructor.net/vkbeautify/
* 
* MIT license:
*   http://www.opensource.org/licenses/mit-license.php
*
*   Pretty print
*
*        vkbeautify.xml(text [,indent_pattern]);
*        vkbeautify.json(text [,indent_pattern]);
*        vkbeautify.css(text [,indent_pattern]);
*        vkbeautify.sql(text [,indent_pattern]);
*
*        @text - String; text to beatufy;
*        @indent_pattern - Integer | String;
*                Integer:  number of white spaces;
*                String:   character string to visualize indentation ( can also be a set of white spaces )
*   Minify
*
*        vkbeautify.xmlmin(text [,preserve_comments]);
*        vkbeautify.jsonmin(text);
*        vkbeautify.cssmin(text [,preserve_comments]);
*        vkbeautify.sqlmin(text);
*
*        @text - String; text to minify;
*        @preserve_comments - Bool; [optional];
*                Set this flag to true to prevent removing comments from @text ( minxml and mincss functions only. )
*
*   Examples:
*        vkbeautify.xml(text); // pretty print XML
*        vkbeautify.json(text, 4 ); // pretty print JSON
*        vkbeautify.css(text, '. . . .'); // pretty print CSS
*        vkbeautify.sql(text, '----'); // pretty print SQL
*
*        vkbeautify.xmlmin(text, true);// minify XML, preserve comments
*        vkbeautify.jsonmin(text);// minify JSON
*        vkbeautify.cssmin(text);// minify CSS, remove comments ( default )
*        vkbeautify.sqlmin(text);// minify SQL
*
*/

(function() {

function createShiftArr(step) {

  var space = '    ';
  
  if ( isNaN(parseInt(step)) ) {  // argument is string
    space = step;
  } else { // argument is integer
    switch(step) {
      case 1: space = ' '; break;
      case 2: space = '  '; break;
      case 3: space = '   '; break;
      case 4: space = '    '; break;
      case 5: space = '     '; break;
      case 6: space = '      '; break;
      case 7: space = '       '; break;
      case 8: space = '        '; break;
      case 9: space = '         '; break;
      case 10: space = '          '; break;
      case 11: space = '           '; break;
      case 12: space = '            '; break;
    }
  }

  var shift = ['\n']; // array of shifts
  for(ix=0;ix<100;ix++){
    shift.push(shift[ix]+space); 
  }
  return shift;
}

function vkbeautify(){
  this.step = '\t'; // 4 spaces
  this.shift = createShiftArr(this.step);
};

vkbeautify.prototype.xml = function(text,step) {

  var ar = text.replace(/>\s{0,}</g,"><")
         .replace(/</g,"~::~<")
         .replace(/\s*xmlns\:/g,"~::~xmlns:")
         .replace(/\s*xmlns\=/g,"~::~xmlns=")
         .split('~::~'),
    len = ar.length,
    inComment = false,
    deep = 0,
    str = '',
    ix = 0,
    shift = step ? createShiftArr(step) : this.shift;

    for(ix=0;ix<len;ix++) {
      // start comment or <![CDATA[...]]> or <!DOCTYPE //
      if(ar[ix].search(/<!/) > -1) { 
        str += shift[deep]+ar[ix];
        inComment = true; 
        // end comment  or <![CDATA[...]]> //
        if(ar[ix].search(/-->/) > -1 || ar[ix].search(/\]>/) > -1 || ar[ix].search(/!DOCTYPE/) > -1 ) { 
          inComment = false; 
        }
      } else 
      // end comment  or <![CDATA[...]]> //
      if(ar[ix].search(/-->/) > -1 || ar[ix].search(/\]>/) > -1) { 
        str += ar[ix];
        inComment = false; 
      } else 
      // <elm></elm> //
      if( /^<\w/.exec(ar[ix-1]) && /^<\/\w/.exec(ar[ix]) &&
        /^<[\w:\-\.\,]+/.exec(ar[ix-1]) == /^<\/[\w:\-\.\,]+/.exec(ar[ix])[0].replace('/','')) { 
        str += ar[ix];
        if(!inComment) deep--;
      } else
       // <elm> //
      if(ar[ix].search(/<\w/) > -1 && ar[ix].search(/<\//) == -1 && ar[ix].search(/\/>/) == -1 ) {
        str = !inComment ? str += shift[deep++]+ar[ix] : str += ar[ix];
      } else 
       // <elm>...</elm> //
      if(ar[ix].search(/<\w/) > -1 && ar[ix].search(/<\//) > -1) {
        str = !inComment ? str += shift[deep]+ar[ix] : str += ar[ix];
      } else 
      // </elm> //
      if(ar[ix].search(/<\//) > -1) { 
        str = !inComment ? str += shift[--deep]+ar[ix] : str += ar[ix];
      } else 
      // <elm/> //
      if(ar[ix].search(/\/>/) > -1 ) { 
        str = !inComment ? str += shift[deep]+ar[ix] : str += ar[ix];
      } else 
      // <? xml ... ?> //
      if(ar[ix].search(/<\?/) > -1) { 
        str += shift[deep]+ar[ix];
      } else 
      // xmlns //
      if( ar[ix].search(/xmlns\:/) > -1  || ar[ix].search(/xmlns\=/) > -1) { 
        str += shift[deep]+ar[ix];
      } 
      
      else {
        str += ar[ix];
      }
    }
    
  return  (str[0] == '\n') ? str.slice(1) : str;
}

vkbeautify.prototype.json = function(text,step) {

  var step = step ? step : this.step;
  
  if (typeof JSON === 'undefined' ) return text; 
  
  if ( typeof text === "string" ) return JSON.stringify(JSON.parse(text), null, step);
  if ( typeof text === "object" ) return JSON.stringify(text, null, step);
    
  return text; // text is not string nor object
}

vkbeautify.prototype.css = function(text, step) {

  var ar = text.replace(/\s{1,}/g,' ')
        .replace(/\{/g,"{~::~")
        .replace(/\}/g,"~::~}~::~")
        .replace(/\;/g,";~::~")
        .replace(/\/\*/g,"~::~/*")
        .replace(/\*\//g,"*/~::~")
        .replace(/~::~\s{0,}~::~/g,"~::~")
        .split('~::~'),
    len = ar.length,
    deep = 0,
    str = '',
    ix = 0,
    shift = step ? createShiftArr(step) : this.shift;
    
    for(ix=0;ix<len;ix++) {

      if( /\{/.exec(ar[ix]))  { 
        str += shift[deep++]+ar[ix];
      } else 
      if( /\}/.exec(ar[ix]))  { 
        str += shift[--deep]+ar[ix];
      } else
      if( /\*\\/.exec(ar[ix]))  { 
        str += shift[deep]+ar[ix];
      }
      else {
        str += shift[deep]+ar[ix];
      }
    }
    return str.replace(/^\n{1,}/,'');
}

//----------------------------------------------------------------------------

function isSubquery(str, parenthesisLevel) {
  return  parenthesisLevel - (str.replace(/\(/g,'').length - str.replace(/\)/g,'').length )
}

function split_sql(str, tab) {

  return str.replace(/\s{1,}/g," ")

        .replace(/ AND /ig,"~::~"+tab+tab+"AND ")
        .replace(/ BETWEEN /ig,"~::~"+tab+"BETWEEN ")
        .replace(/ CASE /ig,"~::~"+tab+"CASE ")
        .replace(/ ELSE /ig,"~::~"+tab+"ELSE ")
        .replace(/ END /ig,"~::~"+tab+"END ")
        .replace(/ FROM /ig,"~::~FROM ")
        .replace(/ GROUP\s{1,}BY/ig,"~::~GROUP BY ")
        .replace(/ HAVING /ig,"~::~HAVING ")
        //.replace(/ SET /ig," SET~::~")
        .replace(/ IN /ig," IN ")
        
        .replace(/ JOIN /ig,"~::~JOIN ")
        .replace(/ CROSS~::~{1,}JOIN /ig,"~::~CROSS JOIN ")
        .replace(/ INNER~::~{1,}JOIN /ig,"~::~INNER JOIN ")
        .replace(/ LEFT~::~{1,}JOIN /ig,"~::~LEFT JOIN ")
        .replace(/ RIGHT~::~{1,}JOIN /ig,"~::~RIGHT JOIN ")
        
        .replace(/ ON /ig,"~::~"+tab+"ON ")
        .replace(/ OR /ig,"~::~"+tab+tab+"OR ")
        .replace(/ ORDER\s{1,}BY/ig,"~::~ORDER BY ")
        .replace(/ OVER /ig,"~::~"+tab+"OVER ")

        .replace(/\(\s{0,}SELECT /ig,"~::~(SELECT ")
        .replace(/\)\s{0,}SELECT /ig,")~::~SELECT ")
        
        .replace(/ THEN /ig," THEN~::~"+tab+"")
        .replace(/ UNION /ig,"~::~UNION~::~")
        .replace(/ USING /ig,"~::~USING ")
        .replace(/ WHEN /ig,"~::~"+tab+"WHEN ")
        .replace(/ WHERE /ig,"~::~WHERE ")
        .replace(/ WITH /ig,"~::~WITH ")
        
        //.replace(/\,\s{0,}\(/ig,",~::~( ")
        //.replace(/\,/ig,",~::~"+tab+tab+"")

        .replace(/ ALL /ig," ALL ")
        .replace(/ AS /ig," AS ")
        .replace(/ ASC /ig," ASC ") 
        .replace(/ DESC /ig," DESC ") 
        .replace(/ DISTINCT /ig," DISTINCT ")
        .replace(/ EXISTS /ig," EXISTS ")
        .replace(/ NOT /ig," NOT ")
        .replace(/ NULL /ig," NULL ")
        .replace(/ LIKE /ig," LIKE ")
        .replace(/\s{0,}SELECT /ig,"SELECT ")
        .replace(/\s{0,}UPDATE /ig,"UPDATE ")
        .replace(/ SET /ig," SET ")
              
        .replace(/~::~{1,}/g,"~::~")
        .split('~::~');
}

vkbeautify.prototype.sql = function(text,step) {

  var ar_by_quote = text.replace(/\s{1,}/g," ")
              .replace(/\'/ig,"~::~\'")
              .split('~::~'),
    len = ar_by_quote.length,
    ar = [],
    deep = 0,
    tab = this.step,//+this.step,
    inComment = true,
    inQuote = false,
    parenthesisLevel = 0,
    str = '',
    ix = 0,
    shift = step ? createShiftArr(step) : this.shift;;

    for(ix=0;ix<len;ix++) {
      if(ix%2) {
        ar = ar.concat(ar_by_quote[ix]);
      } else {
        ar = ar.concat(split_sql(ar_by_quote[ix], tab) );
      }
    }
    
    len = ar.length;
    for(ix=0;ix<len;ix++) {
      
      parenthesisLevel = isSubquery(ar[ix], parenthesisLevel);
      
      if( /\s{0,}\s{0,}SELECT\s{0,}/.exec(ar[ix]))  { 
        ar[ix] = ar[ix].replace(/\,/g,",\n"+tab+tab+"")
      } 
      
      if( /\s{0,}\s{0,}SET\s{0,}/.exec(ar[ix]))  { 
        ar[ix] = ar[ix].replace(/\,/g,",\n"+tab+tab+"")
      } 
      
      if( /\s{0,}\(\s{0,}SELECT\s{0,}/.exec(ar[ix]))  { 
        deep++;
        str += shift[deep]+ar[ix];
      } else 
      if( /\'/.exec(ar[ix]) )  { 
        if(parenthesisLevel<1 && deep) {
          deep--;
        }
        str += ar[ix];
      }
      else  { 
        str += shift[deep]+ar[ix];
        if(parenthesisLevel<1 && deep) {
          deep--;
        }
      } 
      var junk = 0;
    }

    str = str.replace(/^\n{1,}/,'').replace(/\n{1,}/g,"\n");
    return str;
}


vkbeautify.prototype.xmlmin = function(text, preserveComments) {

  var str = preserveComments ? text
                 : text.replace(/\<![ \r\n\t]*(--([^\-]|[\r\n]|-[^\-])*--[ \r\n\t]*)\>/g,"")
                   .replace(/[ \r\n\t]{1,}xmlns/g, ' xmlns');
  return  str.replace(/>\s{0,}</g,"><"); 
}

vkbeautify.prototype.jsonmin = function(text) {

  if (typeof JSON === 'undefined' ) return text; 
  
  return JSON.stringify(JSON.parse(text), null, 0); 
        
}

vkbeautify.prototype.cssmin = function(text, preserveComments) {
  
  var str = preserveComments ? text
                 : text.replace(/\/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+\//g,"") ;

  return str.replace(/\s{1,}/g,' ')
        .replace(/\{\s{1,}/g,"{")
        .replace(/\}\s{1,}/g,"}")
        .replace(/\;\s{1,}/g,";")
        .replace(/\/\*\s{1,}/g,"/*")
        .replace(/\*\/\s{1,}/g,"*/");
}

vkbeautify.prototype.sqlmin = function(text) {
  return text.replace(/\s{1,}/g," ").replace(/\s{1,}\(/,"(").replace(/\s{1,}\)/,")");
}

window.vkbeautify = new vkbeautify();

})();


/////////////////////////////////////////////////////////////////////////////////////////

var canvas = document.getElementById('canvas');
var ctx = canvas.getContext('2d');
var ctx2= canvas.getContext('2d');
var ch = canvas.width;
var coordenadax=155;
var coordenaday=75;
var coordenadayt=90;
var coordenadaxt=255;

function dibujarinicio(){

  var centrox=ch/2, radioX = 50, radioY = 20, rotacion=0, ap = 0, af = 2*Math.PI, cR = true;
  ctx.beginPath();
  ctx.fillStyle = "pink";
  ctx.ellipse(centrox, 35, radioX, radioY, rotacion, ap, af, cR);
  ctx.fill();
  ctx.font = '16px Gill Sans';
  ctx.fillStyle = 'white';
  ctx.fillText('INICIO', 225, 40);
  ctx.closePath();
  ctx.beginPath();
  ctx.moveTo(250, 53);
  ctx.lineTo(250, 64);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(258, 54);
  ctx.lineTo(250, 60);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(240, 54);
  ctx.lineTo(250, 60);
  ctx.stroke();
}

function dibujarfin(){

  var canvas1 = document.getElementById('canvas');
  var ctx3 = canvas1.getContext('2d');
  var centrox=ch/2, radioX = 50, radioY = 20, rotacion=0, ap = 0, af = 2*Math.PI, cR = true;
  ctx.beginPath();
  ctx3.fillStyle = "red";
  ctx3.ellipse(centrox, 470, radioX, radioY, rotacion, ap, af, cR);
  ctx3.fill();
  ctx3.font = '16px Gill Sans';
  ctx3.fillStyle = '#FFFFFF';
  ctx3.fillText('FIN',235,472);
}

function compilar(){

  var palabra=document.getElementById("norm").value;
  var palabra1=document.getElementById("indi").value;
  var palabra2=document.getElementById("indi1").value;
  var palabra3=document.getElementById("indif").value;
  var palabraz=document.getElementById("p1").value;
  var palabrax=document.getElementById("p2").value;
  var palabray=document.getElementById("p3").value;
  var estructura=document.getElementById("menu").value

  if(estructura=='1'){
  document.formu.texto.value += 'void(main){\n'+'int '+palabra+';\n'+'printf("'+palabra1+'");\n'+'scanf("'+palabra2+'");\n\n'+'if('+palabraz+'){\n'+'printf("'+palabrax+'");\n'+'}\n'+'else{\n'+'printf("'+palabray+'");\n}\n'+'printf("'+palabra3+'");\n}';
  }

  if(estructura=='2'){
  document.formu.texto.value += 'void(main){\n'+'int '+palabra+';\n'+'printf("'+palabra1+'");\n'+'scanf("'+palabra2+'");\n\n'+'while('+palabraz+'){\n'+'printf("'+palabrax+'");\n'+'}\n'+'printf("'+palabra3+'");\n}';
  }

  if(estructura=='3'){
  document.formu.texto.value += 'void(main){\n'+'int '+palabra+';\n'+'printf("'+palabra1+'");\n'+'scanf("'+palabra2+'")\n\n'+'for(int i='+palabraz+';i<='+palabrax+';i++){\n'+'printf("'+palabray+'");\n}'+'printf("'+palabra3+'");\n}';
  }
}

function dibujar(){

  var color=document.getElementById("color").value
  var palabra = document.getElementById("norm").value;
  ctx.beginPath();
  ctx.fillStyle =color;
  ctx.lineWidth = 4;
  ctx.strokeStyle = 'black';
  ctx.rect(206, 60, 90, 10);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.rect(206, 100, 90, 20);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.beginPath();
  ctx.rect(206,68, 90, 40);
  ctx.fillStyle = color
  ctx.stroke();
  ctx.fill()
  ctx.closePath();
  ctx.fillStyle = 'white';
  ctx.font = "16px Gill Sans";
  ctx.fillText('' + palabra + '', 220, 90);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(250, 122);
  ctx.lineTo(250, 129);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(258, 122);
  ctx.lineTo(250, 130);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(240, 122);
  ctx.lineTo(250, 130);
  ctx.stroke();
}

function dibujarindicacion(){

  var color1=document.getElementById("color1").value
  var palabra1=document.getElementById("indi").value;  
  ctx.fillStyle =color1;
  ctx.fillRect(207,130,100,45);
  ctx.fillStyle = '#FFFFFF';  
  ctx.beginPath();
  ctx.arc(232.8, 163, 24, 0,Math.PI);
  ctx.fillStyle = color1;
  ctx.fill();
  ctx.lineWidth = 5;
  ctx.strokeStyle = color1;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(283, 190, 32, Math.PI,0);
  ctx.fillStyle = "white";
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = color1;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(256, 175);
  ctx.lineTo(256, 191);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(262, 180);
  ctx.lineTo(256, 191);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(248, 180);
  ctx.lineTo(256, 191);
  ctx.stroke();
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabra1+'',217,140);
}

function dibujarescan(){

  var color2=document.getElementById("color2").value
  var palabra2 = document.getElementById("indi1").value;
  ctx.lineWidth = 2;
  ctx.strokeStyle = color2;
  ctx.beginPath();
  ctx.rect(207, 192, 100, 35);
  ctx.fillStyle = color2
  ctx.stroke();
  ctx.fill()
  ctx.closePath();
  ctx.fillStyle = 'white';
  ctx.font = "16px Gill Sans";
  ctx.fillText('' + palabra2 + '', 233, 211);
}

function dibujarindif(){

  var color3=document.getElementById("color4").value
  var palabra3=document.getElementById("indif").value;
  ctx.fillStyle = color3;
  ctx.beginPath();
  ctx.lineWidth = 4;
  ctx.strokeStyle = 'black';
  ctx.rect(206, 310, 100, 10);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.rect(206, 380, 100, 20);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.beginPath();
  ctx.rect(206,320, 100, 70);
  ctx.fillStyle = color3
  ctx.stroke();
  ctx.fill()
  ctx.closePath();
  ctx.fillStyle = 'white';
  ctx.font = "16px Gill Sans";
  ctx.fillText('' + palabra3 + '', 242, 360);
  
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(256, 407);
  ctx.lineTo(256, 447);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(256, 447);
  ctx.lineTo(266, 442);
  ctx.stroke();    
  ctx.beginPath();
  ctx.moveTo(256, 447);
  ctx.lineTo(246, 442);
  ctx.stroke();
  
}

function dibujarest(){

  var colorz=document.getElementById("color3").value
  var palabraz=document.getElementById("p1").value;
  var palabrax=document.getElementById("p2").value;
  var palabray=document.getElementById("p3").value;
  var estructura=document.getElementById("menu").value
      
  if (estructura == '1') {

    ctx2.fillStyle = colorz;
    ctx2.beginPath();
    ctx2.moveTo(255, 230);
    ctx2.lineTo(190,265);
    ctx2.lineTo(255, 305);
    ctx2.lineTo(320, 265);
    ctx2.closePath();
    ctx2.fill();

    ctx.fillStyle =color2;
    ctx.fillRect(66,247,90,35);
    ctx.fillStyle =color2;
    ctx.fillRect(366,247,90,35);   
         
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabraz+'',89,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabrax+'',228,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabray+'',393,265);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(174, 267);
    ctx.lineTo(156, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 260);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 273);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(348, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(360, 260);
    ctx.stroke();    
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(358, 274);
    ctx.stroke();
  }

  if(estructura=='2'){

    ctx.fillStyle = "#4c004f";
    ctx.beginPath();
    ctx.moveTo(204,225);
    ctx.lineTo(300, 225);
    ctx.lineTo(321,265);
    ctx.lineTo(300, 305);
    ctx.lineTo(204, 305);
    ctx.lineTo(180, 265);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle =colorz;
    ctx.fillRect(66,247,90,35);
    ctx.fillStyle =colorz;
    ctx.fillRect(366,247,90,35);   
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabraz+'',89,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabrax+'',228,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText('' + palabray + '', 393, 265);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(174, 267);
    ctx.lineTo(156, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 260);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 273);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(348, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(360, 260);
    ctx.stroke();    
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(358, 274);
    ctx.stroke();
  }

  if(estructura=='3'){

    ctx.fillStyle = "#1565C0";
    ctx.beginPath();
    ctx.moveTo(215,240);
    ctx.lineTo(305,240);
    ctx.lineTo(330,300); 
    ctx.lineTo(194,300);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle =colorz;
    ctx.fillRect(66,247,90,35);
    ctx.fillStyle =colorz;
    ctx.fillRect(366,247,90,35);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabraz+'',89,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabrax+'',228,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText('' + palabray + '', 393, 265);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(348, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(360, 260);
    ctx.stroke();    
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(358, 274);
    ctx.stroke();
  }
}

function borrar(){

  ctx.clearRect(0, 0, 1000, 3000);
  document.getElementById("ide").value="";
  coordenadax=400;
  coordenaday=75;
  coordenadayt=90;
  coordenadaxt=470;
}

function guardado(){

  var nombreDiagrama = prompt("Inserte el nombre del diagrama");

  var diagramaValue = {

    "variable" : document.getElementById("norm").value,
    "colorVariable" : document.getElementById("color").value,

    "variableScan" : document.getElementById("indi").value,
    "scanColor" : document.getElementById("color1").value,

    "variableAsig" : document.getElementById("indi1").value,
    "asignColor" : document.getElementById("color2").value,

    "valStruct" : document.getElementById("menu").value,
    "palabraz" : document.getElementById("p1").value,
    "palabrax" : document.getElementById("p2").value,
    "palabray" : document.getElementById("p3").value,
    "colorStruct" : document.getElementById("color3").value,

    "final" : document.getElementById("indif").value,
    "valif" : document.getElementById("color4").value
  };

  var diagramaJSON = JSON.stringify(diagramaValue, null, 2);

  localStorage.setItem(nombreDiagrama, diagramaJSON);

  var xXMMLL = new X2JS();

  var nuevoXML = xXMMLL.json2xml_str(JSON.parse(diagramaJSON));
  var bonito = vkbeautify.xml(nuevoXML, 4);

  console.log(bonito);
      
  alert("TU DIAGRAMA SE HA GUARDADO");
}

function cargar(){

  var diagramaCargar = prompt("Inserte el nombre del Diagrama");

  var regreso = localStorage.getItem(diagramaCargar);

  if (regreso == null) {

    alert("No se pudo encontrar el diagrama");
  }
  else{

    regreso = JSON.parse(regreso);

    dibujarinicio();

    dibujarC(regreso.variable, regreso.colorVariable);

    dibujarindicacionC(regreso.variableScan, regreso.scanColor);

    dibujarescanC(regreso.variableAsig, regreso.asignColor);

    dibujarindifC(regreso.final ,regreso.valif);

    dibujarestC(regreso.valStruct ,regreso.palabraz ,regreso.palabrax ,regreso.palabray ,regreso.colorStruct);

    dibujarfin();
  }
}

function getCursorPosition(canvas, event){

  const rect = canvas.getBoundingClientRect()
  const x = event.clientX - rect.left
  const y = event.clientY - rect.top
  prompt("x: " + x + " y: " + y)
}

canvas.addEventListener('mousedown', function(e) {

  getCursorPosition(canvas, e)
})

let cuadro = document.getElementById("cuadrado");

for (let i = 1; i <= 8; i++) {

  let circulo = document.createElement("div")
  cuadro.appendChild(circulo)
  circulo.classList.add("circle", `c${i}`)
}

const textarea = document.querySelector("textarea");

textarea.addEventListener("keyup", e =>{
  
  textarea.style.height = "63px";
  let scHeight = e.target.scrollHeight;
  textarea.style.height = `${scHeight}px`;
});

//FUNCION CON PARAMETROS PARA CARGAR EL DIAGRAMA DESEADO

function dibujarC(palabra, color){

  ctx.beginPath();
  ctx.fillStyle =color;
  ctx.lineWidth = 4;
  ctx.strokeStyle = 'black';
  ctx.rect(206, 60, 90, 10);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.rect(206, 100, 90, 20);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.beginPath();
  ctx.rect(206,68, 90, 40);
  ctx.fillStyle = color
  ctx.stroke();
  ctx.fill()
  ctx.closePath();
  ctx.fillStyle = 'white';
  ctx.font = "16px Gill Sans";
  ctx.fillText('' + palabra + '', 220, 90);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(250, 122);
  ctx.lineTo(250, 129);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(258, 122);
  ctx.lineTo(250, 130);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(240, 122);
  ctx.lineTo(250, 130);
  ctx.stroke();
}

function dibujarindicacionC(palabra1, color1){

  ctx.fillStyle =color1;
  ctx.fillRect(207,130,100,45);
  ctx.fillStyle = '#FFFFFF';  
  ctx.beginPath();
  ctx.arc(232.8, 163, 24, 0,Math.PI);
  ctx.fillStyle = color1;
  ctx.fill();
  ctx.lineWidth = 5;
  ctx.strokeStyle = color1;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(283, 190, 32, Math.PI,0);
  ctx.fillStyle = "white";
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = color1;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(256, 175);
  ctx.lineTo(256, 191);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(262, 180);
  ctx.lineTo(256, 191);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(248, 180);
  ctx.lineTo(256, 191);
  ctx.stroke();
  ctx.font = "10px Verdana";
  ctx.fillText(''+palabra1+'',217,140);
}

function dibujarescanC(palabra2, color2){

  ctx.lineWidth = 2;
  ctx.strokeStyle = color2;
  ctx.beginPath();
  ctx.rect(207, 192, 100, 35);
  ctx.fillStyle = color2
  ctx.stroke();
  ctx.fill()
  ctx.closePath();
  ctx.fillStyle = 'white';
  ctx.font = "16px Gill Sans";
  ctx.fillText('' + palabra2 + '', 233, 211);
}

function dibujarindifC(palabra3, color3){

  ctx.fillStyle = color3;
  ctx.beginPath();
  ctx.lineWidth = 4;
  ctx.strokeStyle = 'black';
  ctx.rect(206, 310, 100, 10);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.rect(206, 380, 100, 20);
  ctx.fillStyle="gray";
  ctx.stroke();
  ctx.fill()
  ctx.beginPath();
  ctx.rect(206,320, 100, 70);
  ctx.fillStyle = color3
  ctx.stroke();
  ctx.fill()
  ctx.closePath();
  ctx.fillStyle = 'white';
  ctx.font = "16px Gill Sans";
  ctx.fillText(''+palabra3+'',242,360);
}

function dibujarestC(estructura, palabraz, palabrax, palabray, colorz){
      
  if (estructura == '1') {

    ctx2.fillStyle = colorz;
    ctx2.beginPath();
    ctx2.moveTo(255, 230);
    ctx2.lineTo(190,265);
    ctx2.lineTo(255, 305);
    ctx2.lineTo(320, 265);
    ctx2.closePath();
    ctx2.fill();

    ctx.fillStyle =color2;
    ctx.fillRect(66,247,90,35);
    ctx.fillStyle =color2;
    ctx.fillRect(366,247,90,35);   
         
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabraz+'',89,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabrax+'',228,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabray+'',393,265);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(174, 267);
    ctx.lineTo(156, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 260);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 273);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(348, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(360, 260);
    ctx.stroke();    
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(358, 274);
    ctx.stroke();
  }

  if(estructura=='2'){

    ctx.fillStyle = "#4c004f";
    ctx.beginPath();
    ctx.moveTo(204,225);
    ctx.lineTo(300, 225);
    ctx.lineTo(321,265);
    ctx.lineTo(300, 305);
    ctx.lineTo(204, 305);
    ctx.lineTo(180, 265);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle =colorz;
    ctx.fillRect(66,247,90,35);
    ctx.fillStyle =colorz;
    ctx.fillRect(366,247,90,35);   
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabraz+'',89,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabrax+'',228,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText('' + palabray + '', 393, 265);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(174, 267);
    ctx.lineTo(156, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 260);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(156, 267);
    ctx.lineTo(162, 273);
    ctx.stroke();
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(348, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(360, 260);
    ctx.stroke();    
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(358, 274);
    ctx.stroke();
  }

  if(estructura=='3'){

    ctx.fillStyle = "#1565C0";
    ctx.beginPath();
    ctx.moveTo(215,240);
    ctx.lineTo(305,240);
    ctx.lineTo(330,300); 
    ctx.lineTo(194,300);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle =colorz;
    ctx.fillRect(66,247,90,35);
    ctx.fillStyle =colorz;
    ctx.fillRect(366,247,90,35);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabraz+'',89,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText(''+palabrax+'',228,265);
    ctx.fillStyle = '#FFFFFF';
    ctx.font = "16px Gill Sans";
    ctx.fillText('' + palabray + '', 393, 265);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(348, 267);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(360, 260);
    ctx.stroke();    
    ctx.beginPath();
    ctx.moveTo(374, 267);
    ctx.lineTo(358, 274);
    ctx.stroke();
  }
}

//Pruebas para crear XML e Identacion

/*
 Copyright 2011-2013 Abdulla Abdurakhmanov
 Original sources are available at https://code.google.com/p/x2js/

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
 */

(function (root, factory) {
     if (typeof define === "function" && define.amd) {
         define([], factory);
     } else if (typeof exports === "object") {
         module.exports = factory();
     } else {
         root.X2JS = factory();
     }
 }(this, function () {
  return function (config) {
    'use strict';
      
    var VERSION = "1.2.0";
    
    config = config || {};
    initConfigDefaults();
    initRequiredPolyfills();
    
    function initConfigDefaults() {
      if(config.escapeMode === undefined) {
        config.escapeMode = true;
      }
      
      config.attributePrefix = config.attributePrefix || "_";
      config.arrayAccessForm = config.arrayAccessForm || "none";
      config.emptyNodeForm = config.emptyNodeForm || "text";    
      
      if(config.enableToStringFunc === undefined) {
        config.enableToStringFunc = true; 
      }
      config.arrayAccessFormPaths = config.arrayAccessFormPaths || []; 
      if(config.skipEmptyTextNodesForObj === undefined) {
        config.skipEmptyTextNodesForObj = true;
      }
      if(config.stripWhitespaces === undefined) {
        config.stripWhitespaces = true;
      }
      config.datetimeAccessFormPaths = config.datetimeAccessFormPaths || [];
  
      if(config.useDoubleQuotes === undefined) {
        config.useDoubleQuotes = false;
      }
      
      config.xmlElementsFilter = config.xmlElementsFilter || [];
      config.jsonPropertiesFilter = config.jsonPropertiesFilter || [];
      
      if(config.keepCData === undefined) {
        config.keepCData = false;
      }
    }
  
    var DOMNodeTypes = {
      ELEMENT_NODE     : 1,
      TEXT_NODE        : 3,
      CDATA_SECTION_NODE : 4,
      COMMENT_NODE     : 8,
      DOCUMENT_NODE      : 9
    };
    
    function initRequiredPolyfills() {    
    }
    
    function getNodeLocalName( node ) {
      var nodeLocalName = node.localName;     
      if(nodeLocalName == null) // Yeah, this is IE!! 
        nodeLocalName = node.baseName;
      if(nodeLocalName == null || nodeLocalName=="") // =="" is IE too
        nodeLocalName = node.nodeName;
      return nodeLocalName;
    }
    
    function getNodePrefix(node) {
      return node.prefix;
    }
      
    function escapeXmlChars(str) {
      if(typeof(str) == "string")
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
      else
        return str;
    }
  
    function unescapeXmlChars(str) {
      return str.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
    }
    
    function checkInStdFiltersArrayForm(stdFiltersArrayForm, obj, name, path) {
      var idx = 0;
      for(; idx < stdFiltersArrayForm.length; idx++) {
        var filterPath = stdFiltersArrayForm[idx];
        if( typeof filterPath === "string" ) {
          if(filterPath == path)
            break;
        }
        else
        if( filterPath instanceof RegExp) {
          if(filterPath.test(path))
            break;
        }       
        else
        if( typeof filterPath === "function") {
          if(filterPath(obj, name, path))
            break;
        }
      }
      return idx!=stdFiltersArrayForm.length;
    }
    
    function toArrayAccessForm(obj, childName, path) {
      switch(config.arrayAccessForm) {
        case "property":
          if(!(obj[childName] instanceof Array))
            obj[childName+"_asArray"] = [obj[childName]];
          else
            obj[childName+"_asArray"] = obj[childName];
          break;
        /*case "none":
          break;*/
      }
      
      if(!(obj[childName] instanceof Array) && config.arrayAccessFormPaths.length > 0) {
        if(checkInStdFiltersArrayForm(config.arrayAccessFormPaths, obj, childName, path)) {
          obj[childName] = [obj[childName]];
        }     
      }
    }
    
    function fromXmlDateTime(prop) {
      // Implementation based up on http://stackoverflow.com/questions/8178598/xml-datetime-to-javascript-date-object
      // Improved to support full spec and optional parts
      var bits = prop.split(/[-T:+Z]/g);
      
      var d = new Date(bits[0], bits[1]-1, bits[2]);      
      var secondBits = bits[5].split("\.");
      d.setHours(bits[3], bits[4], secondBits[0]);
      if(secondBits.length>1)
        d.setMilliseconds(secondBits[1]);
  
      // Get supplied time zone offset in minutes
      if(bits[6] && bits[7]) {
        var offsetMinutes = bits[6] * 60 + Number(bits[7]);
        var sign = /\d\d-\d\d:\d\d$/.test(prop)? '-' : '+';
  
        // Apply the sign
        offsetMinutes = 0 + (sign == '-'? -1 * offsetMinutes : offsetMinutes);
  
        // Apply offset and local timezone
        d.setMinutes(d.getMinutes() - offsetMinutes - d.getTimezoneOffset())
      }
      else
        if(prop.indexOf("Z", prop.length - 1) !== -1) {
          d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds()));          
        }
  
      // d is now a local time equivalent to the supplied time
      return d;
    }
    
    function checkFromXmlDateTimePaths(value, childName, fullPath) {
      if(config.datetimeAccessFormPaths.length > 0) {
        var path = fullPath.split("\.#")[0];
        if(checkInStdFiltersArrayForm(config.datetimeAccessFormPaths, value, childName, path)) {
          return fromXmlDateTime(value);
        }
        else
          return value;     
      }
      else
        return value;
    }
    
    function checkXmlElementsFilter(obj, childType, childName, childPath) {
      if( childType == DOMNodeTypes.ELEMENT_NODE && config.xmlElementsFilter.length > 0) {
        return checkInStdFiltersArrayForm(config.xmlElementsFilter, obj, childName, childPath); 
      }
      else
        return true;
    } 
  
    function parseDOMChildren( node, path ) {
      if(node.nodeType == DOMNodeTypes.DOCUMENT_NODE) {
        var result = new Object;
        var nodeChildren = node.childNodes;
        // Alternative for firstElementChild which is not supported in some environments
        for(var cidx=0; cidx <nodeChildren.length; cidx++) {
          var child = nodeChildren.item(cidx);
          if(child.nodeType == DOMNodeTypes.ELEMENT_NODE) {
            var childName = getNodeLocalName(child);
            result[childName] = parseDOMChildren(child, childName);
          }
        }
        return result;
      }
      else
      if(node.nodeType == DOMNodeTypes.ELEMENT_NODE) {
        var result = new Object;
        result.__cnt=0;
        
        var nodeChildren = node.childNodes;
        
        // Children nodes
        for(var cidx=0; cidx <nodeChildren.length; cidx++) {
          var child = nodeChildren.item(cidx); // nodeChildren[cidx];
          var childName = getNodeLocalName(child);
          
          if(child.nodeType!= DOMNodeTypes.COMMENT_NODE) {
            var childPath = path+"."+childName;
            if (checkXmlElementsFilter(result,child.nodeType,childName,childPath)) {
              result.__cnt++;
              if(result[childName] == null) {
                result[childName] = parseDOMChildren(child, childPath);
                toArrayAccessForm(result, childName, childPath);          
              }
              else {
                if(result[childName] != null) {
                  if( !(result[childName] instanceof Array)) {
                    result[childName] = [result[childName]];
                    toArrayAccessForm(result, childName, childPath);
                  }
                }
                (result[childName])[result[childName].length] = parseDOMChildren(child, childPath);
              }
            }
          }               
        }
        
        // Attributes
        for(var aidx=0; aidx <node.attributes.length; aidx++) {
          var attr = node.attributes.item(aidx); // [aidx];
          result.__cnt++;
          result[config.attributePrefix+attr.name]=attr.value;
        }
        
        // Node namespace prefix
        var nodePrefix = getNodePrefix(node);
        if(nodePrefix!=null && nodePrefix!="") {
          result.__cnt++;
          result.__prefix=nodePrefix;
        }
        
        if(result["#text"]!=null) {       
          result.__text = result["#text"];
          if(result.__text instanceof Array) {
            result.__text = result.__text.join("\n");
          }
          //if(config.escapeMode)
          //  result.__text = unescapeXmlChars(result.__text);
          if(config.stripWhitespaces)
            result.__text = result.__text.trim();
          delete result["#text"];
          if(config.arrayAccessForm=="property")
            delete result["#text_asArray"];
          result.__text = checkFromXmlDateTimePaths(result.__text, childName, path+"."+childName);
        }
        if(result["#cdata-section"]!=null) {
          result.__cdata = result["#cdata-section"];
          delete result["#cdata-section"];
          if(config.arrayAccessForm=="property")
            delete result["#cdata-section_asArray"];
        }
        
        if( result.__cnt == 0 && config.emptyNodeForm=="text" ) {
          result = '';
        }
        else
        if( result.__cnt == 1 && result.__text!=null  ) {
          result = result.__text;
        }
        else
        if( result.__cnt == 1 && result.__cdata!=null && !config.keepCData  ) {
          result = result.__cdata;
        }     
        else      
        if ( result.__cnt > 1 && result.__text!=null && config.skipEmptyTextNodesForObj) {
          if( (config.stripWhitespaces && result.__text=="") || (result.__text.trim()=="")) {
            delete result.__text;
          }
        }
        delete result.__cnt;      
        
        if( config.enableToStringFunc && (result.__text!=null || result.__cdata!=null )) {
          result.toString = function() {
            return (this.__text!=null? this.__text:'')+( this.__cdata!=null ? this.__cdata:'');
          };
        }
        
        return result;
      }
      else
      if(node.nodeType == DOMNodeTypes.TEXT_NODE || node.nodeType == DOMNodeTypes.CDATA_SECTION_NODE) {
        return node.nodeValue;
      } 
    }
    
    function startTag(jsonObj, element, attrList, closed) {
      var resultStr = "<"+ ( (jsonObj!=null && jsonObj.__prefix!=null)? (jsonObj.__prefix+":"):"") + element;
      if(attrList!=null) {
        for(var aidx = 0; aidx < attrList.length; aidx++) {
          var attrName = attrList[aidx];
          var attrVal = jsonObj[attrName];
          if(config.escapeMode)
            attrVal=escapeXmlChars(attrVal);
          resultStr+=" "+attrName.substr(config.attributePrefix.length)+"=";
          if(config.useDoubleQuotes)
            resultStr+='"'+attrVal+'"';
          else
            resultStr+="'"+attrVal+"'";
        }
      }
      if(!closed)
        resultStr+=">";
      else
        resultStr+="/>";
      return resultStr;
    }
    
    function endTag(jsonObj,elementName) {
      return "</"+ (jsonObj.__prefix!=null? (jsonObj.__prefix+":"):"")+elementName+">";
    }
    
    function endsWith(str, suffix) {
      return str.indexOf(suffix, str.length - suffix.length) !== -1;
    }
    
    function jsonXmlSpecialElem ( jsonObj, jsonObjField ) {
      if((config.arrayAccessForm=="property" && endsWith(jsonObjField.toString(),("_asArray"))) 
          || jsonObjField.toString().indexOf(config.attributePrefix)==0 
          || jsonObjField.toString().indexOf("__")==0
          || (jsonObj[jsonObjField] instanceof Function) )
        return true;
      else
        return false;
    }
    
    function jsonXmlElemCount ( jsonObj ) {
      var elementsCnt = 0;
      if(jsonObj instanceof Object ) {
        for( var it in jsonObj  ) {
          if(jsonXmlSpecialElem ( jsonObj, it) )
            continue;     
          elementsCnt++;
        }
      }
      return elementsCnt;
    }
    
    function checkJsonObjPropertiesFilter(jsonObj, propertyName, jsonObjPath) {
      return config.jsonPropertiesFilter.length == 0
        || jsonObjPath==""
        || checkInStdFiltersArrayForm(config.jsonPropertiesFilter, jsonObj, propertyName, jsonObjPath); 
    }
    
    function parseJSONAttributes ( jsonObj ) {
      var attrList = [];
      if(jsonObj instanceof Object ) {
        for( var ait in jsonObj  ) {
          if(ait.toString().indexOf("__")== -1 && ait.toString().indexOf(config.attributePrefix)==0) {
            attrList.push(ait);
          }
        }
      }
      return attrList;
    }
    
    function parseJSONTextAttrs ( jsonTxtObj ) {
      var result ="";
      
      if(jsonTxtObj.__cdata!=null) {                    
        result+="<![CDATA["+jsonTxtObj.__cdata+"]]>";         
      }
      
      if(jsonTxtObj.__text!=null) {     
        if(config.escapeMode)
          result+=escapeXmlChars(jsonTxtObj.__text);
        else
          result+=jsonTxtObj.__text;
      }
      return result;
    }
    
    function parseJSONTextObject ( jsonTxtObj ) {
      var result ="";
  
      if( jsonTxtObj instanceof Object ) {
        result+=parseJSONTextAttrs ( jsonTxtObj );
      }
      else
        if(jsonTxtObj!=null) {
          if(config.escapeMode)
            result+=escapeXmlChars(jsonTxtObj);
          else
            result+=jsonTxtObj;
        }
      
      return result;
    }
    
    function getJsonPropertyPath(jsonObjPath, jsonPropName) {
      if (jsonObjPath==="") {
        return jsonPropName;
      }
      else
        return jsonObjPath+"."+jsonPropName;
    }
    
    function parseJSONArray ( jsonArrRoot, jsonArrObj, attrList, jsonObjPath ) {
      var result = ""; 
      if(jsonArrRoot.length == 0) {
        result+=startTag(jsonArrRoot, jsonArrObj, attrList, true);
      }
      else {
        for(var arIdx = 0; arIdx < jsonArrRoot.length; arIdx++) {
          result+=startTag(jsonArrRoot[arIdx], jsonArrObj, parseJSONAttributes(jsonArrRoot[arIdx]), false);
          result+=parseJSONObject(jsonArrRoot[arIdx], getJsonPropertyPath(jsonObjPath,jsonArrObj));
          result+=endTag(jsonArrRoot[arIdx],jsonArrObj);
        }
      }
      return result;
    }
    
    function parseJSONObject ( jsonObj, jsonObjPath ) {
      var result = "";  
  
      var elementsCnt = jsonXmlElemCount ( jsonObj );
      
      if(elementsCnt > 0) {
        for( var it in jsonObj ) {
          
          if(jsonXmlSpecialElem ( jsonObj, it) || (jsonObjPath!="" && !checkJsonObjPropertiesFilter(jsonObj, it, getJsonPropertyPath(jsonObjPath,it))) )
            continue;     
          
          var subObj = jsonObj[it];           
          
          var attrList = parseJSONAttributes( subObj )
          
          if(subObj == null || subObj == undefined) {
            result+=startTag(subObj, it, attrList, true);
          }
          else
          if(subObj instanceof Object) {
            
            if(subObj instanceof Array) {         
              result+=parseJSONArray( subObj, it, attrList, jsonObjPath );          
            }
            else if(subObj instanceof Date) {
              result+=startTag(subObj, it, attrList, false);
              result+=subObj.toISOString();
              result+=endTag(subObj,it);
            }
            else {
              var subObjElementsCnt = jsonXmlElemCount ( subObj );
              if(subObjElementsCnt > 0 || subObj.__text!=null || subObj.__cdata!=null) {
                result+=startTag(subObj, it, attrList, false);
                result+=parseJSONObject(subObj, getJsonPropertyPath(jsonObjPath,it));
                result+=endTag(subObj,it);
              }
              else {
                result+=startTag(subObj, it, attrList, true);
              }
            }
          }
          else {
            result+=startTag(subObj, it, attrList, false);
            result+=parseJSONTextObject(subObj);
            result+=endTag(subObj,it);
          }
        }
      }
      result+=parseJSONTextObject(jsonObj);
      
      return result;
    }
    
    this.parseXmlString = function(xmlDocStr) {
      var isIEParser = window.ActiveXObject || "ActiveXObject" in window;
      if (xmlDocStr === undefined) {
        return null;
      }
      var xmlDoc;
      if (window.DOMParser) {
        var parser=new window.DOMParser();      
        var parsererrorNS = null;
        // IE9+ now is here
        if(!isIEParser) {
          try {
            parsererrorNS = parser.parseFromString("INVALID", "text/xml").getElementsByTagName("parsererror")[0].namespaceURI;
          }
          catch(err) {          
            parsererrorNS = null;
          }
        }
        try {
          xmlDoc = parser.parseFromString( xmlDocStr, "text/xml" );
          if( parsererrorNS!= null && xmlDoc.getElementsByTagNameNS(parsererrorNS, "parsererror").length > 0) {
            //throw new Error('Error parsing XML: '+xmlDocStr);
            xmlDoc = null;
          }
        }
        catch(err) {
          xmlDoc = null;
        }
      }
      else {
        // IE :(
        if(xmlDocStr.indexOf("<?")==0) {
          xmlDocStr = xmlDocStr.substr( xmlDocStr.indexOf("?>") + 2 );
        }
        xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async="false";
        xmlDoc.loadXML(xmlDocStr);
      }
      return xmlDoc;
    };
    
    this.asArray = function(prop) {
      if (prop === undefined || prop == null)
        return [];
      else
      if(prop instanceof Array)
        return prop;
      else
        return [prop];
    };
    
    this.toXmlDateTime = function(dt) {
      if(dt instanceof Date)
        return dt.toISOString();
      else
      if(typeof(dt) === 'number' )
        return new Date(dt).toISOString();
      else  
        return null;
    };
    
    this.asDateTime = function(prop) {
      if(typeof(prop) == "string") {
        return fromXmlDateTime(prop);
      }
      else
        return prop;
    };
  
    this.xml2json = function (xmlDoc) {
      return parseDOMChildren ( xmlDoc );
    };
    
    this.xml_str2json = function (xmlDocStr) {
      var xmlDoc = this.parseXmlString(xmlDocStr);
      if(xmlDoc!=null)
        return this.xml2json(xmlDoc);
      else
        return null;
    };
  
    this.json2xml_str = function (jsonObj) {
      return parseJSONObject ( jsonObj, "" );
    };
  
    this.json2xml = function (jsonObj) {
      var xmlDocStr = this.json2xml_str (jsonObj);
      return this.parseXmlString(xmlDocStr);
    };
    
    this.getVersion = function () {
      return VERSION;
    };  
  }
}))

