rem crea la base student
set flush off
set termout off
@@C:\Users\ORA_bases\O11\createStudent.sql

