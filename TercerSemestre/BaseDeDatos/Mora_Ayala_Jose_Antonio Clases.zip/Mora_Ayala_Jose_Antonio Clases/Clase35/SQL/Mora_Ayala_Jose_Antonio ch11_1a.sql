spool F:\Base\Clases\ch11_1a.txt


-- ch11_1a.sql
--* vr_student student%ROWTYPE; esta heredando los atributos de la tabla
--* student, por eso podemos acceder a ellos con esta sentencia
--* vr_student.first_name

--*Dando formato a la consolo
SET COLSEP ' |=| '
SET LINESIZE 150
SET PAGESIZE 99

--* Es importante colocar el SERVEROUTPUT si no, no podremos ver las salidas del DBMS
SET SERVEROUTPUT ON
DECLARE
	vr_student student%ROWTYPE;
	BEGIN
		SELECT *
			INTO vr_student
			FROM student
			WHERE student_id = 156 
 			or student_id = 101;
--			WHERE student_id = 115;
			DBMS_OUTPUT.PUT_LINE (vr_student.first_name||' '
			||vr_student.last_name||' has an ID of Tiene un ID de : 156');
		EXCEPTION
			WHEN no_data_found
			THEN
			DBMS_OUTPUT.PUT_LINE ('estudiante 101'||CHR(09)||'NO EXISTE  ');
			RAISE_APPLICATION_ERROR(-20001,'The Student '||'is not in the database NO ESTA EN LA BASE');
END;
/

REM CONSULTA PREVIA 
select student_id, last_name from student
WHERE student_id between 100 and 125;

rem no existen en la base el 101, 115 & 116
select student_id, last_name from student
WHERE student_id= 156;
select count(*) from student;

spool off;