spool F:\Documents\BasedeDatos\Capitulo9\Capitulo9.txt
--  =======================================================================================
--  ||Capitulo 9 Ejercicios SQLOracle By Example                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Oracle SQL by Example Third Edition              ||
--* ||Rischert, Alice.                                                                  ||
--* ||Oracle SQL by example / Alice Rischert.-- 3rd ed.                                 ||
--* ||p. cm. -- (Prentice Hall PTR Oracle series)                                       ||
--* ||Rev. ed. of: Oracle SQL interactive workbook, 2003.                               ||
--* ||Includes indexes.                                                                 ||
--* ||ISBN 0-13-145131-6                                                                ||
--* ||1. SQL (Computer program language) 2. Oracle (Computer file)                      ||
--* ||I. Rischert, Alice. Oracle SQL interactive workbook. II. Title. III. Series.      ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 9'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 210
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;
--  Outer JOINS
--  Missing Rows?

SELECT course_no, description,
        section_id
   FROM course JOIN section
  USING (course_no)
  ORDER BY course_no;

SELECT course_no, description
   FROM course c
  WHERE NOT EXISTS
        (SELECT 'X'
           FROM section
          WHERE c.course_no = course_no);

--  The ANSI OUTER JOIN

SELECT c.course_no, c.description,
        s.section_id, s.course_no
   FROM course c LEFT OUTER JOIN section s
     ON c.course_no = s.course_no
  ORDER BY c.course_no;

--  The ANSI OUTER JOIN

SELECT course_no, description,
        section_id
   FROM section RIGHT OUTER JOIN course
  USING (course_no)
  ORDER BY course_no;

--  FULL OUTER JOIN
--  ANSI FULL OUTER JOIN

SELECT col1
   FROM t1;

--  ANSI FULL OUTER JOIN


 SELECT col2
   FROM t2;

--  ANSI FULL OUTER JOIN

SELECT col1, col2
   FROM t1 LEFT OUTER JOIN t2
     ON t1.col1 = t2.col2;


SELECT col1, col2
   FROM t1 RIGHT OUTER JOIN t2
     ON t1.col1 = t2.col2;


SELECT col1, col2
   FROM t1 FULL OUTER JOIN t2
     ON t1.col1 = t2.col2;

--  FULL OUTER JOIN Using The UNION Operator

SELECT col1, col2
   FROM t1, t2
  WHERE t1.col1 = t2.col2(+)
UNION SELECT col1, col2
   FROM t1, t2
  WHERE t1.col1(+) = t2.col2;


--  Oracle OUTER JOIN Operator Restrictions
--  Conditions and The Oracle OUTER JOIN Operator

SELECT c.course_no cno, s.course_no sno,
        c.description,
        c.prerequisite prereq,
        s.location loc, s.section_id
   FROM course c, section s
  WHERE c.course_no = s.course_no(+)
    AND c.prerequisite = 350
    AND s.location = 'L507';


--  WHERE Conditiond and The ANSI OUTER JOINS

SELECT c.course_no cno, s.course_no sno,
         c.description,
         c.prerequisite prereq,
         s.location loc, s.section_id
    FROM course c LEFT OUTER JOIN section s
      ON c.course_no = s.course_no
   WHERE c.prerequisite = 350
     AND location = 'L507';

--  SELF-JOINS

SELECT c1.course_no,
        c1.description course_descr,
        c1.prerequisite,
        c2.description pre_req_descr
   FROM course c1 JOIN course c2
     ON (c1.prerequisite = c2.course_no)
  ORDER BY 3;


--  SELF-JOINS
--  The NON-EQUIJOIN

SELECT grade_type_code, numeric_grade, letter_grade
   FROM grade g JOIN grade_conversion c
     ON (g.numeric_grade BETWEEN c.min_grade AND c.max_grade)
  WHERE g.student_id = 107
  ORDER BY 1, 2 DESC;

-- Ejercicios
--	b) Muestre la descripción de todos los cursos con el prerrequisito del curso número 350. 
--		Incluya la ubicación donde se encuentran las secciones en el resultado. Devuelve las 
--		filas del curso incluso si no se encuentra la fila correspondiente en la tabla SECCIÓN.

SELECT c.course_no cno, s.course_no sno, c.description, c.prerequisite prereq,
		s.location loc, s.section_id
FROM course c LEFT OUTER JOIN section s
ON c.course_no = s.course_no
WHERE c.prerequisite = 350;

--	c) Vuelva a escribir la siguiente instrucción SQL utilizando una combinación externa.

--		SELECT course_no, description
--		FROM course c
--		WHERE NOT EXISTS (SELECT 'X'
--						  FROM section
--						  WHERE c.course_no = course_no)

SELECT course_no, description
FROM course LEFT OUTER JOIN section
USING (course_no)
WHERE section_id IS NULL;

--	d) Muestra todas las ciudades, estados y códigos postales de Connecticut. Muestre un 
--		recuento de cuántos estudiantes viven en cada código postal. Ordena el resultado 
--		alfabéticamente por ciudad. El resultado debería ser similar al siguiente resultado. 
--		Tenga en cuenta que la columna STUDENT_COUNT muestra un cero cuando ningún estudiante 
--		vive en un código postal en particular.

SELECT city, state, z.zip, COUNT(s.zip) AS student_count
FROM zipcode z LEFT OUTER JOIN student s
ON (z.zip = s.zip)
WHERE state = 'CT'
GROUP BY city, state, z.zip;



--	9.1.2. Write Outer Joins with Three Tables

--	a) Muestra el número del curso, la descripción, el costo, la ubicación de la clase y 
--		el apellido del instructor de todos los cursos. También incluya cursos donde no 
--		se hayan asignado secciones o instructores.

SELECT course_no cou, description, cost, location, last_name
FROM course LEFT OUTER JOIN section
USING (course_no)
LEFT OUTER JOIN instructor
USING (instructor_id)
ORDER BY 1;

--	b) Para los estudiantes con la identificación de estudiante 102 y 301, determine las 
--		secciones en las que están inscritos. También muestre las calificaciones numéricas y 
--		los tipos de calificaciones que recibieron, sin importar si están inscritos o recibieron
--		alguna calificación.

SELECT student_id, section_id, grade_type_code, numeric_grade
FROM student LEFT OUTER JOIN enrollment
USING (student_id)
LEFT OUTER JOIN grade
USING (student_id, section_id)
WHERE student_id IN (102, 301);

--	Lab 9.2.1. Escriba autouniones y detecte inconsistencias de datos

--	a) Para SECTION_ID 86, determine qué estudiantes recibieron una calificación más baja en 
--		su examen final que en su examen parcial. En su resultado, enumere el STUDENT_ID y la 
--		calificación para el parcial y el final.

SELECT fi.student_id, mt.numeric_grade "Midterm Grade", fi.numeric_grade "Final Grade"
FROM grade fi JOIN grade mt
ON (fi.section_id = mt.section_id AND fi.student_id = mt.student_id)
WHERE fi.grade_type_code = 'FI'
AND fi.section_id = 86
AND mt.grade_type_code = 'MT'
AND fi.numeric_grade < mt.numeric_grade;

--	b) Formule la pregunta para la siguiente consulta.

--	SELECT DISTINCT a.student_id, a.first_name, a.salutation
--	FROM student a, student b
--	WHERE a.salutation <> b.salutation
--	AND b.first_name = a.first_name
--	AND a.student_id <> b.student_id
--	ORDER BY a.first_name

--	Determine los estudiantes que podrían tener saludos inconsistentes para sus
--		respectivos nombres.

--	c) Muestre la identificación del estudiante, el apellido y la dirección de los estudiantes 
--		que viven en la misma dirección y código postal.

SELECT DISTINCT a.student_id, a.last_name, a.street_address
FROM student a, student b
WHERE a.street_address = b.street_address
AND a.zip = b.zip
AND a.student_id <> b.student_id
ORDER BY a.street_address;

--	d) Escriba una consulta que muestre el número del curso, la descripción del curso, el 
--		prerrequisito y la descripción del prerrequisito. Incluya cursos sin ningún requisito 
--		previo. Tenga en cuenta que esto requiere una unión automática y una unión externa.

SELECT c1.course_no, SUBSTR(c1.description, 1,15) course_descr, C1.prerequisite,
		SUBSTR(c2.description,1,15) pre_req_descr
FROM course c1 LEFT OUTER JOIN course c2
ON c1.prerequisite = c2.course_no
ORDER BY 1;
SPOOL OFF;