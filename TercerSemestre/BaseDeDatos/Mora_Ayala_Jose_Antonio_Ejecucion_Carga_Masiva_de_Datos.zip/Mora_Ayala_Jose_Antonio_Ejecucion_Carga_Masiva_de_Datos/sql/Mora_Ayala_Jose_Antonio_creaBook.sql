
spool C:\Users\ORA_bases\dbbook\salida\dbbook.txt
@@C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook\script\creaBook.sql
@@C:\Users\ORA_bases\dbbook\script\cifras
spool off