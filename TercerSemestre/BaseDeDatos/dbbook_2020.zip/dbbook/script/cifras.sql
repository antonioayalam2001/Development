
 REM  CIFRAS DE CONTROL
 
 
 SELECT 'Tuplas de entidad STUDENT:  ', COUNT(*)
  FROM STUDENT;

 SELECT 'Tuplas de entidad FACULTY:  ', COUNT(*)
  FROM FACULTY;
 
 SELECT 'Tuplas de entidad CLASS:    ', COUNT(*)
  FROM CLASS;
 
 SELECT 'Tuplas de entidad ENROLLED: ', COUNT(*)
  FROM ENROLLED;
 
 SELECT 'Tuplas de entidad EMP:      ', COUNT(*)
  FROM EMP;
 
 SELECT 'Tuplas de entidad DEPT:     ', COUNT(*)
  FROM DEPT;
 
  SELECT 'Tuplas de entidad WORKS:   ', COUNT(*)
  FROM WORKS;

 SELECT 'Tuplas de entidad PARTS:    ', COUNT(*)
  FROM PARTS;
 
 SELECT 'Tuplas de entidad SUPPLIERS:', COUNT(*)
  FROM SUPPLIERS;
 
 SELECT 'Tuplas de entidad CATALOG:  ', COUNT(*)
  FROM CATALOG;
 
 SELECT 'Tuplas de entidad AIRCRAFT: ', COUNT(*)
  FROM AIRCRAFT;
 
 SELECT 'Tuplas de entidad EMPLOYEES:', COUNT(*)
  FROM EMPLOYEES;
 
 SELECT 'Tuplas de entidad FLIGHTS:  ', COUNT(*)
  FROM FLIGHTS;
 
 SELECT 'Tuplas de entidad CERTIFIED:', COUNT(*)
  FROM CERTIFIED;
 
 SELECT 'Tuplas de entidad SAILORS:  ', COUNT(*)
  FROM SAILORS;
/  
 
 