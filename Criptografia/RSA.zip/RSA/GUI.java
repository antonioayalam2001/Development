/**********************************************
*                                             *
*   Metodo de la GUI                          *
*   Integrantes                               *
*       Mora Ayala Jose Antonio               *
*       Torres Carrillo Josehf Miguel Angel   *
*       Tovar Jacuinde Rodrigo                *
*   Grupo                                     *
*       3CM13                                 *
*                                             *
**********************************************/

//Importamos las Bibliotecas necesarias para inicializar nuestra GUI
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

import java.security.*;
import java.util.regex.Pattern;

//Clase Principal para nuestra GUI que hace uso de la clase JFrame
public class GUI extends JFrame {

    //Variables para mostrar texto es nuestra aplicacion
    private JLabel titulo, inst1, inst2, inst3, inst4, inst5; 

    //Variables para botones que selecciona el archivo e inicia el cifrador
    private JButton selArchivoTexto, selArchivoLlave, iniciarFV;

    //Variables para botones que indican si vamos a cifrar o a decifrar
    //junto con el grupo que solo permite seleccionar uno de estos a la vez
    private JRadioButton firmar, verificar;
    private ButtonGroup grupoFV;

    //Variable para agregar nuestra imagen de fondo para darle estilo a la GUI
    private JLabel fondo, imagenI, imagenD;
    private ImageIcon imagenicono;

    //Variable que nos permite obtener los metodos de nuestro archivo con las 
    //funciones para cifrar o descifrar nuestras imagenes
    private Utilidades entidad = new Utilidades();

    //Variables necesarias para obtener el contenido de la imagen a cifrar
    //la direccion de la imagen ademas de su nombre
    String textoArchivo;
    String textoArchivoCifrado;

    PrivateKey llavePrivada;
    PublicKey llavePublica;

    byte[] bytesHash;

    //Metodo de inicializacion de nuestra GUI
    public GUI (){

        //Mandamos a llamar nuestro metodo que inicializa nuestros elementos 
        //declarados para nuestra GUI
        iniciarComponentes();
    }

    //Metodo que inicializa nuestros componentes anteriormente
    private void iniciarComponentes (){

        titulo = new JLabel();
        getContentPane().add(titulo);

        inst1 = new JLabel();
        getContentPane().add(inst1);

        firmar = new JRadioButton();
        firmar.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt) {
                firmarActionPerformed(evt);
            }
        });
        getContentPane().add(firmar);

        verificar = new JRadioButton();
        verificar.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt) {
                verificarActionPerformed(evt);
            }
        });
        getContentPane().add(verificar);

            grupoFV = new ButtonGroup();
            grupoFV.add(firmar);
            grupoFV.add(verificar);

        inst2 = new JLabel();
        getContentPane().add(inst2);

        inst4 = new JLabel();
        getContentPane().add(inst4);

        selArchivoTexto = new JButton();
        selArchivoTexto.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                selArchivoTextoActionPerformed(evt);
            }
        });
        getContentPane().add(selArchivoTexto);

        inst3 = new JLabel();
        getContentPane().add(inst3);

        inst5 = new JLabel();
        getContentPane().add(inst5);

        selArchivoLlave = new JButton();
        selArchivoLlave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                selArchivoLlaveActionPerformed(evt);
            }
        });
        getContentPane().add(selArchivoLlave);

        //Creamos un nuevo boton  para iniciar nuestro cifrador/Decifrador
        //y le agregamos un metodo que 
        //responda a cada vez que se le de click
        //y al final agregamos nuestro boton a nuestra interfaz
        iniciarFV = new JButton();
        iniciarFV.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent evt) {
                iniciarFVActionPerformed(evt);
            }
        });
        getContentPane().add(iniciarFV);

        //Creamos un nuevo objeto para poder insertar una nueva imagen
        //dentro de nuestra aplicacion, posteriormente agregamos esta imagen
        //a nuestro JFrame
        imagenI = new JLabel();
        getContentPane().add(imagenI);

        //Creamos un nuevo objeto para poder insertar una nueva imagen
        //dentro de nuestra aplicacion, psteriormente agregamos esta imagen
        //a nuestro JFrame
        imagenD = new JLabel();
        getContentPane().add(imagenD);

        //Creamos un nuevo Label el cual tendra el color de fondo para nuestra
        //aplicacion, posteriormente agregaremos este fondo a nuestra aplicacion
        fondo = new JLabel();
        getContentPane().add(fondo);

        //Creamos un nuevo icono que se insertara en nuestro Label de imagenes
        //este objeto no se insertara como tal en nuestro JFrame
        imagenicono = new ImageIcon("fondo.png");


        //Creamos nuestro panel para poder mostrarlo en pantalla
        getContentPane().setLayout(null);

        //Aqui definimos el tamaño de ventana para nuestra aplicacion
        setSize(800, 400);

        //Definimos la aplicacion para que se habra en nuestro monitor
        //principal de manera centrada
        setLocationRelativeTo(null);

        //Definimos la operacion de cierre para que cada vez que se cerremos
        //la aplicacion esta detenga el proceso
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        //Definimos como visible nuestro panel con nuestros objetos 
        setVisible(true);

        //Mandamos nuestro objeto para ejecutar nuestra GUI
        iniciarGUI();
    }

    //Metodo para ejecutar nuestros componentes para nuestro JFrame
    //ademas de darle propiedades a cada uno
    public void iniciarGUI (){

        titulo.setText("Practica 2 - 3CM13");
        titulo.setFont(new Font("Serif", Font.BOLD, 50));
        titulo.setBounds(180, 10, 430, 50);

        inst1.setText("Seleccione la Opcion Deseada");
        inst1.setFont(new Font("Serif", Font.BOLD, 30));
        inst1.setBounds(30, 130, 380, 40);

            firmar.setText("Firmar");
            firmar.setBackground(Color.white);
            firmar.setFont(new Font("Serif", Font.BOLD, 25));
            firmar.setBounds(450, 140, 120, 25);

            verificar.setText("Verificar");
            verificar.setBackground(Color.white);
            verificar.setFont(new Font("Serif", Font.BOLD, 25));
            verificar.setBounds(580, 140, 140, 25);

        inst2.setText("Seleccione el Archivo a Firmar");
        inst2.setFont(new Font("Serif", Font.BOLD, 30));
        inst2.setBounds(30, 190, 390, 40);
        inst2.setVisible(false);

        inst4.setText("Seleccione el Archivo a Verificar");
        inst4.setFont(new Font("Serif", Font.BOLD, 30));
        inst4.setBounds(30, 190, 410, 40);
        inst4.setVisible(false);

            selArchivoTexto.setText("Seleccionar Archivo");
            selArchivoTexto.setBackground(Color.white);
            selArchivoTexto.setFont(new Font("Serif", Font.BOLD, 20));
            selArchivoTexto.setBounds(475, 200, 210, 25);
            selArchivoTexto.setVisible(false);

        inst3.setText("Seleccione la llave Privada");
        inst3.setFont(new Font("Serif", Font.BOLD, 30));
        inst3.setBounds(30, 230, 380, 40);
        inst3.setVisible(false);

        inst5.setText("Seleccione la llave Publica");
        inst5.setFont(new Font("Serif", Font.BOLD, 30));
        inst5.setBounds(30, 230, 380, 40);
        inst5.setVisible(false);

            selArchivoLlave.setText("Seleccionar Llave");
            selArchivoLlave.setBackground(Color.white);
            selArchivoLlave.setFont(new Font("Serif", Font.BOLD, 20));
            selArchivoLlave.setBounds(475, 240, 210, 25);
            selArchivoLlave.setVisible(false);

        iniciarFV.setText("Iniciar Proceso");
        iniciarFV.setBackground(Color.white);
        iniciarFV.setFont(new Font("Serif", Font.BOLD, 30));
        iniciarFV.setBounds(240, 300, 300, 30);
        iniciarFV.setVisible(false);

        imagenI.setIcon(imagenicono);
        imagenI.setBounds(25, 5, 300, 136);

        imagenD.setIcon(imagenicono);
        imagenD.setBounds(625, 5, 300, 136);

        fondo.setBackground(Color.white);
        fondo.setBounds(0, 0, 800, 600);
        fondo.setOpaque(true);
    }

    private void firmarActionPerformed (ActionEvent evt) {

        if (firmar.isSelected()==true){

            selArchivoTexto.setVisible(true);
            selArchivoLlave.setVisible(true);
            inst2.setVisible(true);
            inst3.setVisible(true);
            inst4.setVisible(false);
            inst5.setVisible(false);
            iniciarFV.setVisible(true);
        }
    }

    private void verificarActionPerformed (ActionEvent evt) {

        if (verificar.isSelected()==true){

            selArchivoTexto.setVisible(true);
            selArchivoLlave.setVisible(true);
            inst2.setVisible(false);
            inst3.setVisible(false);
            inst4.setVisible(true);
            inst5.setVisible(true);
            iniciarFV.setVisible(true);
        }
    }

    private void selArchivoTextoActionPerformed (ActionEvent evt) {

        if ( firmar.isSelected()==true ) {

            try{ textoArchivo = entidad.leerArchivo(); }
            catch(Exception e) {}
        }

        if ( verificar.isSelected()==true ) {

            try{ textoArchivoCifrado = entidad.leerArchivo(); }
            catch(Exception e) {}
        }
    }

    private void selArchivoLlaveActionPerformed (ActionEvent evt) {

        if ( firmar.isSelected()==true ) {

            try{ llavePrivada = entidad.leerLlavePrivada(); }
            catch(Exception e) {}
        }

        if ( verificar.isSelected()==true ) {

            try{ llavePublica = entidad.leerLlavePublica(); }
            catch(Exception e) {}
        }
    }

    private void iniciarFVActionPerformed (ActionEvent evt) {
    
        try{ 

            if ( firmar.isSelected()==true ) {
                
                bytesHash = entidad.operacionHash(textoArchivo);
                //Mandamos a crifrar nuestro digesto
                entidad.cifrarRSA(llavePrivada, bytesHash, textoArchivo);
            }

            if ( verificar.isSelected()==true ){

                String separador = Pattern.quote("\n");
                String[] textoPartido = textoArchivoCifrado.split(separador);

                String digestoCifrado = textoPartido[0];

                String textoClaro = textoPartido[1];

                for (int i = 2; i < textoPartido.length ; i++) {
                    textoClaro = textoClaro + "\n" + textoPartido[i];
                }

                //Hacemos Hash a nuestro texto claro
                bytesHash = entidad.operacionHash(textoClaro);

                String datosOriginales = new String(bytesHash);

                //Mandamos a descifrar nuestro textoCifrado
                String datosDescifrados = entidad.descifrarRSA(llavePublica, digestoCifrado);

                if (datosOriginales.equals(datosDescifrados)) JOptionPane.showMessageDialog(null, "Verificacion Correcta :)");
                else JOptionPane.showMessageDialog(null, "Verificacion incorrecta :(");
            }
        }
        catch (Exception e) {}
    }    
}

/*

javac main.java
javac GUI.java
javac Utilidades.java

java main

*/