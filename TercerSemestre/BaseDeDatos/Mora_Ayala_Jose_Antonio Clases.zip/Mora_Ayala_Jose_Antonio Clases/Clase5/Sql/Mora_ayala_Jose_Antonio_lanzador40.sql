REM 
REM   LANZADOR DE CONSULTAS
REM
REM lanzador40.sql 
set echo on                                                     
set feedback on
set pagesize 100
set linesize 129
set colsep ' ||'
clear screen
--       
--  directorio var entorno    ORA_IN  C:\Users\Admin\Desktop\2020_01_24_clase_dist\SCRIPTS
--                            ORA_OUT  C:\Users\Admin\Desktop\2020_01_24_clase_dist\SALIDAS

@%ORA_IN%\HR11.sql
@%ORA_IN%\HR12.sql
@%ORA_IN%\HR13.sql
@%ORA_IN%\HR14.sql
@%ORA_IN%\HR15.sql
@%ORA_IN%\HR41.sql
@%ORA_IN%\HR42.sql
@%ORA_IN%\HR43.sql
@%ORA_IN%\HR44.sql
@%ORA_IN%\HR45.sql




PROMPT   SALUDOS ESCOM  ??????
