spool F:\Documents\BasedeDatos\Capitulo5MO\Capitulo5MO.txt

--  =======================================================================================
--  ||Capitulo 5 Ejercicios Mastering Oracle SQL                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Mastering Oracle SQL                             ||
--* ||by Sanjay Mishra and Alan Beaulieu                                                ||
--* ||Copyright © 2002 O’Reilly & Associates, Inc. All rights reserved.                 ||
--* ||Printed in the United States of America.                                          ||
--* ||Published by O’Reilly & Associates, Inc., 1005 Gravenstein Highway North,         ||
--* ||Sebastopol, CA 95472.                                                             ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 4 Mastering Oracle SQL'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 210
Connect MasterOracle/MasterOracle;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos MasterOracle
show user;

--  Conociendo nuestras tablas 
desc Customer;

--Una subquery se define como una consulta (query) dentro de otra consulta. 
--Es posible colocar una subquery dentro de las consultas de tipo SELECT, INSERT, UPDATE y DELETE.
--La subquery, por su parte, es siempre una sentencia SELECT y debe ir encerrada entre paréntesis.

--Single-Row, Single-Column Subqueries
--Los siguientes operadores pueden ser empleados (=, <, >, !=, <=, >=)
DELETE FROM load_log
WHERE load_dt < (SELECT MAX(TRUNC(load_dt))
FROM load_log);

SELECT sales_emp_id, COUNT(*)
FROM cust_order
GROUP BY sales_emp_id
HAVING COUNT(*) = (SELECT MAX(COUNT(*))
FROM cust_order
GROUP BY sales_emp_id);

--• The FROM clause may contain any type of noncorrelated subquery.
--• The SELECT and ORDER BY clauses may contain scalar subqueries.
--• The GROUP BY clause may not contain subqueries.
--• The START WITH and CONNECT BY clauses, used for querying hierarchical
--data, may contain subqueries and will be examined in detail in Chapter 8.

--Multiple-Row Subqueries
--Operadores que podemos emplear ANY, ALL, IN

SELECT fname, lname
FROM employee
WHERE dept_id = 3 AND salary >= ALL
(SELECT salary
FROM employee
WHERE dept_id = 3);

SELECT fname, lname
FROM employee
WHERE dept_id = 3 AND NOT salary < ANY
(SELECT salary
FROM employee
WHERE dept_id = 3);

--Usando ANY 
SELECT fname, lname
FROM employee
WHERE manager_emp_id IS NOT NULL
AND salary > ANY
(SELECT salary
FROM employee
WHERE manager_emp_id IS NULL);

--Usando IN
UPDATE cust_order
SET expected_ship_dt = TRUNC(SYSDATE) + 1
WHERE ship_dt IS NULL AND order_nbr IN
(SELECT l.order_nbr
FROM line_item l, part p
WHERE l.part_nbr = p.part_nbr AND p.inventory_qty = 0);



DELETE FROM customer
WHERE cust_nbr NOT IN
(SELECT cust_nbr
FROM cust_order
WHERE order_dt >= TRUNC(SYSDATE) — (365 * 5));


--Multiple-Column Subqueries
UPDATE monthly_orders SET
tot_orders = (SELECT COUNT(*)
FROM cust_order
WHERE order_dt >= TO_DATE('01-NOV-2001','DD-MON-YYYY')
AND order_dt < TO_DATE('01-DEC-2001','DD-MON-YYYY')
AND cancelled_dt IS NULL),
max_order_amt = (SELECT MAX(sale_price)
FROM cust_order
WHERE order_dt >= TO_DATE('01-NOV-2001','DD-MON-YYYY')
AND order_dt < TO_DATE('01-DEC-2001','DD-MON-YYYY')
AND cancelled_dt IS NULL),
min_order_amt = (SELECT MIN(sale_price)
FROM cust_order
WHERE order_dt >= TO_DATE('01-NOV-2001','DD-MON-YYYY')
AND order_dt < TO_DATE('01-DEC-2001','DD-MON-YYYY')
AND cancelled_dt IS NULL),
tot_amt = (SELECT SUM(sale_price)
FROM cust_order
WHERE order_dt >= TO_DATE('01-NOV-2001','DD-MON-YYYY')
AND order_dt < TO_DATE('01-DEC-2001','DD-MON-YYYY')
AND cancelled_dt IS NULL)
WHERE month = 11 and year = 2001;

--Modificamos cuatro columnas en la tabla, los WHERE en las 4 son identicos

--Poblando las tablas 
UPDATE monthly_orders
SET (tot_orders, max_order_amt, min_order_amt, tot_amt) =
(SELECT COUNT(*), MAX(sale_price), MIN(sale_price), SUM(sale_price)
FROM cust_order
WHERE order_dt >= TO_DATE('01-NOV-2001','DD-MON-YYYY')
AND order_dt < TO_DATE('01-DEC-2001','DD-MON-YYYY')
AND cancelled_dt IS NULL)
WHERE month = 11 and year = 2001;

Whereas the previous example demonstrates the use of a multiple-column subquery
in the SETclause of an UPDATE statement, such subqueries may also be utilized in
the WHERE clause of a SELECT, UPDATE, or DELETE statement. The next statement
deletes all items from open orders that include discontinued parts:
DELETE FROM line_item
WHERE (order_nbr, part_nbr) IN
(SELECT c.order_nbr, p.part_nbr
FROM cust_order c, line_item li, part p
WHERE c.ship_dt IS NULL AND c.cancelled_dt IS NULL
AND c.order_nbr = li.order_nbr
AND li.part_nbr = p.part_nbr
AND p.status = 'DISCONTINUED');
Note the use of the IN operator in the WHERE clause. Two columns are listed
together in parentheses prior to the IN keyword. Values in these two columns are
compared to the set of two values returned by each row of the subquery. If a match is
found, the row is removed from the line_item table.

--Correlated Subqueries
--Asi se le llama a un subquery que esta referenciando a una o mas columnas desde su contenido 
--En el siguiente ejemplo la referencia a p.part_nbr es lo que hace el subquery corelacionado
--Usualmente son usados para probar si las relaciones existen sin importar la cardinalidad

SELECT p.part_nbr, p.name
FROM supplier s, part p
WHERE s.name = 'Acme Industries'
AND s.supplier_id = p.supplier_id
AND 10 <=
(SELECT COUNT(*)
FROM cust_order co, line_item li
WHERE li.part_nbr = p.part_nbr
AND li.order_nbr = co.order_nbr
AND co.order_dt >= TO_DATE('01-DEC-2001','DD-MON-YYYY'));

--Inline Views
SELECT d.dept_id, d.name, emp_cnt.tot
FROM department d,
(SELECT dept_id, COUNT(*) tot
FROM employee
GROUP BY dept_id) emp_cnt
WHERE d.dept_id = emp_cnt.dept_id;
--En el ejemplo el FROM referencia la tabla departamento y una Inline view llamada
--emp_cnt
--Los in line views nos permiten hacer acciones en un solo query que de otras formas talvez 
--requeririan multiples select 

--Query Execution
SELECT d.dept_id dept_id, d.name dept_name,
dept_orders.tot_orders tot_orders
FROM department d,
(SELECT e.dept_id dept_id, SUM(emp_orders.tot_orders) tot_orders
FROM employee e,
(SELECT sales_emp_id, COUNT(*) tot_orders
FROM cust_order
WHERE order_dt >= TRUNC(SYSDATE) — 365
AND cancelled_dt IS NULL
GROUP BY sales_emp_id
) emp_orders
WHERE e.emp_id = emp_orders.sales_emp_id
GROUP BY e.dept_id
) dept_orders
WHERE d.dept_id = dept_orders.dept_id;

--El query anterior puede ser descompuesto mediante varios SELECT tal como se habia mencionado
SELECT sales_emp_id, COUNT(*) tot_orders
FROM cust_order
WHERE order_dt >= TRUNC(SYSDATE) — 365
AND cancelled_dt IS NULL
GROUP BY sales_emp_id;

--El query principal involucra las inline views, lo que estamos haciendo es ir descomponiendolo para
--ver como se puede llegar al mismo resultado de otra forma
--que seria de cierta manera mas laboriosa
SELECT e.dept_id dept_id, SUM(emp_orders.tot_orders) tot_orders
FROM employee e,
(SELECT sales_emp_id, COUNT(*) tot_orders
FROM cust_order
WHERE order_dt >= TRUNC(SYSDATE) — 365
AND cancelled_dt IS NULL
GROUP BY sales_emp_id
) emp_orders
WHERE e.emp_id = emp_orders.sales_emp_id
GROUP BY e.dept_id;

spool off