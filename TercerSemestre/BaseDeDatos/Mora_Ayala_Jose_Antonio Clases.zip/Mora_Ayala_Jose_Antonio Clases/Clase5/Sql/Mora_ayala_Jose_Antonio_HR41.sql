spool  %ORA_OUT%\s41.txt
REM                                               HR41.sql
rem despliega atributos de la tabla employees del esquema HR
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME
  from HR.employees
  where EMPLOYEE_ID < 120;
spool off