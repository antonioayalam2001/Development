spool F:\Documents\BasedeDatos\Capitulo4MO\Capitulo4MO.txt

--  =======================================================================================
--  ||Capitulo 4 Ejercicios Mastering Oracle SQL                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Mastering Oracle SQL                             ||
--* ||by Sanjay Mishra and Alan Beaulieu                                                ||
--* ||Copyright © 2002 O’Reilly & Associates, Inc. All rights reserved.                 ||
--* ||Printed in the United States of America.                                          ||
--* ||Published by O’Reilly & Associates, Inc., 1005 Gravenstein Highway North,         ||
--* ||Sebastopol, CA 95472.                                                             ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 4 Mastering Oracle SQL'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 210
Connect MasterOracle/MasterOracle;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos MasterOracle
show user;
--  Conociendo nuestras tablas 
desc Customer;
SELECT MAX(SALARY) FROM EMPLOYEE;
    DESC CUST_ORDER

SELECT ORDER_NBR, CUST_NBR, SALES_EMP_ID, SALE_PRICE,
    ORDER_DT, EXPECTED_SHIP_DT
    FROM CUST_ORDER;

--  NULLs and Aggregate Functions
SELECT COUNT(*), COUNT(SALE_PRICE) FROM CUST_ORDER;

SELECT COUNT(*), SUM(SALE_PRICE), AVG(SALE_PRICE)
    FROM CUST_ORDER;
--  AVG
SELECT AVG(NVL(SALE_PRICE,0)) FROM CUST_ORDER;

--  Use of DISTINCT and ALL
SELECT COUNT(CUST_NBR), COUNT(DISTINCT CUST_NBR), COUNT(ALL CUST_NBR)
    FROM CUST_ORDER;

SELECT COUNT(ALL SALE_PRICE) FROM CUST_ORDER;

SELECT STDDEV_POP(ALL SALE_PRICE)
    FROM CUST_ORDER;

--  The GROUP BY Clause
SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR;

SELECT 'CUSTOMER', CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR;
    SELECT 'CUSTOMER', CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY 'CUSTOMER', CUST_NBR;

--  Usando ROWNUM
SELECT ROWNUM, CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY ROWNUM, CUST_NBR;

SELECT ROWNUM, V.*
    FROM (SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER GROUP BY CUST_NBR) V;


--  USO de FROM

SELECT COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR;

SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR, ORDER_DT;

SELECT CUST_NBR, ORDER_DT, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR, ORDER_DT;

--  GROUP BY Clause and NULL Values
SELECT SALE_PRICE, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY SALE_PRICE;

SELECT SALE_PRICE, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY SALE_PRICE
    ORDER BY SALE_PRICE DESC;

--  GROUP BY Clause with WHERE Clause
SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    WHERE SALE_PRICE > 25
    GROUP BY CUST_NBR;

--  SELECT CUST_NBR, COUNT(ORDER_NBR)
--  FROM CUST_ORDER
--  GROUP BY CUST_NBR
--  WHERE SALE_PRICE > 25;
--  WHERE SALE_PRICE > 25
--  *
--  ERROR at line 4:
--  ORA-00933: SQL command not properly ended

--  The HAVING Clause
--  Filtra los grupos generados por el Group By
SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR
    HAVING CUST_NBR < 260;

--  Solucionando error del ejemplo anterior
SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR
    HAVING COUNT(ORDER_NBR) > 2;

--  SELECT CUST_NBR, COUNT(ORDER_NBR)
--  FROM CUST_ORDER
--  GROUP BY CUST_NBR
--  HAVING ORDER_DT < SYSDATE;
--  HAVING ORDER_DT < SYSDATE
--  *
--  ERROR at line 4:
--  ORA-00979: not a GROUP BY expression

--  El having nos presenta una restriccion importante la cual consiste en que 
--  La condcion solo puede referir a expresiones realizadas en el SELEcT o GROUP BY 
--  declaracion si especificamos una expresion en el HAVING habra un error

--  No importa si realizamos el gruop by antes o despues del having
SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    GROUP BY CUST_NBR
    HAVING COUNT(ORDER_NBR) > 1;
    SELECT CUST_NBR, COUNT(ORDER_NBR)
    FROM CUST_ORDER
    HAVING COUNT(ORDER_NBR) > 1
    GROUP BY CUST_NBR;

    spool off;