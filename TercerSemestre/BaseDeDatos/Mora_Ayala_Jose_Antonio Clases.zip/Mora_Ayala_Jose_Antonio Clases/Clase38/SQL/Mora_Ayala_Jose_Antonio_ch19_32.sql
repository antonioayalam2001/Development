spool F:\Base\Clases\ch19_32.txt

/*
Escriba un procedimiento que incluya un código postal, la ciudad y el estado
 e inserte los valores en el código postal.
 Debe verificar si el código postal ya está en la base de datos.
 Si es así, una excepción debería aparecer generar un mensaje de error.
 Escriba un bloque anónimo que utilice 
 el procedimiento e inserte su código postal.
*/

CREATE OR REPLACE PROCEDURE insert_zip
	(I_ZIPCODE IN zipcode.zip%TYPE,
	I_CITY IN zipcode.city%TYPE,
	I_STATE IN zipcode.state%TYPE)
AS
	v_zipcode zipcode.zip%TYPE;
	v_city zipcode.city%TYPE;
	v_state zipcode.state%TYPE;
	v_dummy zipcode.zip%TYPE;
BEGIN
	v_zipcode := i_zipcode;
	v_city := i_city;
	v_state := i_state;
--
	SELECT zip
		INTO v_dummy
		FROM zipcode
		WHERE zip = v_zipcode;
--
	DBMS_OUTPUT.PUT_LINE('The zipcode '||v_zipcode||
		' is already in the database and cannot be'||
		' reinserted.');
	DBMS_OUTPUT.PUT_LINE('El código postal '||v_zipcode||
		' ya existe y no puede ser insertado'||
		chr(10));
--
EXCEPTION
	WHEN NO_DATA_FOUND THEN
		INSERT INTO ZIPCODE
		VALUES (v_zipcode, v_city, v_state, user, sysdate,
			user, sysdate);
		WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE ('There was an unknown error '||
		'in insert_zip.');
		DBMS_OUTPUT.PUT_LINE ('Existe un error desconocido'||
		'al insertar el código postal ');
END;
/


SET SERVEROUTPUT ON
BEGIN
insert_zip (10039, 'No Where', 'ZZ');
END;
/

BEGIN
insert_zip (10049, 'Lugar desconocido', 'ZZ');
END;
/

select zip,city,state 
	from zipcode
	where zip in (10039,10049);
	
	
	

spool off;