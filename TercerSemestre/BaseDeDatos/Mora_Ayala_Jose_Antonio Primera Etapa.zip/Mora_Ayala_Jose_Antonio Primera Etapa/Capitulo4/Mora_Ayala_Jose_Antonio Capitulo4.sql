spool F:\Documents\BasedeDatos\Capitulo4\Capitulo4.txt

--  =======================================================================================
--  ||Capitulo 4 Ejercicios SQLOracle By Example                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Oracle SQL by Example Third Edition              ||
--* ||Rischert, Alice.                                                                  ||
--* ||Oracle SQL by example / Alice Rischert.-- 3rd ed.                                 ||
--* ||p. cm. -- (Prentice Hall PTR Oracle series)                                       ||
--* ||Rev. ed. of: Oracle SQL interactive workbook, 2003.                               ||
--* ||Includes indexes.                                                                 ||
--* ||ISBN 0-13-145131-6                                                                ||
--* ||1. SQL (Computer program language) 2. Oracle (Computer file)                      ||
--* ||I. Rischert, Alice. Oracle SQL interactive workbook. II. Title. III. Series.      ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 4'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2


SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 110
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;

--    Applying Oracle's DATE Format
--    Changing The DATE Display Format


SELECT last_name, registration_date
   FROM student
  WHERE student_id IN (123, 161, 190);

SELECT last_name, registration_date,
        TO_CHAR(registration_date, 'MM/DD/YYYY')
        AS "Formatted"
   FROM student
  WHERE student_id IN (123, 161, 190);


SELECT last_name,
        TO_CHAR(registration_date, 'Dy') AS "1.Day",
        TO_CHAR(registration_date, 'DY') AS "2.Day",
        TO_CHAR(registration_date, 'Month DD, YYYY')
          AS "Look at the Month",
        TO_CHAR(registration_date, 'HH:MI pm') AS "Time"
   FROM student
  WHERE student_id IN (123, 161, 190);

--    Using Special Format Masks

SELECT last_name,
        TO_CHAR(registration_date, 'fmMonth ddth, YYYY')
        "Eliminating Spaces",
        TO_CHAR(registration_date, 'Ddspth "of" fmMonth')
        "Spelled out"
   FROM student
  WHERE student_id IN (123, 161, 190);

--    How To Perform A DATE Search
--  Realizando busqueda mediante el uso de las fechas, las cuales se especifican
--  como cadena de caracteres 

SELECT last_name, registration_date
   FROM student
  WHERE registration_date = TO_DATE('22-JAN-2003', 'DD-MON-YYYY');

--    Implicit Conversion and Default DATE Format
--  Realizando conversiones del formato de fecha y con el formato
--  predeterminado

SELECT last_name, registration_date
   FROM student
  WHERE registration_date = '22-JAN-2003';

SELECT last_name, registration_date
   FROM student
WHERE registration_date = '22-JAN-03';


--    The RR DATE Format Mask and The Previous Century

SELECT SYS_CONTEXT ('USERENV', 'NLS_DATE_FORMAT')
   FROM dual;

--    The RR DATE Format Mask and The Previous Century

SELECT TO_CHAR(TO_DATE('17-OCT-67','DD-MON-RR'),'YYYY') "1900",
        TO_CHAR(TO_DATE('17-OCT-17','DD-MON-RR'),'YYYY') "2000"
   FROM dual;


--    Time and The TRUNC Function

SELECT student_id, TO_CHAR(enroll_date, 'DD-MON-YYYY HH24:MI:SS')
   FROM enrollment
  WHERE TRUNC(enroll_date) = TO_DATE('07-FEB-2003', 'DD-MON-YYYY');

--    The ANSI DATE and ANSI TIMESTAMP Formats

SELECT student_id, TO_CHAR(enroll_date, 'DD-MON-YYYY HH24:MI:SS')
   FROM enrollment
  WHERE enroll_date >= DATE '2003-02-07'
    AND enroll_date <  DATE '2003-02-08';


SELECT student_id, TO_CHAR(enroll_date, 'DD-MON-YYYY HH24:MI:SS')
   FROM enrollment
  WHERE enroll_date >= TIMESTAMP '2003-02-07 00:00:00'
    AND enroll_date <  TIMESTAMP '2003-02-08 00:00:00';

--    The Fill Mode

SELECT course_no, section_id,
        TO_CHAR(start_date_time, 'Day DD-Mon-YYYY')
   FROM section
  WHERE TO_CHAR(start_date_time, 'Day') = 'Tuesday';


SELECT course_no, section_id,
        TO_CHAR(start_date_time, 'Day DD-Mon-YYYY')
   FROM section
  WHERE TO_CHAR(start_date_time, 'fmDay') = 'Tuesday';


SELECT section_id,
        TO_CHAR(start_date_time, 'DD-MON-YYYY HH24:MI:SS')
   FROM section
WHERE TRUNC(start_date_time) BETWEEN '1-JUL-03' AND '31-JUL-03';

--    TO_CHAR Function Versus TO_DATE Function
--  Usamos TO_DATE cuando realizamos una clausula de tipo select o donde usamos un WHERE
--  TO_DATE convierte el texto a el tipo de Dato de Fecha
--  Es necesario realizar una conversion a TO_CHAr despues de un TO_DATE para mostrar el dia 
--  To_CHAR tambien puede ser usado cuando se emplea WHERE

SELECT course_no, section_id,
        TO_CHAR(start_date_time, 'Day DD-Mon-YYYY')
   FROM section
  WHERE TO_CHAR(start_date_time, 'fmDay') = 'Tuesday';

SELECT TO_CHAR(TO_DATE('31-DEC-1899', 'DD-MON-YYYY'),'Mon')
   FROM dual;

--    TO_CHAR Function Versus TO_DATE Function

SELECT 'Section '||section_id||' begins on '||
        TO_CHAR(start_date_time, 'fmDay')||'.' AS "Start"
   FROM section
  WHERE section_id IN (146, 127, 121, 155, 110, 85, 148)
  ORDER BY TO_CHAR(start_date_time, 'D');

--    Performing Date And Time Math
--    The SYSDATE Function

SELECT SYSDATE, TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI')
  FROM dual;

--    The ROUND Function
--  Permite redondear los meses, dias y años

SELECT TO_CHAR(SYSDATE,'DD-MON-YYYY HH24:MI') now,
        TO_CHAR(ROUND(SYSDATE),'DD-MON-YYYY HH24:MI') day,
        TO_CHAR(ROUND(SYSDATE,'MM'),'DD-MON-YYYY HH24:MI')
         mon
   FROM dual;

--    Performing Arithmethic On Dates
--  REalizar operaciones aritmeticas en las fechas
--  La fraccion es la que representa la cantidad de horas que estamos sumando

SELECT TO_CHAR(SYSDATE, 'MM/DD HH24:MI:SS') now,
        TO_CHAR(SYSDATE+3/24, 'MM/DD HH24:MI:SS')
        AS now_plus_3hrs,
        TO_CHAR(SYSDATE+1, 'MM/DD HH24:MI:SS') tomorrow,
        TO_CHAR(SYSDATE+1.5, 'MM/DD HH24:MI:SS') AS
        "36Hrs from now"
   FROM dual;

--    The EXTRACT Function
--  Sirve para obtener el dia,mes,año determinado de acuerdo a una fecha


SELECT TO_CHAR(start_date_time, 'DD-MON-YYYY') "Start Date",
        EXTRACT(MONTH FROM start_date_time) "Month",
        EXTRACT(YEAR FROM start_date_time) "Year",
        EXTRACT(DAY FROM start_date_time) "Day"
   FROM section
  WHERE EXTRACT(MONTH FROM start_date_time) = 4
  ORDER BY start_date_time;

SELECT CURRENT_TIMESTAMP, LOCALTIMESTAMP
   FROM dual;

--    The SESSIONTIMEZONE Function

SELECT SESSIONTIMEZONE
  FROM dual;

--    The DBTIMEZONE Function

SELECT DBTIMEZONE
  FROM dual;

--    Extract Functions
--    The SYS_EXTRACT_UTC Function

SELECT SYS_EXTRACT_UTC(TIMESTAMP '2002-03-11 7:00:00 -8:00')
           "West coast to UTC",
        SYS_EXTRACT_UTC(TIMESTAMP '2002-03-11 10:00:00 -5:00')
           "East coast to UTC"
   FROM dual;

--    The EXTRACT Function and The TIMESTAMP Datatype

SELECT EXTRACT(HOUR FROM TIMESTAMP '2002-03-11 15:48:01.123') hour,
        EXTRACT(MINUTE FROM TIMESTAMP '2002-03-11 15:48:01.123') minute,
        EXTRACT(SECOND FROM TIMESTAMP '2002-03-11 15:48:01.123') second,
        EXTRACT(YEAR FROM TIMESTAMP '2002-03-11 15:48:01.123') year,
        EXTRACT(MONTH FROM TIMESTAMP '2002-03-11 15:48:01.123') month,
        EXTRACT(DAY FROM TIMESTAMP '2002-03-11 15:48:01.123') day
   FROM dual;

--    EXTRACT and The TIMESTAMP With Time Zone Datatype

SELECT col_timestamp_w_tz,
        EXTRACT(YEAR FROM col_timestamp_w_tz) year,
        EXTRACT(MONTH FROM col_timestamp_w_tz) month,
        EXTRACT(DAY FROM col_timestamp_w_tz) day,
        EXTRACT(HOUR FROM col_timestamp_w_tz) hour,
        EXTRACT(MINUTE FROM col_timestamp_w_tz) min,
        EXTRACT(SECOND FROM col_timestamp_w_tz) sec
   FROM date_example;

--    The INTERVAL Datatypes
--    Using INTERVALS

SELECT student_id, registration_date,
        registration_date+TO_YMINTERVAL('01-06') "Grad. Date"
   FROM student
  WHERE student_id = 123;
--    The INTERVAL Datatypes
--    EXTRACT and INTERVALS

SELECT EXTRACT(MINUTE FROM INTERVAL '12:51' HOUR TO MINUTE)
   FROM dual;

SELECT DISTINCT TO_CHAR(created_date, 'DD-MON-YY HH24:MI')"CREATED_DATE",
                 TO_CHAR(start_date_time, 'DD-MON-YY
HH24:MI')"START_DATE_TIME",
                 start_date_time-created_date"Decimal",
                 NUMTODSINTERVAL(start_date_time-created_date,
'DAY')"Interval"
   FROM section
  ORDER BY 3;

SELECT col_timestamp, SYSTIMESTAMP,
        (SYSTIMESTAMP - col_timestamp) DAY(4) TO SECOND
        "Interval Day to Second"
   FROM date_example;

SELECT col_timestamp,
        (SYSTIMESTAMP - col_timestamp) YEAR TO MONTH
        "Interval Year to Month"
   FROM date_example;

--    Formatting Data

SELECT course_no, cost,
        TO_CHAR(cost, '999,999') formatted
   FROM course
  WHERE course_no < 25;

COL "SQL*PLUS" FORMAT 999,999

SELECT course_no, cost "SQL*PLUS",
        TO_CHAR(cost, '999,999') "CHAR"
   FROM course
  WHERE course_no < 25;


--   EXCERCISES
--  	Lab	4.1.1. Comparar un literal de texto con una columna DATE

--  	a) Muestre el número del curso, la ID de la sección y la fecha y hora de inicio de las 
--  		secciones que enseñado el 4 de mayo de 2003.

SELECT course_no, section_id, TO_CHAR(start_date_time, 'DD-MON-YYYY HH24:MI')
FROM section
WHERE start_date_time >= TO_DATE('04-MAY-2003', 'DD-MON-YYYY')
AND start_date_time < TO_DATE('05-MAY-2003', 'DD-MON-YYYY');

--  	b) Muestre los registros de los estudiantes que fueron modificados el 22 de enero de 2003 
--  		o antes. Muestre la fecha en que se modificó el registro y  concatene el nombre y 
--  		apellido de cada estudiante en una columna.

SELECT first_name||' '||last_name fullname, TO_CHAR(modified_date, 'DD-MON-YYYY HH:MI P.M.')
		"Modified Date and Time"
FROM student
WHERE modified_date < TO_DATE('01/23/2003','MM/DD/YYYY');

--   Lab	4.1.2. Aplicar modelos de formato

--  	a) Muestra el número del curso, la ID de la sección y la fecha y hora de inicio de las 
--  		secciones que comienzan los martes.

SELECT course_no, section_id,
TO_CHAR(start_date_time, 'DY DD-MON-YYYY')
FROM section
WHERE TO_CHAR(start_date_time, 'DY') = 'TUE';

--  	b) Indique el ID de la sección y la fecha y hora de inicio de todas las secciones que 
--  	comienzan y terminan en julio 2003.

SELECT section_id,
TO_CHAR(start_date_time, 'DD-MON-YYYY HH24:MI:SS')
FROM section
WHERE start_date_time >= TO_DATE('07/01/2003', 'MM/DD/YYYY')
AND start_date_time < TO_DATE('08/01/2003', 'MM/DD/YYYY');

--  	c) Determine el día de la semana para el 31 de diciembre de 1899.

SELECT TO_CHAR(TO_DATE('31-DEC-1899', 'DD-MON-YYYY'),'Dy')
FROM dual;

--   Lab 4.2.1. Comprender la función SYSDATE y realizar aritmética de fechas

--  	a) Determine el número de días entre el 13 de febrero de 1964 y el último día del mismo.
--  		mes y año.

SELECT LAST_DAY(TO_DATE('13-FEB-1964','DD-MON-YYYY')) lastday,
		LAST_DAY(TO_DATE('13-FEB-1964','DD-MON-YYYY')) - TO_DATE('13-FEB-1964','DD-MON-YYYY') days
FROM dual;

--  	b) Calcule el número de meses entre el 29 de septiembre de 1999 y el 17 de agosto de 2003.

SELECT MONTHS_BETWEEN(TO_DATE('17-AUG-2003','DD-MON-YYYY'),
		TO_DATE('29-SEP-1999','DD-MON-YYYY')) months
FROM dual;

--  	c) Agregue tres días a su fecha y hora actual.

SELECT TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS') "Current",
		TO_CHAR(SYSDATE+3, 'DD-MON-YYYY HH24:MI:SS') "Answer"
FROM dual;

--  	c) ¿Qué función puede utilizar para mostrar el componente de segundos de un TIMESTAMP
--  		columna de tipo de datos?

--  	Puede utilizar la función TO_CHAR o EXTRACT para mostrar componentes como el año, mes, 
--  		fecha, hora, minuto y segundos de las columnas de tipo de datos TIMESTAMP.

SELECT col_timestamp,
TO_CHAR(col_timestamp, 'SS') AS "CHAR Seconds",
EXTRACT(SECOND FROM col_timestamp) AS "EXTRACT Seconds"
FROM date_example;

--  	b) Enumere las columnas COURSE_NO y COST para los cursos que cuestan más de 1500. 
--  		En una tercera, cuarta y quinta columna, muestre el costo aumentado en un 15%. 
--  		Muestre las columnas de costo aumentado, una con un signo de dólar inicial y separe 
--  		los miles, y en otra columna muestre el mismo formato pero redondeado al dólar más cercano

SELECT course_no COST, cost OLDCOST, cost*1.15 NEWCOST,
		TO_CHAR(cost*1.15, '$999,999.99') "COSTO CF",
		TO_CHAR(ROUND(cost*1.15), '$999,999.99') "COSTO CFR"
FROM course
WHERE cost > 1500;

--  	c) Basado en la pregunta anterior, escriba la consulta para lograr este resultado. Utilice 
--  		la máscara de formato fm para eliminar los espacios extra.

SELECT 'The price for course# '||course_no||' has been increased to '||
		TO_CHAR(cost*1.15, 'fm$999,999.99')||'.' "Increase"
FROM course
WHERE cost > 1500;


spool off