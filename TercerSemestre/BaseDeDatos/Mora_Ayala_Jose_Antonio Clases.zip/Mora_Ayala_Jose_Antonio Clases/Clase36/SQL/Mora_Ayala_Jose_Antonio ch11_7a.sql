spool F:\Base\Clases\Mora_Ayala_Jose_Antonio_ch11_7a.txt

-- ch11_7a.sql
-- Trabajando con Student/learn
DECLARE
	CURSOR c_student IS
		SELECT student_id, last_name, first_name
			FROM student
		WHERE student_id < 110;
	BEGIN
	FOR r_student IN c_student
	LOOP
		INSERT INTO table_log
			VALUES(r_student.last_name);
	END LOOP;
END;
/
REM acciones previas crear la tabla log
drop table table_log;
create table table_log
	(description VARCHAR2(250)); 

col description format a40
select description from table_log;	

spool off;
