CONNECT SYSTEM
2001

CREATE USER Clase37 IDENTIFIED by Clase37
DEFAULT TABLESPACE users
TEMPORARY TABLESPACE temp;
GRANT CONNECT, RESOURCE TO Clase37;
GRANT CREATE ANY VIEW TO Clase37;
CONNECT Clase37/Clase37

--* Set null
set null sin_calif.

--* TABLAS DE BASE DE DATOS

@F:\DOCUMENTS\BASEDEDATOS\O11\createStudent.sql
@F:\DOCUMENTS\BASEDEDATOS\O11\sql_book_add_tables.sql

spool F:\DOCUMENTS\BASEDEDATOS\Clases\clase12_1_1\Clase37.txt
spool off

SET LINESIZE 90;
SET PAGESIZE 99;
SET COLSEP ' |=| ';
COL nombre_columna FORMAT Anumero_de_caracter;
COL nombre_columna FORMAT Anumero_de_caracter;

--* COMANDOS CONTAR VER USUSARIOS
SELECT * FROM all_users
ORDER BY created;

--* Muestra numero de tablas
desc dict 

/*
--* otorgar privilegio de lectura de la tabla hr.employees
--* al usuario Clase37 
--* tabla que es propietario el usuario HR
--* otorgarlo desde el usuario SYS
*/)

grant select on student. to Clase37;
grant select on hr.departments to Clase37;

BEGIN
FOR t IN (SELECT * FROM user_tables) 
LOOP   
EXECUTE IMMEDIATE 'GRANT SELECT ON ' || t.table_name || 'Clase37';    
END LOOP;
END;
/


NATURAL JOIN
Muestra auqello que es igual en ambas tablas, donde las duplas coinciden



--* Viendo tablas de un usuario

select table_name, tablespace_name, status, pct_free, pct_used
   from user_tables;

select table_name
  from user_tables
  order by table_name;

--Tablas del usuario con fecha de creacion
select object_name, created from user_objects
where object_name in (select table_name from user_tables )
AND object_type = 'TABLE'
order by created desc;


--* RESTRICCIONES
alter table table_name
   add constraint constraint_name
      check(Atribute_name "condition");

alter table EMPLOYEE
	add constraint bandera_asist_profesor_ck    
		check(bandera_asist_profesor IN ('V','F'));

      el in nos indica que solo debe poseer esos valores V o F



INITIALLY DEFERRED DEFERRABLE
Agregar a las restricciones de llave para que podamos añadir tuplas
sin que antes se verifique la llave en la LLAVE FORANEA

Diferidas aquellas que sean reflexivas 

TITULO

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Clase'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

CAMBIOS
/* Cuando hay un cambio en el atributo genera 2 espacios */
break on vuelo skip 2 duplicates 

clear break
--* cuando ya no queremos el break


--* Comando para ver que comando utilizar para borrar todas las tablas del usuario
SELECT 'DROP TABLE '||table_name||' CASCADE CONSTRAINTS;' FROM user_tables;


--* SET SERVEROUTPUT ON
SET SERVEROUTPUT ON
--* Sirve para poder ver los comentarios de la consola hechos con
DBMS_OUTPUT.PUT_LINE (vr_student.first_name||' '
			||vr_student.last_name||' has an ID of Tiene un ID de : 156');


--* Contanto el numero de tuplas que hay
select count(*) from student;
