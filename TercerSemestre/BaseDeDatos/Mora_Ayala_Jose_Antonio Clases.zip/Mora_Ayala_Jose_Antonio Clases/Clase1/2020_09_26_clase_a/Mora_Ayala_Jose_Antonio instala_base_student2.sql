rem instala la base student

@@C:\Users\ORA_bases\O11\createStudent.sql
@@C:\Users\ORA_bases\O11\CIFRAS_CONTROL_Student.sql
rem borra la base Student 
REM Borra la base y sus tablas 
rem @@C:\Users\ORA_bases\O11\dropStudent.sql
rem @@C:\Users\ORA_bases\O11\createStudent.sql


