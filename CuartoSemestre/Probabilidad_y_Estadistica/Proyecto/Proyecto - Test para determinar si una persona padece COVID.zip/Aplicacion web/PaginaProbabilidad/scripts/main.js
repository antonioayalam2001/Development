let cerrar = document.querySelectorAll(".close")[0];
let abrir = document.querySelectorAll(".button")[0];
let ventana = document.querySelectorAll(".ventana")[0];
let modalC = document.querySelectorAll(".modal")[0];


abrir.addEventListener("click",function(e){
    e.preventDefault();
    modalC.style.opacity="1";
    modalC.style.visibility= "visible"
    ventana.classList.toggle("ventana-close");
});

cerrar.addEventListener("click",function(e){
    e.preventDefault();
    ventana.classList.toggle("ventana-close");
    setTimeout(function(){
        modalC.style.opacity="0";
        modalC.style.visibility= "hidden"
    },900)
});

window.addEventListener("click",function(e){
    if(e.target == modalC){
        ventana.classList.toggle("ventana-close");

        setTimeout(function(){
            modalC.style.opacity="0";
            modalC.style.visibility= "hidden"
        },900)
    }
});

