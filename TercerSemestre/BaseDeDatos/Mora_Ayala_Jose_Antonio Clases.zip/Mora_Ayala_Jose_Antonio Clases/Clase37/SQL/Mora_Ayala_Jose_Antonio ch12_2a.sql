spool F:\Base\Clases\Mora_Ayala_Jose_Antonio_ch12_2a.txt

-- ch12_2a.sql
DECLARE
	CURSOR c_course IS
		SELECT course_no, cost
			FROM course FOR UPDATE;
BEGIN
	FOR r_course IN c_course
	LOOP
		IF r_course.cost < 998
		--2500
		THEN
			UPDATE course
				SET cost = r_course.cost + 19.90
			WHERE course_no = r_course.course_no;
		END IF;
	END LOOP;
END;
/
rem consultas previas 
SELECT course_no, cost,
	description,prerequisite
			FROM course;
			
desc course 
spool off;