spool F:\Base\Clases\ch11_6a.txt

-- ch11_6a.sql
REM Select only students who have a student_id of less than 110.
REM STUDENT_ID,LAST_NAME, FIRST_NAME, and a count of 
REM the number of classes they are enrolled in
REM  (using the enrollment table).
REM 
SET SERVEROUTPUT ON
DECLARE
	CURSOR c_student_enroll IS
	SELECT s.student_id, first_name, last_name,
		COUNT(*) enroll,
		(CASE
			WHEN count(*) = 1 Then ' class.'
			WHEN count(*) is null then
			' no classes.'
		ELSE ' classes.'
		END) class
	FROM student s, enrollment e
	WHERE s.student_id = e.student_id
		AND s.student_id <110
	GROUP BY s.student_id, first_name, last_name;
	r_student_enroll c_student_enroll%ROWTYPE;
BEGIN
	OPEN c_student_enroll;
	LOOP
		FETCH c_student_enroll INTO r_student_enroll;
		EXIT WHEN c_student_enroll%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('Student INFO: ID '||
			r_student_enroll.student_id||' is '||
			r_student_enroll.first_name|| ' ' ||
			r_student_enroll.last_name||
			' is enrolled in '||r_student_enroll.enroll||
			r_student_enroll.class);
	END LOOP;
	CLOSE c_student_enroll;
EXCEPTION
	WHEN OTHERS
	THEN
		IF c_student_enroll %ISOPEN
	THEN
		CLOSE c_student_enroll;
	END IF;
END;
/

REM CONSULTAS PREVIAS
rem desplegar en cuantas asignaturas estan
rem insxritos los alumnos con matriculas 
rem menores a 110 ordenados por student_id
rem 
	SELECT s.student_id, first_name, last_name,
		COUNT(*) INSCRITOS_EN,
		(CASE
			WHEN count(*) = 1 Then ' Asignatura'
			WHEN count(*) is null then
			' ninguna.'
		ELSE ' Asignaturas.'
		END) class
	FROM student s, enrollment e
	WHERE s.student_id = e.student_id
		AND s.student_id <110
	GROUP BY s.student_id, first_name, last_name
	order by 1;
	
	
rem escenario dos 
rem  ordenar los estudiantes por student_id 
rem al generar el CURSOR 
REM 
DECLARE
	CURSOR c_student_enroll IS
	SELECT s.student_id, first_name, last_name,
		COUNT(*) enroll,
		(CASE
			WHEN count(*) = 1 Then ' class.'
			WHEN count(*) is null then
			' no classes.'
		ELSE ' classes.'
		END) class
	FROM student s, enrollment e
	WHERE s.student_id = e.student_id
		AND s.student_id <110
	GROUP BY s.student_id, first_name, last_name
	ORDER BY 1;
	r_student_enroll c_student_enroll%ROWTYPE;
BEGIN
	OPEN c_student_enroll;
	LOOP
		FETCH c_student_enroll INTO r_student_enroll;
		EXIT WHEN c_student_enroll%NOTFOUND;
		DBMS_OUTPUT.PUT_LINE('Student INFO: ID '||
			r_student_enroll.student_id||' is '||
			r_student_enroll.first_name|| ' ' ||
			r_student_enroll.last_name||
			' is enrolled in '||r_student_enroll.enroll||
			r_student_enroll.class);
	END LOOP;
	CLOSE c_student_enroll;
	DBMS_OUTPUT.PUT_LINE ('Final'||chr(13)||chr(10)||chr(10)||
	' Termine'||chr(07)||chr(07)||chr(07));
EXCEPTION
	WHEN OTHERS
	THEN
		IF c_student_enroll %ISOPEN
	THEN
		CLOSE c_student_enroll;
	END IF;
END;
/
spool off;	