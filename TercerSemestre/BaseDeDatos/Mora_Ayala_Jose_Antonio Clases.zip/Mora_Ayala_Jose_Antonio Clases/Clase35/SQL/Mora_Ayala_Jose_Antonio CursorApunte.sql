spool F:\Base\Clases\CursorApunte.txt
--* Cursor IMPLICITO
--* Cada que se realiza una sentencia que devuelve UN SOLO DATO
--* Se asocia de manera automatica con cada sentencia de manipulacion
--* de datos ocmo (UPDATE, INSERT, DELETE)
--* Es usado en: INSERT, UPDATE, DELETE, SELECT INTO
--* Durante el proceso de un cursor implicito Oracle
--* automaticamente realiza OPEN,FETCH (busqueda),CLOSE operaciones
--! ROWCOUNT.SQL%ROWCOUNT
--* Indica el numero de tuplas actualizadas
--* DBMS_OUTPUT.PUT_LINE(ROWCOUNT.SQL%ROWCOUNT);

--* Oracle declara un cursor explicito, el cual permite a cada una de las sentencias  
--* cada una de las filas de datos que el cursor haya
--* regresado (cuando es mas de una tupla)
--* 
--* VENTAJAS
--* 1.Da al programador un mayor control
--* PASOS
--* 1. Declaracion: Inicializa el cursos
--* 2. Apertura: Asigna memoria
--* 3. Busqueda (fetching): Recupera datos
--* 4. Cierre: Debe ser cerrado para liberar la memoria
--! DECLARACION 
--! CURSOR c_cursor_name IS select statement 
--* 
--* 
--* 
spool off;