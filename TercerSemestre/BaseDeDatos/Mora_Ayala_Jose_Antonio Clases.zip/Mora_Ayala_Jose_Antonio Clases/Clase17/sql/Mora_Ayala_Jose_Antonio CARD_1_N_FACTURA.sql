 spool F:\Base\Clases\CARD_1_N_FACTURA.txt
 DROP TABLE FACTURA cascade constraints;

 create table factura(
  factura_ID number(3) constraint tot_fact_NN   NOT NULL,
  fecha_emision date   constraint fech_emis_NN  NOT NULL,
  total_factura number (6,2),
  constraint factura_pk primary key (factura_ID)
  );


 DROP TABLE NOTA_VENTA cascade constraints;


 CREATE TABLE NOTA_VENTA(
   NOTA_ID NUMBER(3),
   FECHA_VENTA DATE             constraint fecha_venta_NN not null,
   TOTAL_NOTA_VENTA NUMBER(6,2) constraint tot_venta_NN   not null,
   constraint nota_pk primary key (nota_ID)
   );


 DROP TABLE fact_nota cascade constraints;


 create table fact_nota (
    nota_id number(3)            constraint nota_id_NN NOT NULL,
    factura_id  number (3)       constraint fact_id_NN NOT NULL,
    descuento number (3,2),
    constraint nota_id_pk primary key (nota_id),
    constraint factura_ID_fk foreign key(factura_id)
    references factura(factura_ID)
    );

 
INSERT INTO FACTURA VALUES (100,TO_DATE('10/02/2020','DD/MM/RR'),250.30);
INSERT INTO FACTURA VALUES (200,TO_DATE('10/02/2020','DD/MM/RR'),25.30);
INSERT INTO FACTURA VALUES (300,TO_DATE('10/02/2020','DD/MM/RR'),50.30);
INSERT INTO FACTURA VALUES (400,TO_DATE('10/02/2020','DD/MM/RR'),2500.30);
INSERT INTO FACTURA VALUES (500,TO_DATE('10/02/2020','DD/MM/RR'),100.30);
INSERT INTO FACTURA VALUES (600,TO_DATE('10/02/2020','DD/MM/RR'),75.30);
INSERT INTO FACTURA VALUES (700,TO_DATE('10/02/2020','DD/MM/RR'),99.30);
INSERT INTO FACTURA VALUES (710,TO_DATE('10/02/2020','DD/MM/RR'),9.30);
INSERT INTO FACTURA VALUES (720,TO_DATE('10/02/2020','DD/MM/RR'),999.30);

desc factura;
select * from factura;


INSERT INTO nota_venta values (10,TO_DATE('10/02/2020','DD/MM/RR'),150.30);
INSERT INTO nota_venta values (20,TO_DATE('10/02/2020','DD/MM/RR'),80.00);
INSERT INTO nota_venta values (30,TO_DATE('10/02/2020','DD/MM/RR'),20.00);
INSERT INTO nota_venta values (40,TO_DATE('10/02/2020','DD/MM/RR'),7.30);
INSERT INTO nota_venta values (50,TO_DATE('10/02/2020','DD/MM/RR'),75.30);
INSERT INTO nota_venta values (60,TO_DATE('10/02/2020','DD/MM/RR'),25.00);
INSERT INTO nota_venta values (70,TO_DATE('10/02/2020','DD/MM/RR'),3.30);
INSERT INTO nota_venta values (80,TO_DATE('10/02/2020','DD/MM/RR'),75.30);
INSERT INTO nota_venta values (85,TO_DATE('10/02/2020','DD/MM/RR'),75.30);
INSERT INTO nota_venta values (86,TO_DATE('10/02/2020','DD/MM/RR'),75.30);

desc NOTA_VENTA;
select * from NOTA_VENTA;


INSERT INTO fact_nota values (10,100,.05);
INSERT INTO fact_nota values (20,100,.05);
INSERT INTO fact_nota values (30,100,.05);
INSERT INTO fact_nota values (40,200,.05);
INSERT INTO fact_nota values (40,200,.05);
INSERT INTO fact_nota values (40,200,.05);
INSERT INTO fact_nota values (50,500,.05);
INSERT INTO fact_nota values (60,500,.05);
INSERT INTO fact_nota values (70,700,.05);
INSERT INTO fact_nota values (80,600,.05);



 select * from factura;
 col total_nota_venta format 999.99
 select * from nota_venta;

 rem verificando atributos en comun
 select * from factura natural join nota_venta;
desc factura;
desc nota_venta;

rem no hay atributos en comun por lo que genera un producto cartesiano

select * from factura f,nota_venta n , fact_nota fn
where f.factura_ID = fn.factura_ID and n.nota_ID = fn.nota_ID;

 rem solo unos atributos
 rem
 select f.factura_ID,n.nota_ID,f.total_factura,
     n.total_nota_venta,fn.descuento,n.fecha_venta
  from factura f,nota_venta n , fact_nota fn
  where f.factura_ID = fn.factura_ID and n.nota_ID = fn.nota_ID;

 /*
 select f.factura_ID,n.nota_ID,f.total_factura,
    n.total_nota_venta,fn.descuento,n.fecha_venta
 from factura f,nota_venta n , fact_nota fn
 where f.factura_ID = fn.factura_ID (+) and n.nota_ID = fn.nota_ID;
 
 select f.factura_ID,n.nota_ID,f.total_factura,
    n.total_nota_venta,fn.descuento,n.fecha_venta
 from factura f,nota_venta n , fact_nota fn
 where f.factura_ID = fn.factura_ID  and n.nota_ID = fn.nota_ID (+);
 */
 
select f.factura_ID,fn.factura_ID,f.total_factura,
     fn.descuento
from factura f, fact_nota fn
where f.factura_id = fn.factura_id;

 
 rem  natual join & left & rigth entre factura y factura_nota
 rem
 
rem atributos en comun y los despliega
rem si no hay hace producto cartesiano
select nota_ID,factura_ID,total_factura,
       fn.descuento
from factura f natural join fact_nota fn;


 
select nota_ID,factura_ID,total_factura,
       fn.descuento
from factura f natural left join fact_nota fn;

 
select nota_ID,factura_ID,total_factura,
       fn.descuento
    from factura f natural right join fact_nota fn;

 rem
 rem
 rem
 rem  natual join & left & rigth entre nota_venta y factura_nota
 rem
 
select nota_ID,factura_ID,total_nota_venta,
      fn.descuento
from nota_venta n natural join fact_nota fn;


 
select nota_ID,factura_ID,total_nota_venta,
      fn.descuento
from nota_venta n natural left join fact_nota fn;

 
select nota_ID,factura_ID,total_nota_venta,
      fn.descuento
from nota_venta n natural right join fact_nota fn;

 
select n.nota_ID,fn.factura_ID,
     fn.descuento
from nota_venta n, fact_nota fn
where n.nota_id = fn.nota_id;


 
 
 REM SEGUNDA PARTE
 REM DESPLEAGAR LAS RESTRICCIONES DEL DICCIONARIO DE DATOS
 REM Y LAS COLUMNAS ASOCIADAS A LAS RESTRICCIONES.
COL OWNER FORMAT A10
COL NOMBRE FORMAT A19
COL TABLE_NAME      FORMAT A15
COL TIPO            FORMAT A4
COL STATUS          FORMAT A8
COL DEFERRABLE      FORMAT A15
COL DEFERRED        FORMAT A10
 
 select owner
, constraint_name NOMBRE
, constraint_type TIPO
, table_name
, status
, deferrable
, deferred
from user_constraints
where owner = 'CLASE17'
 and table_name in ('FACTURA','NOTA_VENTA','FAC_NOTA')
 ORDER BY 3,2;
 
rem deferrable permite que nosotros digamos cuando aplicar una restriccion
COL COLUMN_NAME FORMAT A19
 SELECT OWNER
, CONSTRAINT_NAME PODEMOSCAMBIARASIELNOM
, TABLE_NAME
, COLUMN_NAME
FROM USER_CONS_COLUMNS
where table_name in ('FACTURA','NOTA_VENTA','FAC_NOTA');

spool off;