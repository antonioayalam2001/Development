#!/bin/bash
echo Codificador
cd ..
cd Codificador
gcc main.c  -o main
./main TextoPrueba.txt
