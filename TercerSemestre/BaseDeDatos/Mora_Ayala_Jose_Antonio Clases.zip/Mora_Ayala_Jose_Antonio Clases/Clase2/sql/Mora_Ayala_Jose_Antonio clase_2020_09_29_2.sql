spool F:\Base\Clases\clase_2020_09_29_2.txt
	select 
		TO_CHAR(TO_DATE('1-Ene--4712 12:00 pm','dd-Mon-syyyy hh:mi am'), 'J') 
		from dual;
	select 
		TO_CHAR(TO_DATE('1-Ene-1 12:00 pm','dd-Mon-syyyy hh:mi am'), 'J') 
		from dual;
		
	select 
		TO_CHAR(TO_DATE('29-Sep-20 12:00 pm','dd-Mon-syyyy hh:mi am'), 'J') 
		from dual;
		
		select 
		dump(sysdate), dump(sysdate -365) from dual;
		
		select 
		TO_CHAR(TO_DATE('1-Ene-2020 12:00 pm','dd-Mon-syyyy hh:mi am'), 'J') 
		from dual;
				
		select 
		dump(TO_DATE('1/Ene/2020 12:00 pm','dd/Mon/syyyy hh:mi am'))
		from dual;
		

		select 
		TO_CHAR(TO_DATE('1-Ene-2019 12:00 pm','dd-Mon-syyyy hh:mi am'), 'J') 
		from dual;
				
		select 
		dump(TO_DATE('1/Ene/2019 12:00 pm','dd/Mon/syyyy hh:mi am'))
		from dual;
		spool off;