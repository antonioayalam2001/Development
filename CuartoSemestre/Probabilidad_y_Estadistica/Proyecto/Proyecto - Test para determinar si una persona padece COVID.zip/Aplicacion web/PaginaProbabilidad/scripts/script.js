//Futuro script que desarrollare cuando aprende lo necesario de Java como se debe no copiando codigo de una pagina
//sin entender al 100 su funcionamiento 

// Script en desarrollo NO MODIFICAR

var titulo = document.querySelector(".inst_titulo");
var preguntaElem = document.querySelector(".inst_test_para");
var textoBoton = document.querySelector(".inst_boton");
var iniciarTest = document.querySelector(".iniciarb");
var btnSi = document.querySelector(".btnS");
var btnNo = document.querySelector(".btnN");
var btnA = document.querySelector(".btnAdd");

const preguntaEnun = [
	"¿Usted padece de fiebre constante de entre 38 a 39 grados?", 
		"¿En lugar de tener fiebre su temperatura ha descendido más de lo normal (menor a 36 grados)", 
		"¿Tiene dificultad al momento de respirar?", 
		"¿Ha presentado picazón en diversas zonas del cuerpo?", 
		"¿Tanto su tes como sus ojos presentan un tono amarillo?", 
	"¿Usted padece de tos con flemas o sin flemas?", 
	"¿Padece de cansancio o fatiga constantes?",
	"¿Padece de molestias o dolores en general?", 
		"¿Estas molestias o dolores se generan principalmente en las articulaciones?", 
	"¿El dolor de garganta es un síntoma que usted porta?", 
	"¿Usted padece diarrea?", 
		"¿Tiene una edad menor a los 15 años?", 
	"¿Tiene conjuntivitis?",
	"¿Padece dolores de cabeza?", 
	"¿Las náuseas son constantes?", 
		"¿Tiene una edad menor a los 15 años?",
	"¿Tienes Disnea?",
	"¿Tiene pérdida de apetito constante?",
	"¿El dolor en el pecho es fuerte y punzante?"];

const 	covid = 1/12, 
		gripe = 1/8,
		hepatitis = 1/9, 
		neumonia = 1/7;

var cont = 0, aux = 0, edad = false, llave;

var	pCovid = 0,
	proCovid = 0,
	pGripe = 0,
	pHepatitis = 0, 
	pNeumonia = 0,
	age = 0,
	cess = 0,
	hepapotatoes = 0,
	conjuntivitis = false;

function cambiarPregunta() {

	if (preguntaEnun[cont] !== undefined ) {
		titulo.innerHTML = "Pregunta" + " " + (aux+1) + "<br><br>";
		preguntaElem.innerHTML = preguntaEnun[cont];
		aux++;
	}
	else {
		titulo.innerHTML = "Resultados";
		
		if (proCovid > 0 && age == 0) {
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "Descartamos las posibilidades de que tengas otra enfermedad por que padeces" +
									 "de sintomas especificos del COVID<br><br>";	
		}
		else if (conjuntivitis == true ){
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "Descartamos las posibilidades de que tengas otra enfermedad por que padeces " +
									 "de sintomas especificos del COVID<br><br>";
		}
		else if (hepapotatoes > 0 ){
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "sin embargo puedes tener Hepatitis con un " + (pHepatitis*100) + "%, recomendamos ir " +
									 "con un medico lo mas pronto posible para tu revision<br><br>";
		}
		else if (cess > 0 ){
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "sin embargo puedes tener Neumonia con un " + (pNeumonia*100) + "%, recomendamos ir " +
									 "con un medico lo mas pronto posible para tu revision<br><br>";
		}
		else if (proCovid == 0 && age == 0){
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "aun asi no padeces los sintomas especificos importantes del COVID por lo tanto" +
									 " puedes padecer de un gripe comun con un " + (pGripe*100) + "% <br><br>" +
									 "recomendamos ir al centro medico mas cercano para hacerte una prueba<br><br>";	
		}
		else if (proCovid > 0 && age > 0 ){
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "Descartamos las posibilidades de que tengas otra enfermedad por que padeces" +
									 "de sintomas especificos del COVID<br><br>";
		}
		else if (proCovid == 0 && age > 0 ){
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "aun asi no padeces los sintomas especificos importantes del COVID por lo tanto" +
									 " puedes padecer de un gripe comun con un " + (pGripe*100) + "% <br><br>" +
									 "recomendamos ir al centro medico mas cercano para hacerte una prueba<br><br>";	
		}
		else{
			preguntaElem.innerHTML = "La probabilidad de que tengas COVID es del: " + (pCovid*100) + "%<br><br>" +
									 "La probabilidad de que tengas gripe es del: " + (pGripe*100) + "%<br><br>" +
									 "La probabilidad de que tengas hepatitis es del: " + (pHepatitis*100) + "%<br><br>" +
									 "La probabilidad de que tengas neumonia es del: " + (pNeumonia*100) + "%<br><br>";
		}

		preguntaElem.style.textAlign = "center";

		btnSi.setAttribute("hidden", "true");
		btnNo.setAttribute("hidden", "true");

		btnA.removeAttribute("hidden");
	}
}

function validacion (){

		switch (cont) {

		case 0:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				pGripe = pGripe + gripe;
				cont = 5;
			}
			else {
				cont++;	
			}
		break;

		case 1:
			if ( llave == true ) {
				pHepatitis = pHepatitis + hepatitis;
				pNeumonia = pNeumonia + neumonia;
				cess++;
				cont++;
			}
			else {
				cont = 5;	
			}
		break;

		case 2:
			if ( llave == true ) {
				pHepatitis = pHepatitis + hepatitis;
				hepapotatoes++;
				cont++;
			}
			else {
				cont = 5;	
			}
		break;

		case 3:
			if ( llave == true ) {
				pHepatitis = pHepatitis + hepatitis;
				hepapotatoes++;
				cont++;
			}
			else {
				cont = 5;	
			}
		break;

		case 4:
			if ( llave == true ) {
				pHepatitis = pHepatitis + hepatitis;
				hepapotatoes++;
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 5:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				pGripe = pGripe + gripe;
				pNeumonia = pNeumonia + neumonia;
				cont++;
			}
			else {
				cont++;
			}
		break;

		case 6:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				pGripe = pGripe + gripe;
				pHepatitis = pHepatitis + hepatitis;
				pNeumonia = pNeumonia + neumonia;
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 7:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				pGripe = pGripe + gripe;
				pNeumonia = pNeumonia + neumonia;
				cont++;
			}
			else {
				cont+=2;	
			}
		break;

		case 8:
			if ( llave == true ) {
				pHepatitis = pHepatitis + hepatitis;
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 9:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				pGripe = pGripe + gripe;				
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 10:
			if ( llave == true ) {
				cont++;
			}
			else {
				cont+=2;	
			}
		break;

		case 11:
			edad = true;
			if ( llave == true ) {
				age++;
				pGripe = pGripe + gripe;
				cont++;
			}
			else {
				pCovid = pCovid + covid;
				pHepatitis = pHepatitis + hepatitis;
				cont++;	
			}
		break;

		case 12:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				conjuntivitis = true;
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 13:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				pGripe = pGripe + gripe;
				pNeumonia = pNeumonia + neumonia;
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 14:
			if ( llave == true ) {
				if ( edad == true) {
					if (age > 0) {
						pGripe = pGripe + gripe;
						pHepatitis = pHepatitis + hepatitis;
						pNeumonia = pNeumonia + neumonia;
						cont+=2;	
					}
					else
					{
						pCovid = pCovid + covid;
						pHepatitis = pHepatitis + hepatitis;
						cont+=2;
					}
				}
				else{
					cont++;
				}
			}
			else {
				cont+=2;	
			}
		break;

		case 15:
			if ( llave == true ) {
				pGripe = pGripe + gripe;
				pHepatitis = pHepatitis + hepatitis;
				pNeumonia = pNeumonia + neumonia;
				cont++;
			}
			else {
				pCovid = pCovid + covid;
				pHepatitis = pHepatitis + hepatitis;
				pNeumonia = pNeumonia + neumonia;
				cont++;	
			}
		break;

		case 16:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				proCovid++;
				cont++;
			}
			else {
				cont++;	
			}
		break;

		case 17:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				proCovid++;
				pHepatitis = pHepatitis + hepatitis;
				cont+=2;
			}
			else {
				cont++;	
			}
		break;

		case 18:
			if ( llave == true ) {
				pCovid = pCovid + covid;
				proCovid++;
				pNeumonia = pNeumonia + neumonia;
				cess++;
				cont++;
			}
			else {
				cont++;	
			}
		break;
	}
}

iniciarTest.addEventListener("click", ()=>{

	iniciarTest.setAttribute("hidden", "true");
	textoBoton.setAttribute("hidden", "true");

	btnSi.removeAttribute("hidden");
	btnNo.removeAttribute("hidden");

	cambiarPregunta();
});

btnSi.addEventListener("click", ()=>{

	llave = true;
	validacion();
	cambiarPregunta();
});

btnNo.addEventListener("click", ()=>{

	llave = false;
	validacion();
	cambiarPregunta();
});

btnA.addEventListener("click", ()=>{

	location.reload();
});