SPOOL C:\Users\ORA_bases\2020_09_02_clase_a\salida\instala_base_student.txt
rem crea la base student 
set flush off
set termout off
@@C:\Users\ORA_bases\2020_09_02_clase_a\instala_base_student.sql
@@C:\Users\ORA_bases\2020_09_02_clase_a\CIFRAS_CONTROL_STUDENT.sql
SPOOL OFF
