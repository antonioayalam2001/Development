spool F:\Base\Clases\ch19_33.txt

/*
Cree un procedimiento almacenado basado en el script ch17_1c.sql, versión 3.0, 
 El procedimiento debe aceptar dos parámetros para contener un nombre de tabla y un ID y
debe devolver seis parámetros con información:
 de nombre, apellido, calle, ciudad, estado y código postal.
*/

CREATE OR REPLACE PROCEDURE get_name_address
	(table_name_in IN VARCHAR2
	,id_in IN NUMBER
	,first_name_out OUT VARCHAR2
	,last_name_out OUT VARCHAR2
	,street_out OUT VARCHAR2
	,city_out OUT VARCHAR2
	,state_out OUT VARCHAR2
	,zip_out OUT VARCHAR2)
AS
	sql_stmt VARCHAR2(200);
BEGIN
	sql_stmt := 'SELECT a.first_name, a.last_name, a.street_address'||
		' ,b.city, b.state, b.zip' ||
		' FROM '||table_name_in||' a, zipcode b' ||
		' WHERE a.zip = b.zip' ||
		' AND '||table_name_in||'_id = :1';
EXECUTE IMMEDIATE sql_stmt
	INTO first_name_out, last_name_out, street_out, city_out,
	state_out, zip_out
	USING id_in;
	END get_name_address;
/


REM

SET SERVEROUTPUT ON
DECLARE
	v_table_name VARCHAR2(20) := '&sv_table_name';
	v_id NUMBER := &sv_id;
	v_first_name VARCHAR2(25);
	v_last_name VARCHAR2(25);
	v_street VARCHAR2(50);
	v_city VARCHAR2(25);
	v_state VARCHAR2(2);
	v_zip VARCHAR2(5);
BEGIN
	get_name_address (v_table_name, v_id, v_first_name, v_last_name,
	v_street, v_city, v_state, v_zip);
	DBMS_OUTPUT.PUT_LINE ('First Name: '||v_first_name);
	DBMS_OUTPUT.PUT_LINE ('Last Name: '||v_last_name);
	DBMS_OUTPUT.PUT_LINE ('Street: '||v_street);
	DBMS_OUTPUT.PUT_LINE ('City: '||v_city);
	DBMS_OUTPUT.PUT_LINE ('State: '||v_state);
	DBMS_OUTPUT.PUT_LINE ('Zip Code: '||v_zip);
END;
/

--*Se debe llenar de la siguiente forma;
rem el ejecutarlo insertar 
--instructor 
--105

--Enter value for sv_table_name: instructor

--Enter value for sv_id: 105

/*
Modifique el procedimiento que acaba de crear. 
En lugar de usar seis parámetros para mantener el nombre y la dirección información, 
el procedimiento debe devolver un registro definido por el usuario
 que contiene seis campos que contienen información de nombre y dirección. 
 Nota: es posible que desee crear un paquete en el que defina un tipo de registro. 
Este registro se puede utilizar más tarde, como cuando se invoca el procedimiento en un PL / SQL

*/

CREATE OR REPLACE PACKAGE dynamic_sql_pkg
AS
-- Create user-defined record type
	TYPE name_addr_rec_type IS RECORD
		(first_name VARCHAR2(25),
		last_name VARCHAR2(25),
		street VARCHAR2(50),
		city VARCHAR2(25),
		state VARCHAR2(2),
		zip VARCHAR2(5));
PROCEDURE get_name_address (table_name_in IN VARCHAR2
		,id_in IN NUMBER
		,name_addr_rec OUT name_addr_rec_type);
END dynamic_sql_pkg;
/

CREATE OR REPLACE PACKAGE BODY dynamic_sql_pkg AS
PROCEDURE get_name_address (table_name_in IN VARCHAR2
,id_in IN NUMBER
,name_addr_rec OUT name_addr_rec_type)
IS
sql_stmt VARCHAR2(200);
BEGIN
sql_stmt := 'SELECT a.first_name, a.last_name, a.street_address'||
' ,b.city, b.state, b.zip' ||
' FROM '||table_name_in||' a, zipcode b' ||
' WHERE a.zip = b.zip' ||
' AND '||table_name_in||'_id = :1';
EXECUTE IMMEDIATE sql_stmt
INTO name_addr_rec
USING id_in;
END get_name_address;
END dynamic_sql_pkg;
/



SET SERVEROUTPUT ON
DECLARE
	v_table_name VARCHAR2(20) := '&sv_table_name';
	v_id NUMBER := &sv_id;
	name_addr_rec DYNAMIC_SQL_PKG.NAME_ADDR_REC_TYPE;
BEGIN
	dynamic_sql_pkg.get_name_address (v_table_name, v_id,
		name_addr_rec);
	DBMS_OUTPUT.PUT_LINE ('First Name: '||name_addr_rec.first_name);
	DBMS_OUTPUT.PUT_LINE ('Last Name: '||name_addr_rec.last_name);
	DBMS_OUTPUT.PUT_LINE ('Street: '||name_addr_rec.street);
	DBMS_OUTPUT.PUT_LINE ('City: '||name_addr_rec.city);
	DBMS_OUTPUT.PUT_LINE ('State: '||name_addr_rec.state);
	DBMS_OUTPUT.PUT_LINE ('Zip Code: '||name_addr_rec.zip);
END;

--*Instrucciones de llenado al momento de la solicitud de campo
--*Enter value for sv_table_name: student
--*Enter value for sv_id: 105


--*Enter value for sv_table_name: instructor
--*Enter value for sv_id: 105

spool off;