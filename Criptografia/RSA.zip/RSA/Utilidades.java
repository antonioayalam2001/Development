/****************************************************
*                                                   *
*   Metodo Principal para la Firma/Verificacion RSA *
*   Integrantes                                     *
*       Mora Ayala Jose Antonio                     *
*       Torres Carrillo Josehf Miguel Angel         *
*       Tovar Jacuinde Rodrigo                      *
*   Grupo                                           *
*       3CM13                                       *
*                                                   *
****************************************************/
import javax.swing.*;
import java.awt.*;
import java.util.*;

import java.io.*;
import java.nio.charset.*;
import java.nio.file.*;

import java.security.*;
import java.security.spec.*;

import javax.crypto.*;
import javax.crypto.spec.*;

import java.util.Base64;

import java.lang.Object;
import java.util.regex.Pattern;

public class Utilidades {

    public String leerArchivo () {

        JFileChooser fc = new JFileChooser();
        fc.showOpenDialog(null);
        File archivo = fc.getSelectedFile();

        String texto = "";
        
        try{

            Scanner input = new Scanner(archivo);

            while (input.hasNextLine()) {

                texto += input.nextLine();

                if (input.hasNextLine())                    
                    texto = texto + "\n";                
            }
                
            input.close();

            JOptionPane.showMessageDialog(null, "Archivo de texto Leido Correctamente");
        }catch(FileNotFoundException e){ System.out.println("Error Aqui");}

        return texto;
    }

    public PrivateKey leerLlavePrivada () throws IOException, NoSuchAlgorithmException, InvalidKeySpecException{

        JFileChooser fc = new JFileChooser();
        fc.showOpenDialog(null);
        File archivo = fc.getSelectedFile();

        byte[] bytesLlavePrivada = Files.readAllBytes(archivo.toPath());

        KeyFactory kf = KeyFactory.getInstance("RSA");
        PKCS8EncodedKeySpec llavePrivadaKS = new PKCS8EncodedKeySpec(bytesLlavePrivada);
        
        JOptionPane.showMessageDialog(null, "Llave Privada Leida Correctamente");

        return kf.generatePrivate(llavePrivadaKS);
    }

    public PublicKey leerLlavePublica () throws IOException, NoSuchAlgorithmException, InvalidKeySpecException{

        JFileChooser fc = new JFileChooser();
        fc.showOpenDialog(null);
        File archivo = fc.getSelectedFile();

        byte[] bytesLlavePublica = Files.readAllBytes(archivo.toPath());

        KeyFactory kf = KeyFactory.getInstance("RSA");
        X509EncodedKeySpec  llavePublicaKS = new X509EncodedKeySpec (bytesLlavePublica);
        
        JOptionPane.showMessageDialog(null, "Llave Publica Leida Correctamente");

        return kf.generatePublic(llavePublicaKS);
    }

    public byte[] operacionHash (String textoArchivo) throws NoSuchAlgorithmException, UnsupportedEncodingException{

        //Creamos nuestro digesto en  SHA-1
        MessageDigest digesto = MessageDigest.getInstance("SHA-1");

        //Aplicamos nuestro metodo Hash al texto
        digesto.update(textoArchivo.getBytes("UTF-8"));

        //Guardamos el Digesto en un arreglo de bytes
        return digesto.digest();

            //System.out.println(mensajeDigesto.toString());

            //StringBuffer hexString = new StringBuffer();
      
            //for (int i = 0; i < mensajeDigesto.length; i++) {
                //hexString.append(Integer.toHexString(0xFF & mensajeDigesto[i]));
            //}
            
            //System.out.println("Hex format : " + hexString.toString());




            //BigInteger numero = new BigInteger(1, mensajeDigesto);

            //String texto = numero.toString(16);

            //System.out.println(texto);
    }

    public void cifrarRSA (PrivateKey llavePrivada, byte[] bytesHash, String textoArchivo) {

        try{

            Cipher cipher = Cipher.getInstance("RSA");        
            cipher.init(Cipher.ENCRYPT_MODE, llavePrivada);

            byte[] bytesCifrados = cipher.doFinal(bytesHash);

            escribirArchivo(Base64.getEncoder().encodeToString(bytesCifrados) + "\n" + textoArchivo, "Cifrado.txt");

        }catch (Exception e) { e.printStackTrace(); System.out.println(e); }
    }

    public void escribirArchivo (String texto, String nombreArchivo){

        String carpeta = System.getProperty("user.dir");
        String direccion = carpeta + "/" + nombreArchivo;

        FileWriter ubicacion = null;

        try{

            ubicacion = new FileWriter(direccion);

            BufferedWriter escritor = new BufferedWriter(ubicacion);
            escritor.write(texto);
            escritor.close();

            JOptionPane.showMessageDialog(null, "Proceso De Firmado Completado Correctamente :)");

        } catch(IOException error){}
    }

    public String descifrarRSA (PublicKey llavePublica, String textoCifrado){

        String descifrado = "";

        try{

            Cipher cipher = Cipher.getInstance("RSA");        
            cipher.init(Cipher.DECRYPT_MODE, llavePublica);

            byte[] bytesDescifrados = cipher.doFinal(Base64.getDecoder().decode(textoCifrado));

            descifrado = new String(bytesDescifrados);

        }catch (Exception e) {}

        return descifrado;
    }

    /*
        public static void main(String[] args) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException{

            int modo = 2;

            if (modo == 1) {
                
                //Parte de Cifrado

                //Primero leemos el archivo con el texto
                String textoArchivo = leerArchivo();
                //String textoArchivo = "Hola mundo cruel";

                //Luego leemos nuestra llave privada
                PrivateKey llavePrivadaArchivo = leerLlavePrivada();

                //Luego hacemos Hash a nuestro texto
                byte[] bytesHash = operacionHash(textoArchivo);

                //Mandamos a crifrar nuestro digesto
                cifrarRSA(llavePrivadaArchivo, bytesHash, textoArchivo);
            }
            else{

                //ParteDescifrado

                //Leemos el archivo con el texto cifrado
                String textoArchivoCifrado = leerArchivo();

                String separador = Pattern.quote("\n");
                String[] textoPartido = textoArchivoCifrado.split(separador);

                String digestoCifrado = textoPartido[0];

                String textoClaro = textoPartido[1];

                for (int i = 2; i < textoPartido.length ; i++) {
                    textoClaro = textoClaro + "\n" + textoPartido[i];
                }

                //Luego leemos nuestra llave publica
                PublicKey llavePublicaArchivo = leerLlavePublica();

                //Hacemos Hash a nuestro texto claro
                byte[] bytesHashOriginal = operacionHash(textoClaro);

                String datosOriginales = new String(bytesHashOriginal);

                //Mandamos a descifrar nuestro textoCifrado
                String datosDescifrados = descifrarRSA(llavePublicaArchivo, digestoCifrado);

                if (datosOriginales.equals(datosDescifrados)) System.out.println(":)");
                else System.out.println(":(");                   
            }    
        }
    */
}
