spool F:\Base\Clases\Mora_Ayala_Jose_Antonio_ch11_8a.txt

-- ch11_8a.sql
rem podemos tener varios cursores
rem manipularlos de manera anidada
rem  
DECLARE
	v_zip zipcode.zip%TYPE;
	v_student_flag CHAR;
	CURSOR c_zip IS
		SELECT zip, city, state
		FROM zipcode
		WHERE state = 'CT';
	CURSOR c_student IS
		SELECT first_name, last_name
		FROM student
		WHERE zip = v_zip;
BEGIN
	FOR r_zip IN c_zip
	LOOP
		v_student_flag := 'N';
		v_zip := r_zip.zip;
		DBMS_OUTPUT.PUT_LINE(CHR(10));
		DBMS_OUTPUT.PUT_LINE('Students living in '||
		r_zip.city||chr(10));
		FOR r_student in c_student
		LOOP
			DBMS_OUTPUT.PUT_LINE(chr(9)||chr(9)||
			r_student.first_name||
			' '||r_student.last_name);
			v_student_flag := 'Y';
		END LOOP;
		IF v_student_flag = 'N'
		THEN
			DBMS_OUTPUT.PUT_LINE
			(chr(9)||chr(9)||'No Students for this zipcode');
		END IF;
	END LOOP;
END;
/
rem consultas previas

SELECT zip, city, state
		FROM zipcode
		WHERE state = 'CT';
		
rem para el segundo cursor 


SELECT zip,first_name, last_name
	FROM student
	WHERE zip between 06401 and 06907;
	
rem escenario dos 
DECLARE
	v_zip zipcode.zip%TYPE;
	v_student_flag CHAR;
	CURSOR c_zip IS
		SELECT zip, city, state
		FROM zipcode
		WHERE state = 'CT';
	CURSOR c_student IS
		SELECT first_name, last_name
		FROM student
		WHERE zip = v_zip;
BEGIN
	FOR r_zip IN c_zip
	LOOP
		v_student_flag := 'N';
		v_zip := r_zip.zip;
		DBMS_OUTPUT.PUT_LINE(CHR(10));
		DBMS_OUTPUT.PUT_LINE('Students living in '||
		r_zip.city||chr(10));
		FOR r_student in c_student
		LOOP
			DBMS_OUTPUT.PUT_LINE(chr(9)||chr(9)||
			r_student.first_name||
			' '||r_student.last_name);
			v_student_flag := 'Y';
		END LOOP;
		IF v_student_flag = 'N'
		THEN
			DBMS_OUTPUT.PUT_LINE
			(chr(9)||chr(9)||'No Students for this zipcode');
		END IF;
	END LOOP;
		DBMS_OUTPUT.PUT_LINE ('Final YA '||chr(13)||chr(10)||chr(10)||
	'Termine'||chr(07)||chr(07)||chr(07));
END;
/
spool off;