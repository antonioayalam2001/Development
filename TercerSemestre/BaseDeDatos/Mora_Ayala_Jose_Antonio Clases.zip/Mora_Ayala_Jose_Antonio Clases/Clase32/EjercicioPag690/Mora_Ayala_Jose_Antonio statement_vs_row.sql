spool F:\Base\Clases\statement_vs_row.txt
/*-- statement_vs_row.sql */
-- an after statement level trigger
--pagina 690 del libro de Triggers (Tabla indica orden de los script a ejecutar)
SET SERVEROUTPUT on;

CREATE OR REPLACE TRIGGER statement_trigger
AFTER INSERT ON to_table
BEGIN
  DBMS_OUTPUT.PUT_LINE('After Insert Statement Level');

END;
/

--Añadiendo elementos a la tabla to_table
INSERT INTO to_table
select *from from_table;


/*-- an after row level trigger */
CREATE OR REPLACE TRIGGER row_trigger
AFTER INSERT ON to_table
FOR EACH ROW
BEGIN
  DBMS_OUTPUT.PUT_LINE('After Insert Row Level');
END;
/

--Agregando elementos a la tabla to_table
--mediante un loop para probar como hace la mención del trigger
--por cada fila
BEGIN
  FOR counter IN 21..30 LOOP
    INSERT INTO to_table VALUES(counter);
  END LOOP;
END;
/

/*======================================================================
| Supplement to the third edition of Oracle PL/SQL Programming by Steven
| Feuerstein with Bill Pribyl, Copyright (c) 1997-2002 O'Reilly &
| Associates, Inc. To submit corrections or find more code samples visit
| http://www.oreilly.com/catalog/oraclep3/
*/
spool off;