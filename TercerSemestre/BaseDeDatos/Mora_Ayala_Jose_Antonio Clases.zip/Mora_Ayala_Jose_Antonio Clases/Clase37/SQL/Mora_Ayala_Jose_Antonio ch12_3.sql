spool F:\Base\Clases\Mora_Ayala_Jose_Antonio_ch12_3.txt

-- ch12_3a.sql
--* Cursor calificaciones y cursos inscitos

DECLARE
	CURSOR c_grade(
		i_student_id IN enrollment.student_id%TYPE,
		i_section_id IN enrollment.section_id%TYPE)
	IS
		SELECT final_grade
			FROM enrollment
		WHERE student_id = i_student_id
			AND section_id = i_section_id
		FOR UPDATE;
	CURSOR c_enrollment IS
		SELECT e.student_id, e.section_id
			FROM enrollment e, section s
				WHERE s.course_no = 135
				AND e.section_id = s.section_id;
BEGIN
	FOR r_enroll IN c_enrollment
	LOOP
		FOR r_grade IN c_grade(r_enroll.student_id,
			r_enroll.section_id)
		LOOP
			UPDATE enrollment
			SET final_grade = null
			WHERE student_id = r_enroll.student_id
				AND section_id = r_enroll.section_id;
		END LOOP;
	END LOOP;
END;
/
rem consultas previas
rem del cursor c_grade
SELECT final_grade,student_id,section_id
			FROM enrollment
		WHERE (student_id = 129 AND section_id = 113)
		 OR   (student_id = 135 AND section_id = 112)
		 OR   (student_id = 176 AND section_id = 135)
		 OR   (student_id = 233 AND section_id = 112)
		;
--		WHERE student_id = i_student_id
--			AND section_id = i_section_id;	
			
			
rem del cursor c_enrollment
SELECT e.student_id, e.section_id,s.course_no
			FROM enrollment e, section s
				WHERE s.course_no = 135
				AND e.section_id = s.section_id;
rem escenario dos
DECLARE
	CURSOR c_grade(
		i_student_id IN enrollment.student_id%TYPE,
		i_section_id IN enrollment.section_id%TYPE)
	IS
		SELECT final_grade
			FROM enrollment
		WHERE student_id = i_student_id
			AND section_id = i_section_id
		FOR UPDATE;
	CURSOR c_enrollment IS
		SELECT e.student_id, e.section_id
			FROM enrollment e, section s
				WHERE s.course_no = 135
				AND e.section_id = s.section_id;
BEGIN
	FOR r_enroll IN c_enrollment
	LOOP
		FOR r_grade IN c_grade(r_enroll.student_id,
			r_enroll.section_id)
		LOOP
			UPDATE enrollment
			SET final_grade = null
			WHERE student_id = r_enroll.student_id
				AND section_id = r_enroll.section_id;
		END LOOP;
	END LOOP;
END;
/
spool off;