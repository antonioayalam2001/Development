spool F:\Base\Clases\vista_vista.txt
create view vista2aa as
select *from employee,works_on
    where Essn=ssn and BDATE > '31/12/1957';
    
create view vista3aa as
    select *from vista2aa,project
    where pnumber=pno and pname='ProductX';

create view vista4aa asselect *from project, works_on
    where pname='ProductX' and pnumber=pno;

select * from vista4aa;

create view vista5aa as
select *from project,works_on
where pname='ProductX' and pnumber=pno;


select *from vista5aa;

spool off;
