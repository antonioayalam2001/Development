#!/bin/bash
echo Estas apunto de ejecutar el programa:BurbujaOptimizada2
cd ..
gcc mainLin.c -lm -o mainLin
./mainLin
./mainLin 3 100 >BurbujaO2T.txt
./mainLin 3 1000 >>BurbujaO2T.txt
./mainLin 3 5000 >>BurbujaO2T.txt
./mainLin 3 10000 >>BurbujaO2T.txt
./mainLin 3 50000 >>BurbujaO2T.txt
./mainLin 3 100000 >>BurbujaO2T.txt 
./mainLin 3 125000 >>BurbujaO2T.txt 
./mainLin 3 175000 >>BurbujaO2T.txt 
./mainLin 3 200000 >>BurbujaO2T.txt
./mainLin 3 225000 >>BurbujaO2T.txt
./mainLin 3 275000 >>BurbujaO2T.txt
./mainLin 3 300000 >>BurbujaO2T.txt
./mainLin 3 325000 >>BurbujaO2T.txt
./mainLin 3 375000 >>BurbujaO2T.txt
./mainLin 3 400000 >>BurbujaO2T.txt
./mainLin 3 425000 >>BurbujaO2T.txt
./mainLin 3 500000 >>BurbujaO2T.txt
# ./mainLin 3 4000000 >>BurbujaO2T.txt
# ./mainLin 3 5000000 >>BurbujaO2T.txt
# ./mainLin 3 6000000 >>BurbujaO2T.txt
# ./mainLin 3 7000000 >>BurbujaO2T.txt
# ./mainLin 3 8000000 >>BurbujaO2T.txt
# ./mainLin 3 9000000 >>BurbujaO2T.txt
# ./mainLin 3 10000000 >>BurbujaO2T.txt


