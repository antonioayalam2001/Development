/****************************************************
*                                                   *
*   Metodo Principal para la Firma Digital          *
*   Integrantes                                     *
*       Mora Ayala Jose Antonio                     *
*       Torres Carrillo Josehf Miguel Angel         *
*       Tovar Jacuinde Rodrigo                      *
*   Grupo                                           *
*       3CM13                                       *
*                                                   *
****************************************************/

public class main {

    public static void main(String[] args) {
        //Mandamos a llamar una instancia de nuestra GUI
        new GUI();
    }
}