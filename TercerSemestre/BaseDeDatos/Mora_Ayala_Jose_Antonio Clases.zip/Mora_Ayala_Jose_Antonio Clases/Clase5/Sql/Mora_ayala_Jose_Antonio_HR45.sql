spool  %ORA_OUT%\s45.txt
rem script HR45.sql
select employee_id, first_name
   from employees
   where first_name like 'S%';
spool off