spool F:\Base\Clases\crea_usuario_sergionava.txt
create user sergionava identified by sergionava
default tablespace users
temporary tablespace temp;

grant resource connect to sergionava;

GRANT CONNECT, RESOURCE TO sergionava;

spool off;
drop user sergionava cascade;