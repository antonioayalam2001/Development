

set VERIFY ON; 
SET ECHO ON;
set space 1

spool F:\Documents\BasedeDatos\Capitulo3\Capitulo3.txt
--  =======================================================================================
--  ||Capitulo 3 Ejercicios SQLOracle By Example                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Oracle SQL by Example Third Edition              ||
--* ||Rischert, Alice.                                                                  ||
--* ||Oracle SQL by example / Alice Rischert.-- 3rd ed.                                 ||
--* ||p. cm. -- (Prentice Hall PTR Oracle series)                                       ||
--* ||Rev. ed. of: Oracle SQL interactive workbook, 2003.                               ||
--* ||Includes indexes.                                                                 ||
--* ||ISBN 0-13-145131-6                                                                ||
--* ||1. SQL (Computer program language) 2. Oracle (Computer file)                      ||
--* ||I. Rischert, Alice. Oracle SQL interactive workbook. II. Title. III. Series.      ||
--  =======================================================================================


TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 1'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2


SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 110
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;
--  Lab 3.1 Excercises
--  a) Probando la funcion de INITCAP
COL Description FORMAT A30
SELECT description "Description",
   INITCAP(description) "Initcap Description"
   FROM course
   WHERE description LIKE '%SQL%';
--  Observamos que la funcion esta convirtiendo la primer letra en mayuscula y el resto en minuscula
--  b) Seleccionando el apellido de la tabla instructor, donde el apellido tenga mas o igual de 6 caracteres
SELECT last_name
   FROM instructor
   WHERE LENGTH(last_name) >= 6;
--  c) La primera columna toma los caracteres comenzando desde la posicion 3 hasta el fin
--  dando como resultado la cadena "343"
--  La segunda comienza en 3 y termina despues de 2 caracteres
--  La tercera comeinza en la cuarta posicion y toma tres caracteres
SELECT SUBSTR('12345', 3),
   SUBSTR('12345', 3, 2),
   SUBSTR('12345', -4, 3)
   FROM dual;

--  d) Las funciones LTRIM y RTRIM
--   Quitaran los numeros seleccionados del codigo postal
--  como originalmente se muestra

SELECT LTRIM('00234', '0'), RTRIM('12444', '4')
   FROM dual;

SELECT TRIM('01' FROM '01230145601')
   FROM dual;

--  Usando Replace
SELECT LTRIM('01230145601', '01') left,
RTRIM('01230145601', '01') right,
RTRIM(LTRIM('01230145601', '01'), '01') both,
REPLACE('01230145601', '01') replace
FROM dual;

--  e) Translate para busqueda de Patron
SELECT student_id, employer
    FROM student
    WHERE TRANSLATE(employer, '_', '+') LIKE '%B+B%';

SELECT student_id, employer
    FROM student
    WHERE INSTR(employer, 'B_B') > 0;

SELECT student_id, last_name
    FROM student
    WHERE INSTR(last_name, 'o', 1, 3) > 0;

--   Chapter 3. Character, Number, and Miscellaneous Functions
--   Number Functions
--   The ABS Function
SELECT 'The absolute value of -29 is '||ABS(-29)
   FROM dual;

--   The SIGN Function
SELECT -14, SIGN(-14), SIGN(14), SIGN(0), ABS(-14)
   FROM dual;

--   ROUND and TRUNC Functions
SELECT 222.34501,
        ROUND(222.34501, 2),
        TRUNC(222.34501, 2)
   FROM dual;

--   ROUND and TRUNC Functions
SELECT 222.34501,
    ROUND(222.34501, -2),
    TRUNC(222.34501, -2)
   FROM dual;

--   ROUND and TRUNC Functions
SELECT 2.617, ROUND(2.617), TRUNC(2.617)
   FROM dual;

--   The FLOOR and CEIL Functions
SELECT FLOOR(22.5), CEIL(22.5), TRUNC(22.5), ROUND(22.5)
   FROM dual;

--   The MOD Function
SELECT MOD(23, 8)
   FROM dual;

--   The ROUND Function and FLOATING-POINT Numbers
SELECT ROUND(3.5), ROUND(3.5f), ROUND(4.5), ROUND(4.5f)
   FROM dual;

--   The REMAINDER Function
SELECT MOD(23,8), REMAINDER(23,8)
   FROM DUAL;
SELECT (23-(8*FLOOR(23/8))) AS mod,
    (23-(8*ROUND(23/8))) AS remainder
   FROM DUAL;

--   Arithmetic Operators
SELECT DISTINCT cost, cost + 10,
    cost - 10, cost * 10, cost / 10
   FROM course;

SELECT DISTINCT cost + (cost * .10)
   FROM course;
--  Si usamos un numero negativo, va a redondear hacia la izquierda 
SELECT 10.245, ROUND(10.245, 1), ROUND(10.245, -1)
    FROM dual

--   Miscellaneous Single-Row Functions
--   The NVL Function
--  Permite reemplazar un vaor nulo con un valor predeterminado
SELECT 60+60+NULL
   FROM dual;

SELECT 60+60+NVL(NULL, 1000)
   FROM dual;

select course_no,description,prerequisite
  from course;

SELECT course_no, description,
NVL(TO_CHAR(prerequisite), 'Not Applicable') prereq
FROM course
WHERE course_no IN (20, 100);

--   The COALESCE Function
--  Funcion que nos sirve para poder realizar un remplazo COALESCE(input_expression_sub_exp1_sub_exp_n)
DESCR grade_summary;
SELECT student_id, midterm_grade, finalexam_grade, quiz_grade,
        COALESCE(midterm_grade, finalexam_grade, quiz_grade) "Coalesce"
   FROM grade_summary;

SELECT course_no, description,
        COALESCE(TO_CHAR(prerequisite), 'Not Applicable') prereq
   FROM course
  WHERE course_no IN (20, 100);

--   The NVL2 Function
--  permite reemplazar valores nulos y valores no nulos
--  NVL2(input_expr_nutnull_sub_exp,null_sub_exp)
SELECT DISTINCT cost,
        NVL2(cost, 'exists', 'none') "NVL2"
   FROM course;
--  NUllif (exp1,equal_exp2)

SELECT student_id,
   TO_CHAR(created_date, 'DD-MON-YY HH24:MI:SS') "Created",
   TO_CHAR(modified_date, 'DD-MON-YY HH24:MI:SS') "Modified",
   NULLIF(created_date, modified_date) "Null if equal"
   FROM student
   WHERE student_id in (150,340);

--   The NANVL
--   NANVL (input_value, substitution_value)
--  cuando la entrada no es un numero, se sustituye por un 0
SELECT test_col, NANVL(test_col, 0)
   FROM float_test;

insert into float_test (Test_col)
values (5.0E+000);

SELECT test_col, NANVL(test_col, 0)
   FROM float_test;

--   The DECODE Function
--  DECODE ((if_expr, equals_search, then_result [,else_default]))
SELECT DISTINCT state,
        DECODE(state, 'NY', 'New York',
                      'NJ', 'New Jersey') no_default,
        DECODE(state, 'NY', 'New York',
                      'NJ', 'New Jersey',
                            'OTHER') with_default
   FROM zipcode
  WHERE state IN ('NY','NJ','CT');

--   The DECODE Function and NULLS
SELECT instructor_id, zip,
        DECODE(zip, NULL, 'NO zipcode!', zip) "Decode Use"
   FROM instructor
  WHERE instructor_id IN (102, 110);

--   The DECODE Function and Comparisons
SELECT course_no, cost,
        DECODE(SIGN(cost-1195),-1, 500, cost) newcost
   FROM course
 WHERE course_no IN (80, 20, 135, 450)
  ORDER BY 2;

--   THE SEARCHED CASE EXPRESSION
--  CASE {WHEN condition THEN return_expr
--  [WHEN condition THEN return_expr]... }
--  [ELSE else_expr]
--  END
SELECT course_no, cost,
        CASE WHEN cost <1195 THEN 500
             ELSE cost
        END "Test CASE"
   FROM course
  WHERE course_no IN (80, 20, 135, 450)
  ORDER BY 2;

--   THE SEARCHED CASE EXPRESSION
--   NESTING CASE EXPRESSIONS
SELECT course_no, cost, prerequisite,
        CASE WHEN cost <1100 THEN
                  CASE WHEN prerequisite IN (10, 50) THEN cost/2
                       ELSE cost
                  END
             WHEN cost >=1100 AND cost <1500 THEN cost*1.1
             WHEN cost IS NULL THEN 0
             ELSE cost
        END "Test CASE"
FROM course
WHERE course_no IN (80, 20, 135, 450, 230)
ORDER BY 2;

--   THE SEARCHED CASE EXPRESSION
--   CASE EXPRESSION IN THE WHERE CLAUSE
SELECT DISTINCT capacity, location
   FROM section
   WHERE capacity*CASE
   WHEN SUBSTR(location, 1,1)='L' THEN 2
   WHEN SUBSTR(location, 1,1)='M' THEN 1.5
   ELSE NULL
   END  > 30;

--   DATATYPE INCONSISTENCIES
SELECT section_id, capacity,
   CASE WHEN capacity >=15 THEN TO_CHAR(capacity)
   WHEN capacity < 15 THEN 'Room too small'
   END AS "Capacity"
   FROM section
   WHERE section_id IN (101, 146, 147);

--   SIMPLE CASE EXPRESSION
--  CASE {expr WHEN comparison_expr THEN return_expr
--  [WHEN comparison_expr THEN return_expr]...}
--  [ELSE else_expr]
--  END
SELECT course_no, cost,
   CASE cost WHEN 1095 THEN cost/2
   WHEN 1195 THEN cost*1.1
   WHEN 1595 THEN cost
   ELSE cost*0.5
   END "Simple CASE"
   FROM course
   WHERE course_no IN (80, 20, 135, 450)
   ORDER BY 2;

spool off