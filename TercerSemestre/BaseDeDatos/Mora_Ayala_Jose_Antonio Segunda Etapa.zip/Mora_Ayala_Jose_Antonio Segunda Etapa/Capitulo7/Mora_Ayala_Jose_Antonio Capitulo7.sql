spool F:\Documents\BasedeDatos\Capitulo7\Capitulo7.txt

--  =======================================================================================
--  ||Capitulo 7 Ejercicios SQLOracle By Example                                        ||
--  ||Proporcionando un formato a la consola                                            ||
--  ||Para obtener visualzacion de mejor forma                                          ||
--* ||Ejercicios recuperados del libro Oracle SQL by Example Third Edition              ||
--* ||Rischert, Alice.                                                                  ||
--* ||Oracle SQL by example / Alice Rischert.-- 3rd ed.                                 ||
--* ||p. cm. -- (Prentice Hall PTR Oracle series)                                       ||
--* ||Rev. ed. of: Oracle SQL interactive workbook, 2003.                               ||
--* ||Includes indexes.                                                                 ||
--* ||ISBN 0-13-145131-6                                                                ||
--* ||1. SQL (Computer program language) 2. Oracle (Computer file)                      ||
--* ||I. Rischert, Alice. Oracle SQL interactive workbook. II. Title. III. Series.      ||
--  =======================================================================================

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 7'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2


SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 110
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;

--  Subqueries
--  Simple Subqueries
--  Scalar Subqueries

--   A continuacion se presenta la ejecucion de varios script en donde se muestran
--   las formas en que se puede ir realizando un query y la forma en que el manjeados acata estas intrucciones
--   Realizando combianciones de funciones que ya hemos visto anteriormente

--   Los subqueries escalares solo devuelven una sola columna con una sola fila
--   Podemos utilizar los operadores <>=  


SELECT MIN(cost)
   FROM course;

--  Scalar Subqueries

SELECT course_no, description, cost
   FROM course
  WHERE cost = 1095:

SELECT course_no, description, cost
   FROM course
  WHERE cost =
        (SELECT MIN(cost)
           FROM course);

--  Subqueries Returning Multiple Rows
--  Si devuelve multiples filas usamos opoeradores como IN, ANY, ALL, SOME

SELECT course_no, description, cost
   FROM course
  WHERE cost =
        (SELECT MAX(cost)
           FROM course);


SELECT course_no, description, cost
   FROM course
  WHERE cost IN
        (SELECT cost
          FROM course
          WHERE prerequisite = 20);

--  Subqueries Returning Multiple Rows

SELECT course_no, description, cost
   FROM course
  WHERE cost NOT IN
        (SELECT cost
           FROM course
          WHERE prerequisite = 20);

--  Nesting Multiple Subqueries

SELECT last_name, first_name
   FROM student
  WHERE student_id IN
        (SELECT student_id
           FROM enrollment
          WHERE section_id IN
                (SELECT section_id
                   FROM section
                  WHERE section_no = 8
                    AND course_no = 20));

SET LINESIZE 150
SET PAGESIZE 99
SET COLSEP ' || '
--  Subqueries
--  Simple Subqueries
--  Subqueries and Joins

SELECT course_no, description
   FROM course
  WHERE course_no IN
        (SELECT course_no
           FROM section
          WHERE location = 'L211');

--  Subqueries Returning Multiple Columns

SELECT section_id, MAX(numeric_grade)
   FROM grade
  WHERE grade_type_code = 'PJ'
  GROUP BY section_id;

SELECT student_id, section_id, numeric_grade
   FROM grade
  WHERE grade_type_code = 'PJ'
    AND (section_id, numeric_grade) IN
        (SELECT section_id, MAX(numeric_grade)
           FROM grade
          WHERE grade_type_code = 'PJ'
          GROUP BY section_id);

--  Subqueries and NULLS

SELECT course_no, prerequisite
    FROM course
   WHERE prerequisite NOT IN
         (SELECT prerequisite
            FROM course
           WHERE course_no IN (310, 220));

SELECT course_no, prerequisite
    FROM course
   WHERE prerequisite NOT IN (80, NULL);

--  Correlated Subqueries

SELECT student_id, section_id, numeric_grade
   FROM grade outer
  WHERE grade_type_code = 'PJ'
    AND numeric_grade =
       (SELECT MAX(numeric_grade)
           FROM grade
          WHERE grade_type_code = outer.grade_type_code
            AND section_id = outer.section_id);

--  Select A Row From Ther Outer Query

SELECT student_id, section_id, numeric_grade
   FROM grade outer
  WHERE grade_type_code = 'PJ';

--  Execute The Inner Query

SELECT MAX(numeric_grade)
   FROM grade
  WHERE grade_type_code = 'PJ'
    AND section_id = 155;

--  Correlated Subqueries

SELECT MAX(numeric_grade)
   FROM grade
  WHERE grade_type_code = 'PJ'
    AND section_id = 133;

--  The EXISTS Operator
--   Usado para los correlated sunqueries. Si la evaluacion devuelve
--   al menos una fila, el operador nos devolvera cierto o falso, nunca desconocido

SELECT instructor_id, last_name, first_name, zip
   FROM instructor i
  WHERE EXISTS
        (SELECT 'X'
           FROM section
          WHERE i.instructor_id = instructor_id);
-- Resultado con un IN
SELECT instructor_id, last_name, first_name, zip
FROM instructor
WHERE instructor_id IN
(SELECT instructor_id
FROM section)
-- Distintas formas de expresar el query anterior
SELECT DISTINCT i.instructor_id, i.last_name,
i.first_name, i.zip
FROM instructor i JOIN section s
ON i.instructor_id = s.instructor_id

--  The NOT EXISTS Operator

SELECT instructor_id, last_name, first_name, zip
   FROM instructor i
  WHERE NOT EXISTS
        (SELECT 'X'
           FROM section
          WHERE i.instructor_id = instructor_id);
--  NOT EXISTS Verus NOT IN

--  Using NOT EXISTS
--   Evalua valores nulos, por lo que regresara una tupla
SELECT instructor_id, last_name, first_name, zip
   FROM instructor i
  WHERE NOT EXISTS
        (SELECT 'X'
           FROM zipcode
          WHERE i.zip = zip);

--  Using NOT IN
--   No evalua valores nulos
SELECT instructor_id, last_name, first_name, zip
   FROM instructor
  WHERE zip NOT IN
        (SELECT zip
           FROM zipcode);

--  Inline Views And Scalar Subquery Expressions
--  Inline Views

SELECT e.student_id, e.section_id, s.last_name
   FROM (SELECT student_id, section_id, enroll_date
           FROM enrollment
          WHERE student_id = 123) e,
         student s
  WHERE e.student_id = s.student_id;

--  Inline Views

SELECT enr.num_enrolled "Enrollments",
        enr.num_enrolled * c.cost "Actual Revenue",
        cap.capacity "Total Capacity",
        cap.capacity * c.cost "Potential Revenue"
   FROM (SELECT COUNT(*) num_enrolled
           FROM enrollment e, section s
          WHERE s.course_no = 20
            AND s.section_id = e.section_id) enr,
        (SELECT SUM(capacity) capacity
           FROM section
          WHERE course_no = 20) cap,
        course c
  WHERE c.course_no = 20;

--  Top-N Query

SELECT last_name, first_name
   FROM student
  WHERE ROWNUM <=5;

--  Top-N Query

SELECT ROWNUM, numeric_grade
   FROM (SELECT DISTINCT numeric_grade
           FROM grade
          WHERE section_id = 101
            AND grade_type_code = 'FI'
          ORDER BY numeric_grade DESC)
   WHERE ROWNUM <= 3;

--  Scalar Subquery Expressions In The SELECT Clause

SELECT city, state, zip,
       (SELECT COUNT(*)
         FROM student s
        WHERE s.zip = z.zip) AS student_count
   FROM zipcode z
  WHERE state = 'CT';

SELECT student_id, last_name,
        (SELECT state
           FROM zipcode z
          WHERE z.zip = s.zip) AS state
   FROM student s
  WHERE student_id BETWEEN 100 AND 120;

--  Scalar Subquery Expressions In The WHERE Clause

SELECT student_id, last_name
  FROM student s
  WHERE (SELECT COUNT(*)
           FROM enrollment e
          WHERE s.student_id = e.student_id) >
               (SELECT AVG(COUNT(*))
                  FROM enrollment
                 GROUP BY student_id)
  ORDER BY 1;

--  Scalar Subquery Expressions In The ORDER BY Clause

SELECT student_id, last_name
   FROM student s
  WHERE student_id BETWEEN 230 AND 235
  ORDER BY (SELECT COUNT(*)
              FROM enrollment e
             WHERE s.student_id = e.student_id) DESC;

--  Scalar Subquery Expressions And The Case Expression

SELECT course_no, cost,
        CASE WHEN cost <= (SELECT AVG(cost) FROM course) THEN
                          cost *1.5
             WHEN cost =  (SELECT MAX(cost) FROM course) THEN
                          (SELECT cost FROM course
                          WHERE course_no = 20)
             ELSE cost
        END "Test CASE"
   FROM course
  WHERE course_no IN (20, 80)
  ORDER BY 2;

SELECT course_no, cost,
        CASE WHEN (SELECT cost*2
                     FROM course
                    WHERE course_no = 134)
                       <= (SELECT AVG(cost) FROM course) THEN
                          cost *1.5
             WHEN cost =  (SELECT MAX(cost) FROM course) THEN
                          (SELECT cost FROM course
                          WHERE course_no = 20)
             ELSE cost
        END "Test CASE"
   FROM course
  WHERE course_no IN (20, 80)
  ORDER BY 2;

--  Scalar Subquery Expressions And Functions

SELECT student_id, section_id,
        UPPER((SELECT last_name
                 FROM student
                WHERE student_id = e.student_id))
        "Last Name in Caps"
   FROM enrollment e
  WHERE student_id BETWEEN 100 AND 110;

--  ANY, SOME, and ALL Operators In Subqueries

SELECT section_id, numeric_grade
   FROM grade
  WHERE section_id = 84
    AND numeric_grade IN (77, 99);


--  ALL

SELECT section_id, numeric_grade
   FROM grade
  WHERE section_id = 84
    AND numeric_grade <> ALL (80, 90);

--Ejercicios Cap 7

--	Lab 7.1.1. Escriba subconsultas en las cláusulas WHERE y HAVING
--	a) Escriba una declaración SQL que muestre el nombre y apellido de los estudiantes que se 
--		registraron primero.

SELECT first_name, last_name
FROM student
WHERE registration_date = (SELECT MIN(registration_date) FROM student);

--	b) Mostrar las secciones con menor costo de curso y una capacidad igual o menor a la 
--		capacidad media. También muestra la descripción del curso, el número de sección, 
--		la capacidad y el costo.

SELECT c.description, s.section_no, c.cost, s.capacity
FROM course c, section s
WHERE c.course_no = s.course_no
AND s.capacity <= (SELECT AVG(capacity) FROM section)
AND c.cost = (SELECT MIN(cost) FROM course);

--	c) Seleccione el número de curso y la capacidad total de cada curso. Mostrar solo los 
--		cursos con una capacidad total inferior a la capacidad media de todas las secciones.

SELECT course_no, SUM(capacity)
FROM section
GROUP BY course_no
HAVING SUM(capacity) < (SELECT AVG(capacity) FROM section);

--	d) Elija los estudiantes más ambiciosos: muestre el STUDENT_ID para los estudiantes 
--		inscritos en la mayoría de las secciones.

SELECT student_id, COUNT(*)
FROM enrollment
GROUP BY student_id
HAVING COUNT(*) = (SELECT MAX(COUNT(*))
FROM enrollment
GROUP BY student_id);

-- Lab 7.1.2. Escribir subconsultas que devuelvan varias filas

--	a) Seleccione el STUDENT_ID y SECTION_ID de los estudiantes matriculados que viven en 
--		el código postal 06820.

SELECT student_id, section_id
FROM enrollment
WHERE student_id IN (SELECT student_id FROM student WHERE zip = '06820');

--	b) Mostrar el número de curso y la descripción del curso de los cursos impartidos por el 
--		instructor Fernand Hanks.

SELECT course_no, description
FROM course
WHERE course_no IN (SELECT course_no 
					FROM section 
					WHERE instructor_id IN (SELECT instructor_id
											FROM instructor
											WHERE last_name = 'Hanks'
											AND first_name = 'Fernand'));

--	c) Seleccione el apellido y el nombre de los estudiantes que no están inscritos en 
--		ninguna clase.

SELECT last_name, first_name
FROM student
WHERE student_id NOT IN (SELECT student_id FROM enrollment);

-- Lab 7.1.3. Escribir subconsultas que devuelvan varias columnas

--	a) Determine el STUDENT_ID y el apellido de los estudiantes con el FINAL_GRADE más alto
--		para cada sección. También incluya las columnas SECTION_ID y FINAL_GRADE en el resultado.

SELECT s.student_id, s.last_name, e.final_grade,e.section_id
FROM enrollment e, student s
WHERE e.student_id = s.student_id
AND (e.final_grade, e.section_id) IN (SELECT MAX(final_grade), section_id
									  FROM enrollment
									  GROUP BY section_id);

--	b) Seleccionar las secciones y su capacidad donde la capacidad es igual al número de 
--		estudiantes inscrito.

SELECT section_id, capacity
FROM section
WHERE (section_id, capacity) IN (SELECT section_id, COUNT(*)
							  	 FROM enrollment
								 GROUP BY section_id);

--	a) Escriba una declaración SQL para determinar el número total de estudiantes inscritos 
--		utilizando el operador EXISTS. Cuente como uno a los estudiantes matriculados en más 
--		de un curso.

SELECT COUNT(*)
FROM student s
WHERE EXISTS (SELECT NULL 
			  FROM enrollment 
			  WHERE student_id = s.student_id);

--	b) Muestre el STUDENT_ID, apellido y nombre de los estudiantes matriculados en tres o más 
--		clases.

SELECT first_name, last_name, student_id
FROM student s
WHERE EXISTS (SELECT NULL
			  FROM enrollment
			  WHERE s.student_id = student_id
			  GROUP BY student_id
			  HAVING COUNT(*) >= 3);

--	c) ¿Qué cursos no tienen secciones asignadas? Utilice una subconsulta correlacionada en 
--		la solución.

SELECT course_no, description
FROM course c
WHERE NOT EXISTS (SELECT 'X'
				  FROM section
				  WHERE c.course_no = course_no);

--	d) ¿Qué secciones no tienen alumnos matriculados? Utilice una subconsulta correlacionada 
--		en la solución y ordene el resultado por el número de curso en orden ascendente.

SELECT course_no, section_id
FROM section s
WHERE NOT EXISTS (SELECT NULL
				  FROM enrollment
				  WHERE s.section_id = section_id)
ORDER BY course_no;

--	7.3.1. Escribir vistas en línea y expresiones de subconsultas escalares

--	a) Escriba la consulta que muestra las columnas SECTION_ID y COURSE_NO junto con el
--		número de estudiantes matriculados para secciones con los ID de 93, 101 y 103. 
--		Utilice una subconsulta escalar para escribir la consulta.

SELECT section_id, course_no, (SELECT COUNT(*)
							   FROM enrollment e
							   WHERE s.section_id = e.section_id)
AS num_enrolled
FROM section s
WHERE section_id IN (101, 103, 93);

spool off