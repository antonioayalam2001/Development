spool F:\Base\Clases\ch19_01a.txt

-- ch19_01a.sql
--* Trabajando con el usuario Student/learn debido a que es el que posee
--* la base de datos correspondiente a este libro

--*Dando formato a la consola
SET COLSEP ' |=| '
SET LINESIZE 99
SET PAGESIZE 99
SET SERVEROUTPUT on;

show user;

--* El cursor lo estamos usando para agregar/modificar/actualizar ciertas tuplas 
--*

--* Observando que es lo que posee la tabla user_objects
desc course;

SET LINESIZE 199
SET PAGESIZE 99
--*Seleccionando los que vamos a modificar
select course_no,description,cost,prerequisite
from course;

CREATE OR REPLACE PROCEDURE Discount
AS
	CURSOR c_group_discount
	IS
	SELECT distinct s.course_no, c.description
		FROM section s, enrollment e, course c
	WHERE s.section_id = e.section_id
		AND c.course_no = s.course_no
	GROUP BY s.course_no, c.description,
		e.section_id, s.section_id
	HAVING COUNT(*) >=8;
BEGIN
	FOR r_group_discount IN c_group_discount
	LOOP
		UPDATE course
			SET cost = cost * .95
		WHERE course_no = r_group_discount.course_no;
	DBMS_OUTPUT.PUT_LINE
		('A 5% discount has been given to '||
		r_group_discount.course_no||' '||
		r_group_discount.description
		);
	END LOOP;
END;
/

--*Ejecutando el procedimiento.
--*Recuerda tener set SERVERUOTPUT ON para observar el mensaje que el procedimiento muestra
EXECUTE discount;

--*Observando los cambios que se realizaron
select course_no,description,cost,prerequisite
from course;


rem consultas adicionales
rem consulta al diccionario de datos
col object_name format a20
col object_type format a20
col status   format a15


rem to display the source code 
rem from the USER_SOURCE view for
rem  the Discount procedure.
rem 
SELECT object_name, object_type, status
FROM user_objects
WHERE object_name = 'DISCOUNT';
rem 
rem se puede recompilar el procedimiento 
rem ya almacenado
--*COMPILANDO
--*alter procedure procedure_name compile;
alter procedure discount compile;
/

spool off;