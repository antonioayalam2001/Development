#include <stdio.h>
#define PESOBIT(bpos) 1<<bpos
#define CONSULTARBIT(var,bpos) (*(unsigned*)&var & PESOBIT(bpos))?1:0
#define PONE_1(var,bpos) *(unsigned*)&var |= PESOBIT(bpos)
#define PONE_0(var,bpos) *(unsigned*)&var &= ~(PESOBIT(bpos))
#define CAMBIA(var,bpos) *(unsigned*)&var ^= PESOBIT(bpos)

int main(void)
{
	int i,n_bits; //Auxiliares
	unsigned char numero=0; //Variable de tipo char (byte)
	unsigned char arreglo[125];
	
	//bit 0 del arreglo 999
	a=999;
	PONE_1(arreglo[a/8],a%8);

	//Determinar la longitud de los bits a operar
	printf("N�mero de bits\n");
	n_bits=sizeof(numero)*8;
	printf("%2d bits",n_bits);	
	printf("\n");
	
	//Revisar el valor de cada bit
	printf("Valor de los bits\n");
	for (i=n_bits-1; i>=0; i--)
	printf("%d",CONSULTARBIT(numero,i));
	printf("\t%u\n",numero);

	//Modificar el valor de algunos bits
	printf("Modificar el valor de los bits\n");
	PONE_1(numero,7); 		//1 en Bit 0  
	//PONE_1(numero,3); 		//1 en Bit 3
	PONE_1(numero,5); 		//1 en Bit 5
	//PONE_0(numero,5); 		//0 en Bit 5
	
	CAMBIA(numero,0);		//Negar Bit 0
	//CAMBIA(numero,3);		//Negar Bit 3
	//CAMBIA(numero,7);		//Negar Bit 7
	//CAMBIA(numero,0);		//Negar Bit 0

	//PONE_1(numero,31); 		//1 en Bit 5
	//Revisar el valor de cada bit
	printf("Valor de los bits\n");
	for (i=n_bits-1; i>=0; i--)
	printf("%d",CONSULTARBIT(numero,i));
	printf("\t%u\n",numero);
}
