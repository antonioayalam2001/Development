spool  %ORA_OUT%\s44.txt
rem script HR44.sql
rem despliega atributos de la tabla employees del esquema HR
select EMPLOYEE_ID, FIRST_NAME, LAST_NAME
from HR.employees
where EMPLOYEE_ID between 125 and  140;
spool off