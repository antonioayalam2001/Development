#!/bin/bash
echo Estas apunto de ejecutar el programa:Burbuja Simple
cd ..
gcc mainLin.c -lm -o mainLin

./mainLin 1 100 >BurbujaT.txt
./mainLin 1 1000 >>BurbujaT.txt
./mainLin 1 5000 >>BurbujaT.txt
./mainLin 1 10000 >>BurbujaT.txt
./mainLin 1 50000 >>BurbujaT.txt
./mainLin 1 100000 >>BurbujaT.txt 
./mainLin 1 125000 >>BurbujaT.txt 
./mainLin 1 175000 >>BurbujaT.txt 
./mainLin 1 200000 >>BurbujaT.txt
./mainLin 1 225000 >>BurbujaT.txt
./mainLin 1 275000 >>BurbujaT.txt
./mainLin 1 300000 >>BurbujaT.txt
./mainLin 1 325000 >>BurbujaT.txt
./mainLin 1 375000 >>BurbujaT.txt
./mainLin 1 400000 >>BurbujaT.txt
./mainLin 1 425000 >>BurbujaT.txt
./mainLin 1 500000 >>BurbujaT.txt
# ./mainLin 1 600000 >>BurbujaT.txt
# ./mainLin 1 800000 >>BurbujaT.txt
# ./mainLin 1 1000000 >>BurbujaT.txt
# ./mainLin 1 2000000 >>BurbujaT.txt
# ./mainLin 1 3000000 >>BurbujaT.txt
# ./mainLin 1 4000000 >>BurbujaT.txt
# ./mainLin 1 5000000 >>BurbujaT.txt
# ./mainLin 1 6000000 >>BurbujaT.txt
# ./mainLin 1 7000000 >>BurbujaT.txt
# ./mainLin 1 8000000 >>BurbujaT.txt
# ./mainLin 1 9000000 >>BurbujaT.txt
# ./mainLin 1 10000000 >>BurbujaT.txt

