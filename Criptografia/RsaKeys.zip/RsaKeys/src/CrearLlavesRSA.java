import java.io.*;
import java.security.*;
import java.security.spec.*;

public class CrearLlavesRSA {

    public static void generateKey (){

        //Generamos un bloque try para manejar las excepciones
        try{

            //Primero creamos un objeto generador de llaves y a este mismo
            //le indicamos que queremos crear una llave en el modo de RSA
            KeyPairGenerator generador = KeyPairGenerator.getInstance("RSA");

            //Inicializamos nuestro generador de llaves, en este caso la llave
            //es de 1024 bits, otro valor disponible para este modo de creacion
            //de llaves es de 2048
            generador.initialize(1024);

            //Ya que tenemos nuestro generador iniciado lo que aremos sera crear
            //un objeto KeyPair para generar nuestro par de llaves
            KeyPair parDeLlaves = generador.generateKeyPair();

            //Ya que tenemos nuestras llaves generadas podemos obtenerlas mediante
            //los bojetos de PublicKey  y PrivateKey
            PrivateKey llavePrivada = parDeLlaves.getPrivate();
            PublicKey llavePublica = parDeLlaves.getPublic();

            System.out.println("Llaves generadas Correctamente");

            //Este metodo nos permite crear archivos de texto para nuestra llave
            crearArchivoKey(llavePrivada, llavePublica);

        }catch(Exception e){ }
    }

    public static void crearArchivoKey (PrivateKey llavePrivada, PublicKey llavePublica){

        try{
            
            //Podemos crear nuestros archivos ya sea con formato txt o key,
            FileOutputStream archivoPrivada = new FileOutputStream("llavePrivada.txt");
            archivoPrivada.write(llavePrivada.getEncoded());

            FileOutputStream archivoPublica = new FileOutputStream("llavePublica.txt");
            archivoPublica.write(llavePublica.getEncoded());

            //Version Alternativa de guardar las llaves

            //FileOutputStream archivoPrivadaK = new FileOutputStream("llavePrivada.key");
            //archivoPrivadaK.write(llavePrivada.getEncoded());

            //FileOutputStream archivoPublicaK = new FileOutputStream("llavePublica.key");
            //archivoPublicaK.write(llavePublica.getEncoded());

            System.out.println("Archivos Generados Correctamente");
        }catch(Exception e) {}
    }

    public static void main(String[] args) {

        //Mandamos a llamar a nuestra funcion que creara nuestras llaves
        generateKey();
    }
}
