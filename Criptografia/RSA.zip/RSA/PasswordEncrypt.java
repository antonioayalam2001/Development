import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class PasswordEncrypt {
   

   // Method to encrypt the password
   public String encryptPassword(String password) throws NoSuchAlgorithmException {
      MessageDigest mD = MessageDigest.getInstance("SHA-1");
      byte[] passDigest = mD.digest(password.getBytes());
      System.out.println(passDigest.toString());
      System.out.println(passDigest.length);
      String hash = "[B@1f17ae1";

      
      System.out.println(mD.isEqual(passDigest, hash.getBytes()));
      BigInteger bigInt = new BigInteger(1,passDigest);
      return bigInt.toString(16);
         }

   public static void main(String[] args) throws NoSuchAlgorithmException {
      System.out.println("Hi everyone");
      PasswordEncrypt pE = new PasswordEncrypt();
      String HashPassword = pE.encryptPassword("Antonio");
      System.out.println(HashPassword);

      String HashStored = "aa4a9f786afbc7c3ce73e9e9c77f4a477397adad";

      if (HashPassword.equals(HashStored)) {
         System.out.println("Hola");
      }

   }
}
