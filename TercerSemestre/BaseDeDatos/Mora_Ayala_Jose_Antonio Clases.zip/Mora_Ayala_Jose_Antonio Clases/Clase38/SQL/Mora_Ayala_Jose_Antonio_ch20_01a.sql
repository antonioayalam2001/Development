spool F:\Base\Clases\ch20_01a.txt

-- ch20_01a.sql ver 1.0
CREATE OR REPLACE FUNCTION show_description
	(i_course_no course.course_no%TYPE)
	RETURN varchar2
AS
	v_description varchar2(50);
BEGIN
	SELECT description
	INTO v_description
	FROM course
	WHERE course_no = i_course_no;
	RETURN v_description;
EXCEPTION
WHEN NO_DATA_FOUND
	THEN
		RETURN(‘The Course is not in the database');
	WHEN OTHERS
		THEN
	RETURN(‘Error in running show_description');
END;
/

spool off;