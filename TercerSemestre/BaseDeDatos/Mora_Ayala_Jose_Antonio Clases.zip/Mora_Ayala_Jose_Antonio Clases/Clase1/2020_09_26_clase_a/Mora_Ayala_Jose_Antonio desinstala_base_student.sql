rem borra base student, contenido y estructura de tablas
@@C:\Users\ORA_bases\O11\dropStudent.sql
rem @@C:\Users\ORA_bases\2020_09_02_clase_a\CIFRAS_CONTROL_STUDENT.sql

