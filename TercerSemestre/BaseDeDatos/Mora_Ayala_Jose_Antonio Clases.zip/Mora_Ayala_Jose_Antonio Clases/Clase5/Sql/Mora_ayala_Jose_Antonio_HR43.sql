spool  %ORA_OUT%\s43.txt
rem script HR43.sql
rem despliega atributos de la tabla employees del esquema HR
select employee_id, first_name
   from employees
   where first_name like 'S%';
spool off