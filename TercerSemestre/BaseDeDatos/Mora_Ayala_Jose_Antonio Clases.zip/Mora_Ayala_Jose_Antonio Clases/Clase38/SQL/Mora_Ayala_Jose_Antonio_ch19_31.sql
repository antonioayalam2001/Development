spool F:\Base\Clases\ch19_31.txt

/*
Escribe un procedimiento sin parámetros. 
El procedimiento debe indicar si el día actual es un
fin de semana o día hábil laborable. 
Además, debe indicarle el nombre del usuario y la hora actual.
 También debe especificar cuántos procedimientos válidos
 y no válidos hay en la base de datos.
*/


CREATE OR REPLACE PROCEDURE current_status
AS
	v_day_type CHAR(1);
	v_user VARCHAR2(30);
	v_valid NUMBER;
	v_invalid NUMBER;
BEGIN
	SELECT SUBSTR(TO_CHAR(sysdate, 'DAY'), 0, 1)
		INTO v_day_type
		FROM dual;
	IF v_day_type = 'S' THEN
		DBMS_OUTPUT.PUT_LINE ('Today is a weekend.');
	ELSE
		DBMS_OUTPUT.PUT_LINE ('Today is a weekday.');
	END IF;
--
DBMS_OUTPUT.PUT_LINE('The time is: '||
	TO_CHAR(sysdate, 'HH:MI AM'));
--
SELECT user
	INTO v_user
	FROM dual;
	DBMS_OUTPUT.PUT_LINE ('The current user is '||v_user);
--
SELECT NVL(COUNT(*), 0)
	INTO v_valid
	FROM user_objects
	WHERE status = 'VALID'
		AND object_type = 'PROCEDURE';
	DBMS_OUTPUT.PUT_LINE
	('There are '||v_valid||' valid procedures.');
--
SELECT NVL(COUNT(*), 0)
	INTO v_invalid
	FROM user_objects
	WHERE status = 'INVALID'
	AND object_type = 'PROCEDURE';
	DBMS_OUTPUT.PUT_LINE
	('There are '||v_invalid||' invalid procedures.');
END;
/

SET SERVEROUTPUT ON
EXEC current_status;

rem escenario 2

CREATE OR REPLACE PROCEDURE current_status
AS
	v_day_type CHAR(1);
	v_user VARCHAR2(30);
	v_valid NUMBER;
	v_invalid NUMBER;
BEGIN
	SELECT SUBSTR(TO_CHAR(sysdate, 'DAY'), 0, 1)
		INTO v_day_type
		FROM dual;
	IF v_day_type = 'S' THEN
		DBMS_OUTPUT.PUT_LINE ('Today is a weekend.');
		DBMS_OUTPUT.PUT_LINE (chr(09)||chr(9)||'Hoy es fin de semana');
	ELSE
		DBMS_OUTPUT.PUT_LINE ('Today is a weekday.');
		DBMS_OUTPUT.PUT_LINE (chr(09)||chr(9)||'Hoy es día habil.');
	END IF;
--
DBMS_OUTPUT.PUT_LINE('The time is: '||chr(09)||chr(9)||'La  hora es:'||
	TO_CHAR(sysdate, 'HH:MI AM')||chr(10));
--
SELECT user
	INTO v_user
	FROM dual;
	DBMS_OUTPUT.PUT_LINE ('The current user is=> El usuario actual '||v_user||chr(10));
--
SELECT NVL(COUNT(*), 0)
	INTO v_valid
	FROM user_objects
	WHERE status = 'VALID'
		AND object_type = 'PROCEDURE';
	DBMS_OUTPUT.PUT_LINE
	('There are '||v_valid||' valid procedures.');
	DBMS_OUTPUT.PUT_LINE
	('Existen '||v_valid||' procedimientos válidos.'||chr(10));
--
SELECT NVL(COUNT(*), 0)
	INTO v_invalid
	FROM user_objects
	WHERE status = 'INVALID'
	AND object_type = 'PROCEDURE';
	DBMS_OUTPUT.PUT_LINE
	('There are '||v_invalid||' invalid procedures.');
	DBMS_OUTPUT.PUT_LINE
	('Existen  '||v_invalid||' procedimientos invalidos.');
END;
/

--*Ejecutando Procedimiento
EXEC current_status;

--*Observando los procedimientos que tenemos
SELECT object_name, object_type, status
FROM user_objects
WHERE object_name = 'current_status';

spool off;