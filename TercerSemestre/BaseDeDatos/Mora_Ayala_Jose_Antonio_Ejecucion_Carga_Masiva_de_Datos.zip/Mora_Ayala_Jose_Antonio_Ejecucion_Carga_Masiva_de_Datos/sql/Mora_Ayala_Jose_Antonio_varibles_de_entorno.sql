spool F:\Base\Clases\varibles_de_entorno.txt

rem  definir las variables de ent1orno de windows

--Agregar variables de entorno, con el mismo nombre
--y ruta

--	   PATH DE CONTROL
SET ORA_SCRIPTS=C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook
--	   PATH DE CONTROL
SET ORA_CONTROL=C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook\control

--	   PATH DE LOG    BITACORA
SET    ORA_LOG =C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook\bitacora

--	   PATH DE BAD
SET    ORA_BAD =C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook\bad

--	   PATH DE DISCARD
SET ORA_DISCARD=C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook\discard

--     PATH DE DATOS A POBLAR				   
SET   ORA_DATA =C:\Users\TONY AYALA\Google Drive\College\TercerSemestre\Base de Datos\PC\Clases\Clase34\dbbook\data

rem  ejecutar en cmd 

--sqlldr es manejador carga masiva
--crear un usuario donde estaran estos datos "usuario"/"password"

		
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\faculty.ctl'  log='%ORA_LOG%\faculty.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\aircraft.ctl' log='%ORA_LOG%\aircraft.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\catalog.ctl'  log='%ORA_LOG%\catalog.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\certified.ctl'log='%ORA_LOG%\certified.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\class.ctl'    log='%ORA_LOG%\class.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\dept.ctl'     log='%ORA_LOG%\dept.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\emp.ctl'      log='%ORA_LOG%\emp.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\employees.ctl'log='%ORA_LOG%\employees.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\enrolled.ctl' log='%ORA_LOG%\enrolled.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\flights.ctl'  log='%ORA_LOG%\flights.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\parts.ctl'    log='%ORA_LOG%\parts.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\sailors.ctl'  log='%ORA_LOG%\sailors.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\student.ctl'  log='%ORA_LOG%\student.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\suppliers.ctl'log='%ORA_LOG%\suppliers.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\works.ctl'    log='%ORA_LOG%\works.log'
sqlldr Clase34/Clase34 control='%ORA_CONTROL%\faculty.ctl'  log='%ORA_LOG%\faculty.log'
		



spool off;