#!/bin/bash
echo Estas apunto de ejecutar el programa: Insercion
cd ..
gcc mainLin.c -lm -o mainLin
./mainLin
./mainLin 4 100 >InsercionT.txt
./mainLin 4 1000 >>InsercionT.txt
./mainLin 4 5000 >>InsercionT.txt
./mainLin 4 10000 >>InsercionT.txt
./mainLin 4 50000 >>InsercionT.txt
./mainLin 4 100000 >>InsercionT.txt 
./mainLin 4 125000 >>InsercionT.txt 
./mainLin 4 175000 >>InsercionT.txt 
./mainLin 4 200000 >>InsercionT.txt
./mainLin 4 225000 >>InsercionT.txt
./mainLin 4 275000 >>InsercionT.txt
./mainLin 4 300000 >>InsercionT.txt
./mainLin 4 325000 >>InsercionT.txt
./mainLin 4 375000 >>InsercionT.txt
./mainLin 4 400000 >>InsercionT.txt
./mainLin 4 425000 >>InsercionT.txt
./mainLin 4 500000 >>InsercionT.txt
# ./mainLin 4 600000 >>InsercionT.txt
# ./mainLin 4 800000 >>InsercionT.txt
# ./mainLin 4 1000000 >>InsercionT.txt
# ./mainLin 4 2000000 >>InsercionT.txt
# ./mainLin 4 3000000 >>InsercionT.txt
# ./mainLin 4 4000000 >>InsercionT.txt
# ./mainLin 4 5000000 >>InsercionT.txt
# ./mainLin 4 6000000 >>InsercionT.txt
# ./mainLin 4 7000000 >>InsercionT.txt
# ./mainLin 4 8000000 >>InsercionT.txt
# ./mainLin 4 9000000 >>InsercionT.txt
# ./mainLin 4 10000000 >>InsercionT.txt


