spool F:\Documents\BasedeDatos\Capitulo8\Capitulo8.txt

--  Capitulo 8 Ejercicios SQLOracle By Example
--  Proporcionando un formato a la consola
--  Para obtener visualzacion de mejor forma

TTITLE COL 28  '===>  E  S  C  O  M' SKIP 1 -
COL 28  '====================' SKIP 1    -
COL 5 LEFT 'Ejercicios Capitulo 8'      COL 28 '===================='  COL 65  'Bases de Datos' skip 1  -
COL 5 '====================================================' SKIP 2

set sqlprompt 'SQL>'
SET HEADING On;
set colsep '||'
set underline '='
SET PAGESIZE 99
SET LINESIZE 110
Connect Student/learn;
--  Mostrando el usuario en el cual tenemos nuestra base de Datos Student
show user;
--  Conociendo nuestras tablas 
desc Student;
--  Chapter 8.Set Operators
--  The Power Of UNION and UNION ALL
SELECT first_name, last_name, phone
   FROM instructor
  UNION
 SELECT first_name, last_name, phone
   FROM student;

SELECT first_name, last_name, phone, COUNT(*)
   FROM student
  GROUP BY first_name, last_name, phone
 HAVING COUNT(*) > 1;

SELECT first_name, last_name, phone
   FROM instructor
  UNION ALL;

SELECT first_name, last_name, phone
   FROM student;

--  ORDER BY and SET Operations
SELECT instructor_id id, first_name, last_name, phone
   FROM instructor
  UNION
 SELECT student_id, first_name, last_name, phone
   FROM student
  ORDER BY 3;

--  The MINUS And INTERSECT SET Operators
--  The MINUS Operator
SELECT instructor_id
   FROM instructor
  MINUS
 SELECT instructor_id
   FROM section;

--  The MINUS Operator
SELECT instructor_id
   FROM instructor;
SELECT DISTINCT instructor_id
   FROM section;

--  The MINUS Operator
SELECT created_by
   FROM enrollment
  MINUS
 SELECT created_by
   FROM course;

SELECT DISTINCT created_by
   FROM enrollment;

--  The MINUS Operator
SELECT DISTINCT created_by
   FROM course;

--  The INTERSECT Operator
SELECT created_by
   FROM enrollment
 INTERSECT
 SELECT created_by
   FROM course;


--  The INTERSECT Operator
--  INTERSECT Instead Of EQUIJOINS
SELECT DISTINCT c.course_no
   FROM course c, section s
  WHERE c.course_no = s.course_no;

--  INTERSECT Instead Of EQUIJOINS
SELECT course_no
   FROM course
 INTERSECT
 SELECT course_no
   FROM section;

--  Execution Order Of Set Operations
SELECT col1
   FROM t1
 UNION ALL
 SELECT col2
   FROM t2
 MINUS
 SELECT col3
   FROM t3;


SELECT col1
   FROM t1
 UNION ALL
 (SELECT col2
   FROM t2
 MINUS
 SELECT col3
   FROM t3);


--	Lab 8.2.1. Utilice el operador de conjunto MINUS

--	a) Explique el resultado de la siguiente operación de conjunto.

--	La operación de conjunto resta todos los cursos que tienen secciones de todos los cursos,
--		lo que da como resultado los dos cursos sin secciones coincidentes.

--	b) Utilice el operador de conjunto MINUS para crear una lista de cursos y 
--		secciones sin estudiantes inscritos. Agregue una columna al conjunto de resultados 
--		con el título Estado y muestre el texto Sin inscripciones en cada fila. Ordene los 
--		resultados por las columnas COURSE_NO y SECTION_NO

SELECT course_no, section_no, 'No Enrollments' "Status"
FROM section
MINUS
SELECT course_no, section_no, 'No Enrollments'
FROM section s
WHERE EXISTS (SELECT section_id
			  FROM enrollment e
			  WHERE e.section_id = s.section_id)
ORDER BY 1, 2;

--	Lab 8.2.2. Utilice el operador de conjunto INTERSECT

--	a) Utilice el operador de conjunto INTERSECT para enumerar todos los códigos postales 
--		que se encuentran en las tablas de ESTUDIANTE e INSTRUCTOR.

SELECT zip
FROM instructor
INTERSECT
SELECT zip
FROM student;

--	b) Utilice el operador de conjunto INTERSECT para enumerar las identificaciones de los 
--		estudiantes que están inscritos.

SELECT student_id
FROM student
INTERSECT
SELECT student_id
FROM enrollment;

spool off